# StrengthSMP 2.0 - Java + Bedrock (Paper + Geyser + Floodgate)

Kill a player = +1 permanent Strength. Ranks, 12 abilities, custom weapons/armor,
scrolls, crystals, upgrade/reroll, anti-farm, scoreboard + tab list.

## Versions and dependencies
- Paper 1.21 - 1.21.1 (built against paper-api 1.21.1), Java 21
- Geyser-Spigot + Floodgate-Spigot (geysermc.org/download) for Bedrock players
- The plugin does not call the Geyser/Floodgate API, so it needs no extra dependency
- Paper 1.21.3+: in pom.xml raise the paper-api version and in Util.java change
  Attribute.GENERIC_MAX_HEALTH to Attribute.MAX_HEALTH (one line)

## 1. Build
    mvn package
Result: target/StrengthSMP-2.0.0.jar

## 2. Server
1. Download Paper, rename it paper.jar, put it with server/start.sh in a folder
2. Run ./start.sh once, set eula=true in eula.txt, run again, then stop
3. Put into plugins/: StrengthSMP-2.0.0.jar, Geyser-Spigot.jar, Floodgate-Spigot.jar
4. Start the server. Open TCP 25565 (Java) and UDP 19132 (Bedrock)
5. Java joins on IP:25565, Bedrock on the same IP, port 19132

## Core mechanic
- Valid PvP kill = exactly +1 Strength (melee, bow, crossbow, trident, any projectile)
- No reward for mob kills, void/fall deaths, suicide or duplicate death events
- Strength is kept after death, logout and restart (plugins/StrengthSMP/playerdata/)
- Damage uses a custom calculation (damage-per-level), not the potion effect, so it
  works safely beyond vanilla limits. Max level in config.yml (strength.max-level)
- Optional death penalty, health scaling, prestige, milestones, ranks (all in config.yml)

## Commands
/strength [player]   stats, rank, kills, deaths, K/D, streak, total gained
/ability             chest menu to select an ability
/ability list | select <id> | cycle | use [id] | <id>
/withdraw            1 Strength -> Strength Crystal (right-click = +1)
/prestige            at max Strength (if enabled)
/upgrade /reroll     upgrade or reroll the custom item in your hand
/leaderboard         top 10
/ssmp set|add|remove <player> <n>, reset <player> [stats], give <player> <item> [n],
      unlock <player> <ability>, reload      (permission strengthsmp.admin)

## Using abilities (same on Java and Bedrock)
- Right-click a sword / axe / mace = use the selected ability
- Sneak + right-click = switch to the next ability
- /ability menu or /ability <id> works everywhere
- Optional: swap-hands key (abilities.swap-key: true)
- Items with a bound ability (Heavy Axe, Thunder Sword, Speed Dagger) fire it on right-click
- Unlock by Strength (config) or with a Scroll (/ssmp give <player> scroll_<ability>)

## Java vs Bedrock differences
- Bedrock has no keybinds: abilities use sneak + right-click, the menu or commands
- No resource pack: custom items are vanilla items with names/lore, so Bedrock sees them
- same-ip-check may misfire for Bedrock/LAN players, so it is off by default
- Sidebar, tab list, titles and action bar work through Geyser; looks can differ slightly

## Add a new ability
In AbilityManager.registerDefaults() add:
    register("my_ability", "My Ability", "Description.", Material.DIAMOND, (p, c) -> { ...; return true; });
then add abilities.list.my_ability (cooldown, unlock-strength, ...) to config.yml.
