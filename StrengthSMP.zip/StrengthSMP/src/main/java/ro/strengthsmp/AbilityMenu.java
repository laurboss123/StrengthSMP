package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Chest GUI for choosing the selected ability. Works on Bedrock through Geyser. */
public class AbilityMenu implements InventoryHolder {
    private final Inventory inv;
    private final List<String> slots = new ArrayList<>();

    public AbilityMenu(StrengthSMP plugin, Player p) {
        inv = Bukkit.createInventory(this, 27, Util.color("&8Abilities"));
        PlayerData d = plugin.data().get(p);
        AbilityManager am = plugin.abilities();
        int i = 0;
        for (AbilityManager.Ability a : am.all()) {
            if (i >= 27) break;
            ConfigurationSection c = am.cfg(a.id());
            boolean enabled = c.getBoolean("enabled", true);
            boolean unlocked = am.isUnlocked(p, a);
            ItemStack it = new ItemStack(enabled && unlocked ? a.icon() : Material.BARRIER);
            ItemMeta m = it.getItemMeta();
            boolean selected = a.id().equals(d.selectedAbility);
            m.displayName(Util.color((unlocked ? "&a" : "&c") + a.name() + (selected ? " &e[SELECTED]" : "")));
            List<Component> lore = new ArrayList<>();
            lore.add(Util.color("&7" + a.description()));
            lore.add(Util.color("&7Cooldown: &f" + Util.num(c.getDouble("cooldown", 10)) + "s"));
            int need = c.getInt("unlock-strength", 0);
            if (!enabled) lore.add(Util.color("&cDisabled by admin"));
            else if (!unlocked) lore.add(Util.color(need >= 0 ? "&cRequires Strength " + need : "&cUnlock with a scroll"));
            else lore.add(Util.color("&eClick to select"));
            m.lore(lore);
            it.setItemMeta(m);
            inv.setItem(i, it);
            slots.add(a.id());
            i++;
        }
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    public String idAt(int slot) {
        return slot >= 0 && slot < slots.size() ? slots.get(slot) : null;
    }
}
