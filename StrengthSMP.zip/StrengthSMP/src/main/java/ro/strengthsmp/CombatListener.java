package ro.strengthsmp;

import net.kyori.adventure.title.Title;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.potion.PotionEffectType;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Kill rewards, Strength damage scaling, items, lifesteal, shields, crits. */
public class CombatListener implements Listener {
    private final StrengthSMP plugin;
    private final Map<UUID, Long> lastDeath = new HashMap<>();
    private final Random random = new Random();

    public CombatListener(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    private Player attackerOf(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile pr && pr.getShooter() instanceof Player s) return s;
        return null;
    }

    // ---------- damage ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        FileConfiguration cfg = plugin.getConfig();
        AbilityManager am = plugin.abilities();
        ItemManager items = plugin.items();
        Player attacker = attackerOf(e.getDamager());
        Entity victim = e.getEntity();
        double dmg = e.getDamage();
        double lifesteal = 0.0;

        if (attacker != null && victim instanceof LivingEntity && !am.isAbilityDamage()
                && (victim instanceof Player || cfg.getBoolean("strength.apply-to-mobs", true))) {
            PlayerData ad = plugin.data().get(attacker);
            boolean melee = e.getDamager() instanceof Player;
            ItemManager.Stats hand = melee
                    ? items.stats(attacker.getInventory().getItemInMainHand())
                    : ItemManager.Stats.NONE;
            ItemManager.Stats armor = items.armorStats(attacker);

            dmg += plugin.strength().damageBonus(ad) + hand.damage() + armor.damage();
            if (am.isActive(attacker, "berserker")) {
                dmg *= am.cfg("berserker").getDouble("multiplier", 1.3);
            }
            if (am.isActive(attacker, "strength_boost")) {
                dmg += am.cfg("strength_boost").getDouble("bonus", 3.0);
            }

            double crit = cfg.getDouble("combat.base-crit-chance", 0.0) + hand.crit() + armor.crit();
            if (crit > 0 && random.nextDouble() < crit) {
                dmg *= cfg.getDouble("combat.crit-multiplier", 1.5);
                attacker.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 15, 0.3, 0.3, 0.3, 0.1);
                attacker.sendActionBar(Util.color("&cCritical hit!"));
            }

            lifesteal = hand.lifesteal() + armor.lifesteal();
            if (am.isActive(attacker, "lifesteal")) {
                lifesteal += am.cfg("lifesteal").getDouble("percent", 0.25);
            }

            if (am.isActive(attacker, "invisibility") && am.cfg("invisibility").getBoolean("break-on-attack", true)) {
                attacker.removePotionEffect(PotionEffectType.INVISIBILITY);
                am.endBuff(attacker, "invisibility");
            }
        }

        if (victim instanceof Player vp) {
            double red = plugin.items().armorStats(vp).reduction();
            if (am.isActive(vp, "shield")) red += am.cfg("shield").getDouble("reduction", 0.5);
            red = Math.min(red, cfg.getDouble("combat.max-damage-reduction", 0.8));
            if (red > 0) dmg *= (1.0 - red);
        }

        double cap = cfg.getDouble("combat.max-damage-per-hit", 200.0);
        if (Double.isNaN(dmg) || dmg < 0) dmg = 0;
        dmg = Math.min(dmg, cap);
        e.setDamage(dmg);

        if (attacker != null && lifesteal > 0 && dmg > 0 && !attacker.isDead()) {
            AttributeInstance mh = attacker.getAttribute(Util.maxHealth());
            double max = mh != null ? mh.getValue() : 20.0;
            attacker.setHealth(Math.max(0.1, Math.min(max, attacker.getHealth() + dmg * lifesteal)));
        }

        if (attacker != null && victim instanceof Player target && !attacker.equals(target)) {
            am.tagCombat(attacker);
            am.tagCombat(target);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL && e.getEntity() instanceof Player p
                && plugin.abilities().isActive(p, "nofall")) {
            e.setCancelled(true);
        }
    }

    // ---------- kills ----------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        long now = System.currentTimeMillis();
        Long last = lastDeath.get(victim.getUniqueId());
        if (last != null && now - last < 1000) return; // prevents duplicate rewards for one death
        lastDeath.put(victim.getUniqueId(), now);

        PlayerData vd = plugin.data().get(victim);
        vd.deaths++;
        vd.streak = 0;
        plugin.abilities().clearBuffs(victim);

        Player killer = victim.getKiller();
        boolean validPvp = killer != null && !killer.equals(victim) && isDirectPvp(victim, killer);
        if (validPvp) handleKill(killer, victim);

        FileConfiguration cfg = plugin.getConfig();
        if (cfg.getBoolean("death-penalty.enabled", false)
                && (validPvp || !cfg.getBoolean("death-penalty.only-pvp", true))) {
            int loss = cfg.getInt("death-penalty.amount", 1);
            plugin.strength().setStrength(victim, vd.strength - loss, false);
        }
        plugin.strength().refresh(victim);
    }

    /** Last damage must come from the killer (melee or their projectile) - no void/fall kills. */
    private boolean isDirectPvp(Player victim, Player killer) {
        if (!plugin.getConfig().getBoolean("kills.pvp-only", true)) return true;
        EntityDamageEvent last = victim.getLastDamageCause();
        if (last instanceof EntityDamageByEntityEvent ebe) {
            Player a = attackerOf(ebe.getDamager());
            return a != null && a.equals(killer);
        }
        return false;
    }

    private void handleKill(Player killer, Player victim) {
        PlayerData kd = plugin.data().get(killer);
        kd.kills++;
        kd.streak++;
        kd.bestStreak = Math.max(kd.bestStreak, kd.streak);

        String reason = plugin.antiFarm().check(killer, victim);
        if (reason != null) {
            plugin.send(killer, "kill-no-reward", "reason", reason);
            plugin.strength().refresh(killer);
            return;
        }

        int max = plugin.strength().max();
        if (kd.strength >= max) {
            plugin.send(killer, "kill-max", "victim", victim.getName(), "max", max);
            plugin.antiFarm().record(killer, victim);
            plugin.strength().refresh(killer);
            return;
        }

        int old = kd.strength;
        plugin.strength().setStrength(killer, old + 1, true); // exactly +1 per valid kill
        kd.totalGained += Math.max(0, kd.strength - old);
        plugin.antiFarm().record(killer, victim);
        feedback(killer, victim, kd.strength);
    }

    private void feedback(Player killer, Player victim, int level) {
        FileConfiguration c = plugin.getConfig();
        killer.sendMessage(plugin.msg("kill", "victim", victim.getName(), "level", level));
        if (c.getBoolean("feedback.action-bar", true)) {
            killer.sendActionBar(Util.color("&6Strength: &c" + level));
        }
        if (c.getBoolean("feedback.title", true)) {
            killer.showTitle(Title.title(Util.color("&c+1 Strength"), Util.color("&7Level " + level),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1000), Duration.ofMillis(300))));
        }
        if (c.getBoolean("feedback.sound", true)) {
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
        if (c.getBoolean("feedback.particles", true)) {
            killer.getWorld().spawnParticle(Particle.CRIT, killer.getLocation().add(0, 1, 0), 30, 0.5, 0.8, 0.5, 0.2);
        }
    }
}
