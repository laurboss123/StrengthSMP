package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Sidebar scoreboard (Geyser shows it on Bedrock too). */
public class ScoreboardManager {
    private final StrengthSMP plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public ScoreboardManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void update(Player p) {
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) return;
        if (Bukkit.getScoreboardManager() == null) return;
        PlayerData d = plugin.data().get(p);
        StrengthManager.Rank r = plugin.strength().rankFor(d.strength);

        Scoreboard board = boards.computeIfAbsent(p.getUniqueId(), k -> Bukkit.getScoreboardManager().getNewScoreboard());
        Objective old = board.getObjective("ssmp");
        if (old != null) old.unregister();
        Objective obj = board.registerNewObjective("ssmp", Criteria.DUMMY,
                Util.color(plugin.getConfig().getString("scoreboard.title", "&c&lSTRENGTH SMP")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        String[] lines = {
                "&1 ",
                "&fStrength: &c" + d.strength,
                "&fRank: " + r.color() + r.display(),
                "&fPrestige: &d" + d.prestige,
                "&2 ",
                "&fKills: &a" + d.kills,
                "&fDeaths: &c" + d.deaths,
                "&fStreak: &6" + d.streak,
                "&3 "
        };
        int score = lines.length;
        for (String l : lines) {
            obj.getScore(ChatColor.translateAlternateColorCodes('&', l)).setScore(score--);
        }
        p.setScoreboard(board);
    }

    public void remove(UUID id) {
        boards.remove(id);
    }
}
