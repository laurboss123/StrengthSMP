package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public class StrengthSMP extends JavaPlugin {

    private DataManager data;
    private StrengthManager strength;
    private AbilityManager abilities;
    private ItemManager items;
    private AntiFarm antiFarm;
    private ScoreboardManager scoreboards;
    private PlayerListener playerListener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        data = new DataManager(this);
        strength = new StrengthManager(this);
        strength.loadRanks();
        antiFarm = new AntiFarm(this);
        abilities = new AbilityManager(this);
        abilities.registerDefaults();
        items = new ItemManager(this);
        items.load();
        scoreboards = new ScoreboardManager(this);

        playerListener = new PlayerListener(this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(playerListener, this);

        Commands cmds = new Commands(this);
        for (String name : List.of("strength", "ability", "withdraw", "prestige", "upgrade", "reroll", "leaderboard", "ssmp")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(cmds);
                pc.setTabCompleter(cmds);
            }
        }

        // keep health / scoreboard in sync (armor bonuses etc.)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) strength.refresh(p);
        }, 100L, 100L);
        // autosave every 5 minutes
        Bukkit.getScheduler().runTaskTimer(this, () -> data.saveAll(), 6000L, 6000L);

        // /reload safety
        for (Player p : Bukkit.getOnlinePlayers()) playerListener.setup(p);

        getLogger().info("StrengthSMP enabled (Java + Bedrock via Geyser/Floodgate).");
    }

    @Override
    public void onDisable() {
        if (data != null) data.saveAll();
    }

    public void reload() {
        reloadConfig();
        strength.loadRanks();
        items.load();
    }

    public Component msg(String key, Object... kv) {
        String raw = getConfig().getString("messages." + key, "&cMissing message: " + key);
        String prefix = getConfig().getString("messages.prefix", "");
        return Util.color(prefix + Util.fmt(raw, kv));
    }

    public void send(CommandSender to, String key, Object... kv) {
        to.sendMessage(msg(key, kv));
    }

    public DataManager data() {
        return data;
    }

    public StrengthManager strength() {
        return strength;
    }

    public AbilityManager abilities() {
        return abilities;
    }

    public ItemManager items() {
        return items;
    }

    public AntiFarm antiFarm() {
        return antiFarm;
    }

    public ScoreboardManager scoreboards() {
        return scoreboards;
    }
}
