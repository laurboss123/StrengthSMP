package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Modular ability framework. To add an ability: call register(...) with an Executor
 * and add a section under abilities.list.<id> in config.yml.
 */
public class AbilityManager {

    public interface Executor {
        /** Return true if the ability fired (cooldown is only consumed on success). */
        boolean run(Player p, ConfigurationSection cfg);
    }

    public record Ability(String id, String name, String description, Material icon, Executor exec) {
    }

    private final StrengthSMP plugin;
    private final Map<String, Ability> abilities = new LinkedHashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private final Map<UUID, Map<String, Long>> active = new HashMap<>();
    private final Map<UUID, Long> lastAny = new HashMap<>();
    private final Map<UUID, Long> combat = new HashMap<>();
    private boolean abilityDamage = false;

    public AbilityManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    // ---------- registry ----------

    public void register(String id, String name, String description, Material icon, Executor exec) {
        abilities.put(id, new Ability(id, name, description, icon, exec));
        String perm = "strengthsmp.ability." + id;
        if (Bukkit.getPluginManager().getPermission(perm) == null) {
            Bukkit.getPluginManager().addPermission(new Permission(perm, PermissionDefault.TRUE));
        }
    }

    public Ability get(String id) {
        return id == null ? null : abilities.get(id.toLowerCase());
    }

    public Collection<Ability> all() {
        return abilities.values();
    }

    public ConfigurationSection cfg(String id) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("abilities.list." + id);
        return s != null ? s : new YamlConfiguration();
    }

    // ---------- state ----------

    public boolean isUnlocked(Player p, Ability a) {
        PlayerData d = plugin.data().get(p);
        if (d.unlocked.contains(a.id())) return true;
        int need = cfg(a.id()).getInt("unlock-strength", 0);
        return need >= 0 && d.strength >= need;
    }

    public void activate(Player p, String key, double seconds) {
        active.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>())
                .put(key, System.currentTimeMillis() + (long) (seconds * 1000));
    }

    public boolean isActive(Player p, String key) {
        Map<String, Long> m = active.get(p.getUniqueId());
        if (m == null) return false;
        Long t = m.get(key);
        if (t == null) return false;
        if (System.currentTimeMillis() > t) {
            m.remove(key);
            return false;
        }
        return true;
    }

    public void endBuff(Player p, String key) {
        Map<String, Long> m = active.get(p.getUniqueId());
        if (m != null) m.remove(key);
    }

    public void clearBuffs(Player p) {
        active.remove(p.getUniqueId());
    }

    public void clear(UUID id) {
        active.remove(id);
        cooldowns.remove(id);
        lastAny.remove(id);
        combat.remove(id);
    }

    public void tagCombat(Player p) {
        double sec = plugin.getConfig().getDouble("combat.combat-tag-seconds", 10);
        combat.put(p.getUniqueId(), System.currentTimeMillis() + (long) (sec * 1000));
    }

    public boolean inCombat(Player p) {
        Long t = combat.get(p.getUniqueId());
        return t != null && System.currentTimeMillis() < t;
    }

    public boolean isAbilityDamage() {
        return abilityDamage;
    }

    /** Damage dealt by an ability: skips Strength/item bonuses so it is not boosted twice. */
    public void damage(Player src, LivingEntity target, double amount) {
        abilityDamage = true;
        try {
            target.damage(amount, src);
        } finally {
            abilityDamage = false;
        }
    }

    public boolean canHarm(Player p, LivingEntity t) {
        if (t.equals(p) || t instanceof ArmorStand || t.isDead()) return false;
        if (t instanceof Player tp) {
            if (tp.getGameMode() == GameMode.CREATIVE || tp.getGameMode() == GameMode.SPECTATOR) return false;
            if (!tp.getWorld().getPVP()) return false;
        }
        return true;
    }

    // ---------- selection ----------

    public List<String> available(Player p) {
        List<String> list = new ArrayList<>();
        for (Ability a : abilities.values()) {
            if (cfg(a.id()).getBoolean("enabled", true) && isUnlocked(p, a)) list.add(a.id());
        }
        return list;
    }

    public void ensureSelection(Player p) {
        PlayerData d = plugin.data().get(p);
        List<String> av = available(p);
        if (!av.contains(d.selectedAbility)) {
            d.selectedAbility = av.isEmpty() ? "" : av.get(0);
        }
    }

    public void select(Player p, String id) {
        Ability a = get(id);
        if (a == null) {
            plugin.send(p, "ability-unknown");
            return;
        }
        if (!cfg(a.id()).getBoolean("enabled", true)) {
            plugin.send(p, "ability-disabled", "ability", a.name());
            return;
        }
        if (!isUnlocked(p, a)) {
            sendLocked(p, a);
            return;
        }
        plugin.data().get(p).selectedAbility = a.id();
        plugin.send(p, "ability-selected", "ability", a.name());
    }

    public void cycle(Player p) {
        PlayerData d = plugin.data().get(p);
        List<String> av = available(p);
        if (av.isEmpty()) {
            plugin.send(p, "ability-none");
            return;
        }
        int idx = av.indexOf(d.selectedAbility);
        d.selectedAbility = av.get((idx + 1) % av.size());
        Ability a = get(d.selectedAbility);
        p.sendActionBar(Util.color("&eSelected ability: &6" + (a != null ? a.name() : d.selectedAbility)));
    }

    private void sendLocked(Player p, Ability a) {
        int need = cfg(a.id()).getInt("unlock-strength", 0);
        if (need >= 0) plugin.send(p, "ability-locked", "ability", a.name(), "need", need);
        else plugin.send(p, "ability-locked-scroll", "ability", a.name());
    }

    // ---------- use ----------

    public boolean use(Player p, String id, boolean ignoreUnlock) {
        Ability a = get(id);
        if (a == null) {
            plugin.send(p, "ability-unknown");
            return false;
        }
        ConfigurationSection c = cfg(a.id());
        if (!c.getBoolean("enabled", true)) {
            plugin.send(p, "ability-disabled", "ability", a.name());
            return false;
        }
        if (!p.hasPermission("strengthsmp.ability." + a.id())) {
            plugin.send(p, "no-permission");
            return false;
        }
        if (p.getGameMode() == GameMode.SPECTATOR) return false;
        if (!ignoreUnlock && !isUnlocked(p, a)) {
            sendLocked(p, a);
            return false;
        }
        if (c.getBoolean("blocked-in-combat", false) && inCombat(p)) {
            plugin.send(p, "ability-combat", "ability", a.name());
            return false;
        }

        long now = System.currentTimeMillis();
        long globalCd = (long) (plugin.getConfig().getDouble("abilities.global-cooldown", 1.0) * 1000);
        Long la = lastAny.get(p.getUniqueId());
        if (la != null && now - la < globalCd) return false;

        Map<String, Long> cds = cooldowns.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
        long until = cds.getOrDefault(a.id(), 0L);
        if (now < until) {
            plugin.send(p, "ability-cooldown", "ability", a.name(), "seconds", (until - now + 999) / 1000);
            return false;
        }

        if (!a.exec().run(p, c)) return false;

        cds.put(a.id(), now + (long) (c.getDouble("cooldown", 10) * 1000));
        lastAny.put(p.getUniqueId(), now);
        p.sendActionBar(Util.color("&6" + a.name() + " &eactivated!"));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
        return true;
    }

    // ---------- built-in abilities ----------

    public void registerDefaults() {
        register("dash", "Dash", "Quickly move in the direction you are facing.", Material.FEATHER, (p, c) -> {
            Vector dir = p.getLocation().getDirection().setY(0);
            if (dir.lengthSquared() < 0.0001) dir = new Vector(0, 0, 1);
            dir.normalize().multiply(c.getDouble("power", 1.8)).setY(c.getDouble("lift", 0.25));
            p.setVelocity(dir);
            activate(p, "nofall", 3);
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1f);
            p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 15, 0.3, 0.1, 0.3, 0.02);
            return true;
        });

        register("super_jump", "Super Jump", "Perform a powerful jump.", Material.RABBIT_FOOT, (p, c) -> {
            p.setVelocity(p.getVelocity().setY(c.getDouble("power", 1.3)));
            activate(p, "nofall", c.getDouble("fall-protection-seconds", 6));
            p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 20, 0.3, 0.1, 0.3, 0.05);
            return true;
        });

        register("teleport", "Teleport", "Teleport a short distance forward, only to a safe spot.", Material.ENDER_PEARL, (p, c) -> {
            Location dest = findSafeSpot(p, c.getInt("range", 8));
            if (dest == null) {
                p.sendActionBar(Util.color("&cNo safe spot ahead."));
                return false;
            }
            p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.05);
            p.teleport(dest);
            p.getWorld().playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
            return true;
        });

        register("shield", "Shield", "Temporarily reduce incoming damage.", Material.SHIELD, (p, c) -> {
            activate(p, "shield", c.getDouble("duration", 6));
            p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1f);
            return true;
        });

        register("lifesteal", "Lifesteal", "Restore health based on a percentage of damage dealt.", Material.GHAST_TEAR, (p, c) -> {
            activate(p, "lifesteal", c.getDouble("duration", 8));
            return true;
        });

        register("berserker", "Berserker", "Temporarily increase combat damage.", Material.NETHERITE_AXE, (p, c) -> {
            activate(p, "berserker", c.getDouble("duration", 8));
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1f, 1f);
            return true;
        });

        register("speed_boost", "Speed Boost", "Gain temporary movement speed.", Material.SUGAR, (p, c) -> {
            p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED,
                    (int) (c.getDouble("duration", 8) * 20), c.getInt("amplifier", 1)));
            return true;
        });

        register("invisibility", "Invisibility", "Become temporarily invisible. Attacking can break it.", Material.GLASS, (p, c) -> {
            double dur = c.getDouble("duration", 10);
            p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, (int) (dur * 20), 0, false, false));
            activate(p, "invisibility", dur);
            return true;
        });

        register("lightning", "Lightning Strike", "Call lightning on the target you are looking at.", Material.LIGHTNING_ROD, (p, c) -> {
            Entity t = p.getTargetEntity(c.getInt("range", 20));
            if (!(t instanceof LivingEntity le) || !canHarm(p, le)) {
                p.sendActionBar(Util.color("&cNo valid target."));
                return false;
            }
            if (c.getBoolean("real-lightning", false)) le.getWorld().strikeLightning(le.getLocation());
            else le.getWorld().strikeLightningEffect(le.getLocation());
            damage(p, le, c.getDouble("damage", 6.0));
            return true;
        });

        register("ground_slam", "Ground Slam", "Damage and knock back nearby enemies.", Material.MACE, (p, c) -> {
            double r = c.getDouble("radius", 5);
            double dmg = c.getDouble("damage", 6.0);
            double kb = c.getDouble("knockback", 1.0);
            for (Entity en : p.getNearbyEntities(r, r / 2, r)) {
                if (en instanceof LivingEntity le && canHarm(p, le)) {
                    damage(p, le, dmg);
                    Vector away = le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
                    if (away.lengthSquared() > 0.0001) away.normalize().multiply(kb);
                    else away = new Vector(0, 0, 0);
                    le.setVelocity(le.getVelocity().add(away.setY(0.45)));
                }
            }
            p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 40, r / 2, 0.2, r / 2, 0.1);
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
            return true;
        });

        register("regeneration", "Regeneration", "Restore health over time.", Material.GOLDEN_APPLE, (p, c) -> {
            p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION,
                    (int) (c.getDouble("duration", 8) * 20), c.getInt("amplifier", 1)));
            return true;
        });

        register("strength_boost", "Strength Boost", "Temporarily add flat bonus damage.", Material.BLAZE_POWDER, (p, c) -> {
            activate(p, "strength_boost", c.getDouble("duration", 10));
            p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.1);
            return true;
        });
    }

    private Location findSafeSpot(Player p, int range) {
        Vector dir = p.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.0001) return null;
        dir.normalize();
        Location eye = p.getEyeLocation();
        RayTraceResult hit = p.getWorld().rayTraceBlocks(eye, dir, range);
        double max = range;
        if (hit != null) max = Math.max(0, eye.toVector().distance(hit.getHitPosition()) - 1);
        for (int d = (int) Math.floor(max); d >= 1; d--) {
            Location cand = p.getLocation().add(dir.clone().multiply(d));
            Block feet = cand.getBlock();
            Block head = feet.getRelative(BlockFace.UP);
            Block below = feet.getRelative(BlockFace.DOWN);
            if (!feet.isPassable() || feet.isLiquid() || !head.isPassable() || head.isLiquid()) continue;
            String ft = feet.getType().name();
            if (ft.contains("FIRE") || ft.contains("LAVA")) continue;
            Material bt = below.getType();
            if (!bt.isSolid() || bt == Material.MAGMA_BLOCK || bt == Material.CACTUS) continue;
            Location dest = feet.getLocation().add(0.5, 0, 0.5);
            dest.setYaw(p.getLocation().getYaw());
            dest.setPitch(p.getLocation().getPitch());
            return dest;
        }
        return null;
    }
}
