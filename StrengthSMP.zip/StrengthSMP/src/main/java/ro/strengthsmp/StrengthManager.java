package ro.strengthsmp;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Core progression logic: levels, ranks, milestones, health scaling. */
public class StrengthManager {
    public record Rank(String id, String display, String color, int min, List<String> commands) {
    }

    private final StrengthSMP plugin;
    private final List<Rank> ranks = new ArrayList<>();

    public StrengthManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void loadRanks() {
        ranks.clear();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("ranks");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection r = sec.getConfigurationSection(key);
                if (r == null) continue;
                ranks.add(new Rank(key, r.getString("display", key), r.getString("color", "&f"),
                        r.getInt("min-strength", 0), r.getStringList("commands")));
            }
        }
        ranks.sort(Comparator.comparingInt(Rank::min));
        if (ranks.isEmpty()) ranks.add(new Rank("rookie", "Rookie", "&7", 0, List.of()));
    }

    public int max() {
        return plugin.getConfig().getInt("strength.max-level", 100);
    }

    public int min() {
        return plugin.getConfig().getInt("strength.min-level", 0);
    }

    public Rank rankFor(int strength) {
        Rank best = ranks.get(0);
        for (Rank r : ranks) {
            if (strength >= r.min()) best = r;
        }
        return best;
    }

    public Rank nextRank(int strength) {
        for (Rank r : ranks) {
            if (r.min() > strength) return r;
        }
        return null;
    }

    /** Extra damage from permanent Strength (custom calculation, not the potion effect). */
    public double damageBonus(PlayerData d) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("strength.scale-damage", true)) return 0.0;
        double bonus = d.strength * c.getDouble("strength.damage-per-level", 0.5);
        bonus += d.prestige * c.getDouble("prestige.damage-bonus-per-prestige", 0.5);
        return bonus;
    }

    public void setStrength(Player p, int value, boolean rewards) {
        PlayerData d = plugin.data().get(p);
        int old = d.strength;
        int nv = Math.max(min(), Math.min(max(), value));
        d.strength = nv;
        if (rewards && nv > old) {
            checkRank(p, old, nv);
            checkMilestones(p, d, old, nv);
        }
        refresh(p);
    }

    public void refresh(Player p) {
        applyHealth(p);
        plugin.scoreboards().update(p);
        updateTab(p);
    }

    public void applyHealth(Player p) {
        AttributeInstance attr = p.getAttribute(Util.maxHealth());
        if (attr == null) return;
        FileConfiguration c = plugin.getConfig();
        PlayerData d = plugin.data().get(p);
        double bonus = 0.0;
        if (c.getBoolean("health.scale-health", true)) {
            int step = Math.max(1, c.getInt("health.every-levels", 5));
            double per = c.getDouble("health.bonus-per-step", 2.0);
            double cap = c.getDouble("health.max-bonus", 20.0);
            bonus += Math.min(cap, (d.strength / step) * per);
        }
        bonus += plugin.items().armorStats(p).health();
        double target = Math.max(1.0, Math.min(c.getDouble("health.absolute-max", 100.0), 20.0 + bonus));
        if (Math.abs(attr.getBaseValue() - target) > 0.001) attr.setBaseValue(target);
        if (p.getHealth() > attr.getValue()) p.setHealth(Math.max(0.5, attr.getValue()));
    }

    public void updateTab(Player p) {
        if (!plugin.getConfig().getBoolean("tab-list.enabled", true)) return;
        PlayerData d = plugin.data().get(p);
        Rank r = rankFor(d.strength);
        p.playerListName(Util.color(r.color() + "[" + r.display() + "] &f" + p.getName() + " &7[&c" + d.strength + "&7]"));
    }

    private void checkRank(Player p, int old, int nv) {
        Rank a = rankFor(old);
        Rank b = rankFor(nv);
        if (a.id().equals(b.id())) return;
        p.sendMessage(plugin.msg("rank-up", "rank", b.color() + b.display()));
        p.showTitle(Title.title(Util.color(b.color() + b.display()), Util.color("&7New rank!")));
        for (String cmd : b.commands()) runCommand(cmd, p);
    }

    private void checkMilestones(Player p, PlayerData d, int old, int nv) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("milestones");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            int level;
            try {
                level = Integer.parseInt(key);
            } catch (NumberFormatException ex) {
                continue;
            }
            if (old < level && level <= nv && d.claimedMilestones.add(level)) {
                ConfigurationSection m = sec.getConfigurationSection(key);
                if (m == null) continue;
                String text = m.getString("message", "");
                p.sendMessage(plugin.msg("milestone", "level", level, "text", text));
                for (String cmd : m.getStringList("commands")) runCommand(cmd, p);
                for (String spec : m.getStringList("give-items")) giveItemSpec(p, spec);
            }
        }
    }

    public void giveItemSpec(Player p, String spec) {
        String[] parts = spec.split(":");
        int amount = 1;
        if (parts.length > 1) {
            try {
                amount = Integer.parseInt(parts[1]);
            } catch (NumberFormatException ignored) {
                amount = 1;
            }
        }
        ItemStack item = plugin.items().create(parts[0], amount);
        if (item == null) {
            plugin.getLogger().warning("Unknown item in reward: " + spec);
            return;
        }
        Util.give(p, item);
    }

    private void runCommand(String cmd, Player p) {
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
    }
}
