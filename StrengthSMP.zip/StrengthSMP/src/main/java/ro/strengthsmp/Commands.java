package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class Commands implements CommandExecutor, TabCompleter {
    private final StrengthSMP plugin;
    private final Random random = new Random();

    public Commands(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "strength" -> strengthCmd(sender, args);
            case "ability" -> abilityCmd(sender, args);
            case "withdraw" -> withdrawCmd(sender);
            case "prestige" -> prestigeCmd(sender);
            case "upgrade" -> upgradeCmd(sender);
            case "reroll" -> rerollCmd(sender);
            case "leaderboard" -> leaderboardCmd(sender);
            case "ssmp" -> adminCmd(sender, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    private Player playerOnly(CommandSender s) {
        if (s instanceof Player p) return p;
        s.sendMessage("This command can only be used by players.");
        return null;
    }

    // ---------- /strength ----------

    private void strengthCmd(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 1) {
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                plugin.send(sender, "player-offline");
                return;
            }
        } else {
            target = playerOnly(sender);
            if (target == null) return;
        }
        PlayerData d = plugin.data().get(target);
        StrengthManager sm = plugin.strength();
        StrengthManager.Rank r = sm.rankFor(d.strength);
        StrengthManager.Rank next = sm.nextRank(d.strength);

        sender.sendMessage(Util.color("&8--- &c" + target.getName() + " &8---"));
        sender.sendMessage(Util.color("&fStrength: &c" + d.strength + "&7/" + sm.max()
                + "  &fDamage bonus: &c+" + Util.num(sm.damageBonus(d))));
        sender.sendMessage(Util.color("&fRank: " + r.color() + r.display()
                + (next != null ? " &7(next: " + next.color() + next.display() + " &7at " + next.min() + ")" : " &7(max rank)")));
        sender.sendMessage(Util.color("&fKills: &a" + d.kills + "  &fDeaths: &c" + d.deaths
                + "  &fK/D: &e" + Util.num((double) d.kills / Math.max(1, d.deaths))));
        sender.sendMessage(Util.color("&fKill streak: &6" + d.streak + " &7(best " + d.bestStreak + ")"
                + "  &fTotal gained: &a" + d.totalGained));
        if (plugin.getConfig().getBoolean("prestige.enabled", false)) {
            sender.sendMessage(Util.color("&fPrestige: &d" + d.prestige));
        }
    }

    // ---------- /ability ----------

    private void abilityCmd(CommandSender sender, String[] args) {
        Player p = playerOnly(sender);
        if (p == null) return;
        AbilityManager am = plugin.abilities();
        if (args.length == 0) {
            p.openInventory(new AbilityMenu(plugin, p).getInventory());
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "list" -> {
                for (AbilityManager.Ability a : am.all()) {
                    boolean ok = am.cfg(a.id()).getBoolean("enabled", true) && am.isUnlocked(p, a);
                    p.sendMessage(Util.color((ok ? "&a[x] " : "&7[ ] ") + a.name() + " &8- &7" + a.description()));
                }
            }
            case "select" -> {
                if (args.length < 2) p.sendMessage(Util.color("&cUsage: /ability select <id>"));
                else am.select(p, args[1]);
            }
            case "cycle" -> am.cycle(p);
            case "use" -> {
                String id = args.length > 1 ? args[1] : plugin.data().get(p).selectedAbility;
                if (id == null || id.isEmpty()) plugin.send(p, "ability-none");
                else am.use(p, id, false);
            }
            default -> {
                if (am.get(args[0]) != null) am.use(p, args[0], false);
                else p.sendMessage(Util.color("&cUsage: /ability [list|select <id>|cycle|use [id]|<id>]"));
            }
        }
    }

    // ---------- /withdraw ----------

    private void withdrawCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        if (!plugin.getConfig().getBoolean("crystals.withdraw-enabled", true)) {
            plugin.send(p, "withdraw-disabled");
            return;
        }
        PlayerData d = plugin.data().get(p);
        if (d.strength <= plugin.strength().min()) {
            plugin.send(p, "withdraw-min");
            return;
        }
        ItemStack crystal = plugin.items().create("strength_crystal", 1);
        if (crystal == null) return;
        plugin.strength().setStrength(p, d.strength - 1, false);
        Util.give(p, crystal);
        plugin.send(p, "withdraw-ok", "level", d.strength);
    }

    // ---------- /prestige ----------

    private void prestigeCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("prestige.enabled", false)) {
            plugin.send(p, "prestige-disabled");
            return;
        }
        PlayerData d = plugin.data().get(p);
        if (d.strength < plugin.strength().max()) {
            plugin.send(p, "prestige-need", "max", plugin.strength().max());
            return;
        }
        d.prestige++;
        d.claimedMilestones.clear();
        plugin.strength().setStrength(p, c.getInt("prestige.reset-to", 0), false);
        for (String cmd : c.getStringList("prestige.commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
        }
        plugin.send(p, "prestige-ok", "prestige", d.prestige);
    }

    // ---------- /upgrade /reroll ----------

    private void upgradeCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        ItemManager items = plugin.items();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!items.isUpgradable(hand)) {
            plugin.send(p, "upgrade-invalid");
            return;
        }
        FileConfiguration c = plugin.getConfig();
        int lvl = items.upgradeLevel(hand);
        int max = c.getInt("upgrade.max-level", 5);
        if (lvl >= max) {
            plugin.send(p, "upgrade-max");
            return;
        }
        if (!items.consumeOne(p, "upgrade_stone")) {
            plugin.send(p, "upgrade-no-stone");
            return;
        }
        double chance = Math.max(0.1, c.getDouble("upgrade.base-success-chance", 0.9)
                - lvl * c.getDouble("upgrade.chance-loss-per-level", 0.1));
        // re-read the hand: consuming a stone may have changed the stack we hold
        hand = p.getInventory().getItemInMainHand();
        if (random.nextDouble() < chance) {
            items.setUpgradeLevel(hand, lvl + 1);
            p.getInventory().setItemInMainHand(hand);
            plugin.send(p, "upgrade-ok", "level", lvl + 1);
        } else {
            plugin.send(p, "upgrade-fail");
        }
    }

    private void rerollCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        ItemManager items = plugin.items();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!items.isRerollable(hand)) {
            plugin.send(p, "reroll-invalid");
            return;
        }
        if (!items.consumeOne(p, "reroll_token")) {
            plugin.send(p, "reroll-no-token");
            return;
        }
        hand = p.getInventory().getItemInMainHand();
        items.reroll(hand);
        p.getInventory().setItemInMainHand(hand);
        plugin.send(p, "reroll-ok");
    }

    // ---------- /leaderboard ----------

    private void leaderboardCmd(CommandSender sender) {
        List<PlayerData> top = plugin.data().top(10);
        sender.sendMessage(Util.color("&8--- &cTop Strength &8---"));
        int i = 1;
        for (PlayerData d : top) {
            String name = d.name == null || d.name.isEmpty() ? d.uuid.toString().substring(0, 8) : d.name;
            sender.sendMessage(Util.color("&7" + i + ". &f" + name + " &8- &cStrength " + d.strength
                    + " &7(" + d.kills + " kills)"));
            i++;
        }
    }

    // ---------- /ssmp (admin) ----------

    private void adminCmd(CommandSender sender, String[] args) {
        if (!sender.hasPermission("strengthsmp.admin")) {
            plugin.send(sender, "no-permission");
            return;
        }
        if (args.length == 0) {
            sender.sendMessage(Util.color("&cUsage: /ssmp <set|add|remove|reset|give|unlock|reload> ..."));
            return;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            plugin.reload();
            sender.sendMessage(Util.color("&aStrengthSMP reloaded."));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(Util.color("&cUsage: /ssmp " + sub + " <player> ..."));
            return;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) {
            plugin.send(sender, "player-offline");
            return;
        }
        PlayerData d = plugin.data().get(t);
        StrengthManager sm = plugin.strength();
        switch (sub) {
            case "set", "add", "remove" -> {
                if (args.length < 3) {
                    sender.sendMessage(Util.color("&cUsage: /ssmp " + sub + " <player> <amount>"));
                    return;
                }
                int n;
                try {
                    n = Integer.parseInt(args[2]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage(Util.color("&cThe amount must be a number."));
                    return;
                }
                int value = sub.equals("set") ? n : sub.equals("add") ? d.strength + n : d.strength - n;
                sm.setStrength(t, value, false);
                sender.sendMessage(Util.color("&a" + t.getName() + " now has Strength " + d.strength));
            }
            case "reset" -> {
                sm.setStrength(t, sm.min(), false);
                d.claimedMilestones.clear();
                if (args.length >= 3 && args[2].equalsIgnoreCase("stats")) {
                    d.kills = 0;
                    d.deaths = 0;
                    d.streak = 0;
                    d.bestStreak = 0;
                    d.totalGained = 0;
                    d.prestige = 0;
                    plugin.strength().refresh(t);
                }
                sender.sendMessage(Util.color("&a" + t.getName() + " was reset."));
            }
            case "give" -> {
                if (args.length < 3) {
                    sender.sendMessage(Util.color("&cUsage: /ssmp give <player> <item> [amount]"));
                    return;
                }
                int amount = 1;
                if (args.length >= 4) {
                    try {
                        amount = Math.max(1, Integer.parseInt(args[3]));
                    } catch (NumberFormatException ignored) {
                        amount = 1;
                    }
                }
                ItemStack item = plugin.items().create(args[2], amount);
                if (item == null) {
                    sender.sendMessage(Util.color("&cUnknown item: " + args[2]));
                    return;
                }
                Util.give(t, item);
                sender.sendMessage(Util.color("&aGave " + amount + "x " + args[2] + " to " + t.getName()));
            }
            case "unlock" -> {
                if (args.length < 3 || plugin.abilities().get(args[2]) == null) {
                    sender.sendMessage(Util.color("&cUsage: /ssmp unlock <player> <ability>"));
                    return;
                }
                d.unlocked.add(args[2].toLowerCase(Locale.ROOT));
                plugin.abilities().ensureSelection(t);
                sender.sendMessage(Util.color("&aUnlocked " + args[2] + " for " + t.getName()));
            }
            default -> sender.sendMessage(Util.color("&cUnknown subcommand."));
        }
    }

    // ---------- tab completion ----------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);

        if (name.equals("strength") && args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (name.equals("ability")) {
            if (args.length == 1) {
                out.addAll(List.of("list", "select", "cycle", "use"));
                plugin.abilities().all().forEach(a -> out.add(a.id()));
            } else if (args.length == 2 && (args[0].equalsIgnoreCase("select") || args[0].equalsIgnoreCase("use"))) {
                plugin.abilities().all().forEach(a -> out.add(a.id()));
            }
        } else if (name.equals("ssmp") && sender.hasPermission("strengthsmp.admin")) {
            if (args.length == 1) {
                out.addAll(List.of("set", "add", "remove", "reset", "give", "unlock", "reload"));
            } else if (args.length == 2) {
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
                out.addAll(plugin.items().ids());
                plugin.abilities().all().forEach(a -> out.add("scroll_" + a.id()));
            } else if (args.length == 3 && args[0].equalsIgnoreCase("unlock")) {
                plugin.abilities().all().forEach(a -> out.add(a.id()));
            } else if (args.length == 3 && args[0].equalsIgnoreCase("reset")) {
                out.add("stats");
            }
        }
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
