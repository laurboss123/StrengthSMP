# StrengthSMP 2.4 - Java + Bedrock (Paper + Geyser + Floodgate)

Kill a player = +1 permanent Strength. Ranks, 70 weapon abilities (10 per category), custom weapons/armor,
scrolls, crystals, upgrade/reroll, anti-farm, scoreboard + tab list.

## Versions and dependencies
- Paper 1.21 - 1.21.1 (built against paper-api 1.21.1), Java 21
- Geyser-Spigot + Floodgate-Spigot (geysermc.org/download) for Bedrock players
- The plugin does not call the Geyser/Floodgate API, so it needs no extra dependency
- Paper 1.21.3+: in pom.xml raise the paper-api version and in Util.java change
  Attribute.GENERIC_MAX_HEALTH to Attribute.MAX_HEALTH (one line)

## 1. Build
    mvn package
Result: target/StrengthSMP-2.4.0.jar

## 2. Server
1. Download Paper, rename it paper.jar, put it with server/start.sh in a folder
2. Run ./start.sh once, set eula=true in eula.txt, run again, then stop
3. Put into plugins/: StrengthSMP-2.4.0.jar, Geyser-Spigot.jar, Floodgate-Spigot.jar
4. Start the server. Open TCP 25565 (Java) and UDP 19132 (Bedrock)
5. Java joins on IP:25565, Bedrock on the same IP, port 19132

## Core mechanic
- Valid PvP kill = exactly +1 Strength (melee, bow, crossbow, trident, any projectile)
- No reward for mob kills, void/fall deaths, suicide or duplicate death events
- Strength is kept after death, logout and restart (plugins/StrengthSMP/playerdata/)
- Damage uses a custom calculation (damage-per-level), not the potion effect, so it
  works safely beyond vanilla limits. Max level in config.yml (strength.max-level)
- Optional death penalty, health scaling, prestige, milestones, ranks (all in config.yml)

## Commands
/strength [player]   stats, rank, kills, deaths, K/D, streak, total gained
/ability             chest menu to select an ability
/ability list | select <id> | cycle | use [id] | <id>
/withdraw            1 Strength -> Strength Crystal (right-click = +1)
/prestige            at max Strength (if enabled)
/upgrade /reroll     upgrade or reroll the custom item in your hand
/leaderboard         top 10
/ssmp set|add|remove <player> <n>, reset <player> [stats], give <player> <item> [n],
      unlock <player> <ability>, reload      (permission strengthsmp.admin)

## Using abilities (same on Java and Bedrock)
- Right-click a sword / axe / mace = use the selected ability
- Sneak + right-click = switch to the next ability
- /ability menu or /ability <id> works everywhere
- Optional: swap-hands key (abilities.swap-key: true)
- Items with a bound ability (Heavy Axe, Thunder Sword, Speed Dagger) fire it on right-click
- Unlock by Strength (config) or with a Scroll (/ssmp give <player> scroll_<ability>)

## Java vs Bedrock differences
- Bedrock has no keybinds: abilities use sneak + right-click, the menu or commands
- No resource pack: custom items are vanilla items with names/lore, so Bedrock sees them
- same-ip-check may misfire for Bedrock/LAN players, so it is off by default
- Sidebar, tab list, titles and action bar work through Geyser; looks can differ slightly

## Add a new ability
In AbilityManager.registerDefaults() add:
    register("my_ability", "My Ability", "Description.", Material.DIAMOND, (p, c) -> { ...; return true; });
then add abilities.list.my_ability (cooldown, unlock-strength, ...) to config.yml.

## New in 2.1
- **HUD**: the action bar always shows your selected ability and its cooldown (READY / 5s), active buffs
  (Shield, Berserker...), combat tag and PvP protection. The scoreboard shows Ability + Status too.
- **Kill feed + kill streaks + bounty**: every valid kill is broadcast; streak milestones are announced;
  a player on a streak of `bounty.min-streak` carries a bounty (rewards in config). `/bounty` lists them.
- **Combat log**: logging out while combat-tagged kills you (killer gets credit). Teleport-style commands
  (`combat-commands.blocked`) are blocked in combat.
- **Newbie protection**: new players can't hit or be hit by players for `protection.minutes` of online time.
  `/pvp` shows the status, `/pvp on` ends it early. Existing players are not protected.
- **Teams**: `/team create|invite|accept|leave|kick|disband|info`. No friendly fire (also for abilities),
  team tag in tab and chat.
- **Chat prefix** `[Rank] <Team> Name:` (set `chat.enabled: false` if another plugin formats chat).
- **Seasons**: `/ssmp season <name> confirm` archives the top 25 to `seasons/<name>.yml`, then resets everyone.
- **PlaceholderAPI** (optional): `%strengthsmp_strength%`, `_rank`, `_kills`, `_deaths`, `_kd`, `_streak`,
  `_best_streak`, `_prestige`, `_ability`, `_cooldown`, `_team`, `_bounty`, `_protection`.

Upgrading: stop the server, delete the old `plugins/StrengthSMP/config.yml` (or copy the new sections from
this one), then start. Player data and teams are kept.
If the build fails because the PlaceholderAPI repository is unreachable, delete `StrengthPlaceholders.java`
and the placeholderapi dependency in `pom.xml`; everything else still works.

## New in 2.2: weapon categories + craftable items
- **Weapon category**: every player gets one random category on first join (Sword, Axe, Shield, Trident, Bow,
  Crossbow, Mace). Right-click with a weapon of YOUR category = use the selected ability, sneak + right-click =
  next ability. Bow / crossbow / trident / shield keep their normal right-click. `/category` shows yours,
  `/ssmp category <player> <category>` sets it. `category.enabled: false` in config.yml = old behaviour.
- **Ability Reroll Book** (right-click): new random category (always a different one), book is consumed.
- **Strength Crystal** (+1 Strength, now craftable), **Strength Gift** (look at a player: you -1, they +1, min 1,
  respects max level), **Strength Fragment** (ingredient only), **Strength Protector** (Resistance 5s, 60s cooldown),
  **Strength Tracker** (look at a player to see their Strength), **Dash Core** (dash, consumed).
- Recipes are in items.yml, settings in config.yml (`special-items`). Give with `/ssmp give <player> <id>`:
  ability_reroll_book, strength_crystal, strength_gift, strength_fragment, strength_protector, strength_tracker, dash_core.
- Upgrading from 2.1: delete plugins/StrengthSMP/items.yml (config.yml falls back to the new defaults automatically).

## New in 2.3: every weapon has its own abilities
Each category only sees and uses its own abilities (menu, /ability list, cycling). Rerolling the category
switches the selected ability automatically. Old generic abilities (super_jump, teleport, speed_boost, shield,
invisibility, regeneration, strength_boost) are gone. `lightning` stays as an item-only ability (Thunder Sword).

| Category | Abilities |
|---|---|
| Sword | dash, lifesteal, berserker, shadow_strike, blood_rage, blade_storm, parry, crescent_slash, rending_strike, phantom_step |
| Axe | ground_slam, armor_break, heavy_strike, earthquake, iron_will, cleave, war_cry, executioner, stagger, savage_leap |
| Mace | meteor_smash, gravity_crush, seismic_wave, overcharge, unstoppable, lunge, crater_stomp, skyfall, bone_crusher, thunderclap, dust_storm (11 abilities) |
| Shield | reflect, fortress, shield_bash, counterattack, taunt, aegis, shield_charge, second_wind, last_stand, repel |
| Trident | thunder_throw, tidal_rush, whirlpool, storm_call, water_jet, ocean_blessing, tsunami, poseidon_wrath, kraken_grasp, tempest |
| Bow | piercing_shot, frost_arrow, explosive_arrow, marked_target, poison_arrow, flame_arrow, gale_arrow, lightning_arrow, hunters_leap, arrow_rain |
| Crossbow | multishot_burst, snare_bolt, blast_bolt, execution_bolt, harpoon_bolt, shock_bolt, venom_bolt, thunder_bolt, sniper_bolt, bolt_barrage |

Abilities unlock one at a time: Strength 1 = first ability of your category, Strength 2 = second, ... Strength 10 = tenth.

- Trident / bow / crossbow abilities that change a shot (thunder_throw, whirlpool and all bow/crossbow ones)
  ARM your next shot: right-click starts the cooldown, the next arrow/trident you fire gets the effect.
- Nothing breaks blocks. Explosions and lightning are effects plus damage that respects teams and PvP protection.
- All numbers are in config.yml under abilities.list. Numbers the design doc did not give are marked (guess).
- Upgrading from 2.2: delete plugins/StrengthSMP/config.yml (the abilities section changed).
- Paper 1.21.3+: also change Util.knockbackResistance() to Attribute.KNOCKBACK_RESISTANCE.

## Spawn protection
Square zone centered on the world spawn (`spawn-protection.size: 150` = 75 blocks each way). Inside it: no PvP
(melee, projectiles and abilities). Building is allowed by default (`no-build: false`); set it to true to block
break/place/buckets/fire/explosions (admins always bypass). Move the zone with `/setworldspawn`. All toggles are in config.yml.

## Starter Reroll Book
Every player gets one free Ability Reroll Book the first time they join (also existing players, once).
Turn off with `starter-items.reroll-book: false`.

The action bar and scoreboard show your weapon category (Sword, Shield, ...) next to the selected ability.
Placeholder: `%strengthsmp_category%`.

## New in 2.4
Upgrading from 2.3: delete plugins/StrengthSMP/config.yml and items.yml (many new sections), then start.

- **Romanian (optional)**: `language: ro` in config.yml. Loads plugins/StrengthSMP/lang/ro.yml (all messages, HUD,
  scoreboard, menus). `language: en` = English. Ability names, item names and admin messages stay English.
- **Bedrock forms**: `/ability` opens a native Floodgate form for Bedrock players (abilities, upgrade, daily quests);
  Java players keep the chest menu. Uses reflection, so it falls back to the chest menu if anything is missing.
- **Ability levels**: levels 1-5. Kills with an ability selected raise it (10 x level kills), or `/ability upgrade`
  with an Upgrade Stone. Each level: +10% ability damage, -5% cooldown. Settings: `ability-levels`.
- **Strength loss / Revive**: `death-penalty.enabled: true` removes Strength on death. `elimination.enabled: true`
  eliminates a player who dies at 0 Strength (spectator). New item **Revive Beacon** (craftable): hold it and use
  `/revive <player>`. Admin: `/ssmp revive <player>`.
- **Leaderboard**: `/top [strength|kills|streak|week]`. **Weekly prizes** for the top kills of the week (`weekly`),
  paid automatically (offline winners get them on join). `/ssmp weekly end` pays now.
- **Events**: `/ssmp event bloodmoon [minutes]` (Strength x2 per kill, boss bar) and KOTH
  (`/ssmp koth set [radius]`, then `/ssmp event koth`). Both can run automatically (`auto-interval-minutes`).
- **Duels**: `/duel <player>`, `/duel accept|deny`. No Strength lost, nobody dies. Arena: `/ssmp arena set1|set2`.
- **Daily quests**: `/quests`. Rewards: Upgrade Stones, Strength Crystals, random scrolls (`quests.pool`).
- **Passive bonus per category** (`passive`): sword attack speed, shield knockback resistance, etc.
- **Kill effects by rank** (`cosmetics.kill-effects`): particles and sounds.
- New placeholders: `week_kills`, `duel_wins`, `ability_level`, `eliminated`.
- Arena and KOTH positions are saved in locations.yml, the weekly timer in weekly.yml.
