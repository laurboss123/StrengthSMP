package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Locale;

/**
 * Weekly leaderboard prizes. Every `weekly.length-days` days (default 7) the top players by weekly kills
 * get the rewards from weekly.rewards.<place>, then weekly kills reset. Offline winners receive the prize
 * when they next join. The timer is kept in weekly.yml.
 */
public class WeeklyManager {
    private final StrengthSMP plugin;
    private File file;
    private YamlConfiguration y;
    private long weekStart = 0L;

    public WeeklyManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("weekly.enabled", true);
    }

    public void start() {
        file = new File(plugin.getDataFolder(), "weekly.yml");
        y = YamlConfiguration.loadConfiguration(file);
        weekStart = y.getLong("week-start", 0L);
        if (weekStart <= 0L) {
            weekStart = System.currentTimeMillis();
            save();
        }
        Bukkit.getScheduler().runTaskTimer(plugin, this::check, 1200L, 1200L);
    }

    private void save() {
        y.set("week-start", weekStart);
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save weekly.yml: " + ex.getMessage());
        }
    }

    private long lengthMs() {
        return Math.max(1, plugin.getConfig().getInt("weekly.length-days", 7)) * 86_400_000L;
    }

    /** Milliseconds until the next payout. */
    public long untilReset() {
        return Math.max(0L, weekStart + lengthMs() - System.currentTimeMillis());
    }

    public String untilText() {
        long s = untilReset() / 1000;
        long d = s / 86400;
        long h = (s % 86400) / 3600;
        long m = (s % 3600) / 60;
        return String.format(Locale.ROOT, "%dd %02dh %02dm", d, h, m);
    }

    private void check() {
        if (!enabled()) return;
        if (System.currentTimeMillis() >= weekStart + lengthMs()) payout();
    }

    /** Gives the prizes now and starts a new week. Also used by /ssmp weekly end. */
    public void payout() {
        int places = Math.max(1, plugin.getConfig().getInt("weekly.places", 3));
        List<PlayerData> top = plugin.data().topBy("week", places);
        Bukkit.broadcast(plugin.msg("weekly-ended"));
        int place = 1;
        for (PlayerData d : top) {
            if (d.weekKills <= 0) break;
            ConfigurationSection rs = plugin.getConfig().getConfigurationSection("weekly.rewards." + place);
            String name = d.name == null || d.name.isEmpty() ? d.uuid.toString().substring(0, 8) : d.name;
            Bukkit.broadcast(plugin.msg("weekly-winner", "place", place, "player", name, "kills", d.weekKills));
            if (rs != null) {
                List<String> specs = plugin.rewards().specs(rs);
                Player online = Bukkit.getPlayer(d.uuid);
                if (online != null) {
                    for (String spec : specs) plugin.rewards().deliver(online, spec);
                } else {
                    d.pending.addAll(specs);
                    plugin.data().save(d);
                }
            }
            place++;
        }
        plugin.data().resetWeekly();
        weekStart = System.currentTimeMillis();
        save();
    }
}
