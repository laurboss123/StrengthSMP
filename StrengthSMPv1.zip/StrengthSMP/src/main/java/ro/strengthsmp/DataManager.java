package ro.strengthsmp;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Persistent per-player data: plugins/StrengthSMP/playerdata/<uuid>.yml */
public class DataManager {
    private final StrengthSMP plugin;
    private final File folder;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();

    public DataManager(StrengthSMP plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "playerdata");
        folder.mkdirs();
    }

    public PlayerData get(UUID id) {
        PlayerData d = cache.get(id);
        if (d == null) {
            d = load(id);
            cache.put(id, d);
        }
        return d;
    }

    public PlayerData get(Player p) {
        PlayerData d = get(p.getUniqueId());
        d.name = p.getName();
        return d;
    }

    private File file(UUID id) {
        return new File(folder, id + ".yml");
    }

    private PlayerData load(UUID id) {
        PlayerData d = new PlayerData(id);
        File f = file(id);
        if (f.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            d.name = y.getString("name", "");
            d.strength = y.getInt("strength");
            d.kills = y.getInt("kills");
            d.deaths = y.getInt("deaths");
            d.streak = y.getInt("streak");
            d.bestStreak = y.getInt("best-streak");
            d.totalGained = y.getInt("total-gained");
            d.prestige = y.getInt("prestige");
            d.selectedAbility = y.getString("selected-ability", "");
            d.category = y.getString("category", "");
            d.starterBook = y.getBoolean("starter-book", false);
            d.unlocked.addAll(y.getStringList("unlocked-abilities"));
            d.claimedMilestones.addAll(y.getIntegerList("claimed-milestones"));
            d.protectionSeconds = y.getInt("protection-seconds", 0);
            d.weekKills = y.getInt("week-kills", 0);
            d.duelWins = y.getInt("duel-wins", 0);
            d.duelLosses = y.getInt("duel-losses", 0);
            d.eliminated = y.getBoolean("eliminated", false);
            d.reviveFix = y.getBoolean("revive-fix", false);
            d.questDay = y.getLong("quest-day", -1L);
            d.questDone.addAll(y.getStringList("quest-done"));
            d.pending.addAll(y.getStringList("pending-rewards"));
            readMap(y.getConfigurationSection("quest-progress"), d.questProgress);
            readMap(y.getConfigurationSection("ability-levels"), d.abilityLevels);
            readMap(y.getConfigurationSection("ability-kills"), d.abilityKills);
        } else if (plugin.getConfig().getBoolean("protection.enabled", true)) {
            // brand-new player: starts with PvP protection
            d.protectionSeconds = Math.max(0, plugin.getConfig().getInt("protection.minutes", 30)) * 60;
        }
        return d;
    }

    private static void readMap(ConfigurationSection sec, Map<String, Integer> out) {
        if (sec == null) return;
        for (String k : sec.getKeys(false)) out.put(k, sec.getInt(k));
    }

    private static void writeMap(YamlConfiguration y, String base, Map<String, Integer> map) {
        for (Map.Entry<String, Integer> en : map.entrySet()) y.set(base + "." + en.getKey(), en.getValue());
    }

    public void save(PlayerData d) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("name", d.name);
        y.set("strength", d.strength);
        y.set("kills", d.kills);
        y.set("deaths", d.deaths);
        y.set("streak", d.streak);
        y.set("best-streak", d.bestStreak);
        y.set("total-gained", d.totalGained);
        y.set("prestige", d.prestige);
        y.set("selected-ability", d.selectedAbility);
        y.set("category", d.category);
        y.set("starter-book", d.starterBook);
        y.set("unlocked-abilities", new ArrayList<>(d.unlocked));
        y.set("claimed-milestones", new ArrayList<>(d.claimedMilestones));
        y.set("protection-seconds", d.protectionSeconds);
        y.set("week-kills", d.weekKills);
        y.set("duel-wins", d.duelWins);
        y.set("duel-losses", d.duelLosses);
        y.set("eliminated", d.eliminated);
        y.set("revive-fix", d.reviveFix);
        y.set("quest-day", d.questDay);
        y.set("quest-done", new ArrayList<>(d.questDone));
        y.set("pending-rewards", new ArrayList<>(d.pending));
        writeMap(y, "quest-progress", d.questProgress);
        writeMap(y, "ability-levels", d.abilityLevels);
        writeMap(y, "ability-kills", d.abilityKills);
        try {
            y.save(file(d.uuid));
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save data for " + d.uuid + ": " + ex.getMessage());
        }
    }

    public void saveAll() {
        for (PlayerData d : cache.values()) save(d);
    }

    public void unload(UUID id) {
        PlayerData d = cache.remove(id);
        if (d != null) save(d);
    }

    /** Every known player: cached (online) data first, the rest loaded from disk (not cached). */
    public Collection<PlayerData> allData() {
        Map<UUID, PlayerData> all = new HashMap<>();
        File[] files = folder.listFiles((dir, n) -> n.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                try {
                    UUID id = UUID.fromString(f.getName().substring(0, f.getName().length() - 4));
                    all.put(id, cache.containsKey(id) ? cache.get(id) : load(id));
                } catch (IllegalArgumentException ignored) {
                    // not a player file
                }
            }
        }
        all.putAll(cache);
        return all.values();
    }

    /** Online + offline players, sorted by Strength then kills (used by /leaderboard). */
    public List<PlayerData> top(int limit) {
        return topBy("strength", limit);
    }

    /** Sorted list for the leaderboard: mode = strength | kills | streak | week. */
    public List<PlayerData> topBy(String mode, int limit) {
        List<PlayerData> list = new ArrayList<>(allData());
        Comparator<PlayerData> byStrength = Comparator.comparingInt((PlayerData d) -> d.strength).reversed()
                .thenComparing(Comparator.comparingInt((PlayerData d) -> d.kills).reversed());
        switch (mode) {
            case "kills" -> list.sort(Comparator.comparingInt((PlayerData d) -> d.kills).reversed().thenComparing(byStrength));
            case "streak" -> list.sort(Comparator.comparingInt((PlayerData d) -> d.bestStreak).reversed().thenComparing(byStrength));
            case "week" -> list.sort(Comparator.comparingInt((PlayerData d) -> d.weekKills).reversed().thenComparing(byStrength));
            default -> list.sort(byStrength);
        }
        return list.size() > limit ? new ArrayList<>(list.subList(0, limit)) : list;
    }

    /** Finds a player by last known name (cache first, then disk). The result may be an uncached copy: save it after editing. */
    public PlayerData findByName(String name) {
        for (PlayerData d : cache.values()) {
            if (d.name != null && d.name.equalsIgnoreCase(name)) return d;
        }
        File[] files = folder.listFiles((dir, n) -> n.endsWith(".yml"));
        if (files == null) return null;
        for (File f : files) {
            try {
                UUID id = UUID.fromString(f.getName().substring(0, f.getName().length() - 4));
                PlayerData d = cache.containsKey(id) ? cache.get(id) : load(id);
                if (d.name != null && d.name.equalsIgnoreCase(name)) return d;
            } catch (IllegalArgumentException ignored) {
                // not a player file
            }
        }
        return null;
    }

    /** Loads a player's data without caching it (offline edits). Save it afterwards. */
    public PlayerData peek(UUID id) {
        PlayerData d = cache.get(id);
        return d != null ? d : load(id);
    }

    /** Sets weekly kills back to 0 for everybody (online and offline). */
    public void resetWeekly() {
        File[] files = folder.listFiles((dir, n) -> n.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                UUID id;
                try {
                    id = UUID.fromString(f.getName().substring(0, f.getName().length() - 4));
                } catch (IllegalArgumentException ex) {
                    continue;
                }
                if (cache.containsKey(id)) continue;
                PlayerData d = load(id);
                if (d.weekKills == 0) continue;
                d.weekKills = 0;
                save(d);
            }
        }
        for (PlayerData d : cache.values()) {
            d.weekKills = 0;
            save(d);
        }
    }

    // ---------- seasons ----------

    /** Saves the current top 25 to plugins/StrengthSMP/seasons/<name>.yml. Returns null on failure. */
    public File archiveSeason(String name) {
        File dir = new File(plugin.getDataFolder(), "seasons");
        dir.mkdirs();
        File out = new File(dir, name.replaceAll("[^A-Za-z0-9_-]", "_") + ".yml");
        YamlConfiguration y = new YamlConfiguration();
        int i = 1;
        for (PlayerData d : top(25)) {
            String base = "top." + i++;
            y.set(base + ".name", d.name);
            y.set(base + ".uuid", d.uuid.toString());
            y.set(base + ".strength", d.strength);
            y.set(base + ".kills", d.kills);
            y.set(base + ".deaths", d.deaths);
            y.set(base + ".best-streak", d.bestStreak);
            y.set(base + ".prestige", d.prestige);
        }
        try {
            y.save(out);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save season archive: " + ex.getMessage());
            return null;
        }
        return out;
    }

    /** Resets progress for every known player (online and offline). Returns how many files were reset. */
    public int resetAll(boolean keepPrestige) {
        int count = 0;
        File[] files = folder.listFiles((dir, n) -> n.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                UUID id;
                try {
                    id = UUID.fromString(f.getName().substring(0, f.getName().length() - 4));
                } catch (IllegalArgumentException ex) {
                    continue;
                }
                PlayerData d = cache.get(id);
                boolean cached = d != null;
                if (!cached) d = load(id);
                resetData(d, keepPrestige);
                if (!cached) save(d);
                count++;
            }
        }
        for (PlayerData d : cache.values()) {
            resetData(d, keepPrestige);
            save(d);
        }
        return count;
    }

    private void resetData(PlayerData d, boolean keepPrestige) {
        d.strength = plugin.strength().min();
        d.kills = 0;
        d.deaths = 0;
        d.streak = 0;
        d.bestStreak = 0;
        d.totalGained = 0;
        if (!keepPrestige) d.prestige = 0;
        d.unlocked.clear();
        d.claimedMilestones.clear();
        d.selectedAbility = "";
        d.weekKills = 0;
        d.abilityLevels.clear();
        d.abilityKills.clear();
    }
}
