package ro.strengthsmp;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Persistent per-player data: plugins/StrengthSMP/playerdata/<uuid>.yml */
public class DataManager {
    private final StrengthSMP plugin;
    private final File folder;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();

    public DataManager(StrengthSMP plugin) {
        this.plugin = plugin;
        this.folder = new File(plugin.getDataFolder(), "playerdata");
        folder.mkdirs();
    }

    public PlayerData get(UUID id) {
        PlayerData d = cache.get(id);
        if (d == null) {
            d = load(id);
            cache.put(id, d);
        }
        return d;
    }

    public PlayerData get(Player p) {
        PlayerData d = get(p.getUniqueId());
        d.name = p.getName();
        return d;
    }

    private File file(UUID id) {
        return new File(folder, id + ".yml");
    }

    private PlayerData load(UUID id) {
        PlayerData d = new PlayerData(id);
        File f = file(id);
        if (f.exists()) {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            d.name = y.getString("name", "");
            d.strength = y.getInt("strength");
            d.kills = y.getInt("kills");
            d.deaths = y.getInt("deaths");
            d.streak = y.getInt("streak");
            d.bestStreak = y.getInt("best-streak");
            d.totalGained = y.getInt("total-gained");
            d.prestige = y.getInt("prestige");
            d.selectedAbility = y.getString("selected-ability", "");
            d.category = y.getString("category", "");
            d.starterBook = y.getBoolean("starter-book", false);
            d.unlocked.addAll(y.getStringList("unlocked-abilities"));
            d.claimedMilestones.addAll(y.getIntegerList("claimed-milestones"));
            d.protectionSeconds = y.getInt("protection-seconds", 0);
        } else if (plugin.getConfig().getBoolean("protection.enabled", true)) {
            // brand-new player: starts with PvP protection
            d.protectionSeconds = Math.max(0, plugin.getConfig().getInt("protection.minutes", 30)) * 60;
        }
        return d;
    }

    public void save(PlayerData d) {
        YamlConfiguration y = new YamlConfiguration();
        y.set("name", d.name);
        y.set("strength", d.strength);
        y.set("kills", d.kills);
        y.set("deaths", d.deaths);
        y.set("streak", d.streak);
        y.set("best-streak", d.bestStreak);
        y.set("total-gained", d.totalGained);
        y.set("prestige", d.prestige);
        y.set("selected-ability", d.selectedAbility);
        y.set("category", d.category);
        y.set("starter-book", d.starterBook);
        y.set("unlocked-abilities", new ArrayList<>(d.unlocked));
        y.set("claimed-milestones", new ArrayList<>(d.claimedMilestones));
        y.set("protection-seconds", d.protectionSeconds);
        try {
            y.save(file(d.uuid));
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save data for " + d.uuid + ": " + ex.getMessage());
        }
    }

    public void saveAll() {
        for (PlayerData d : cache.values()) save(d);
    }

    public void unload(UUID id) {
        PlayerData d = cache.remove(id);
        if (d != null) save(d);
    }

    /** Online + offline players, sorted by Strength then kills (used by /leaderboard). */
    public List<PlayerData> top(int limit) {
        Map<UUID, PlayerData> all = new HashMap<>();
        File[] files = folder.listFiles((dir, n) -> n.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                try {
                    UUID id = UUID.fromString(f.getName().substring(0, f.getName().length() - 4));
                    all.put(id, cache.containsKey(id) ? cache.get(id) : load(id));
                } catch (IllegalArgumentException ignored) {
                    // not a player file
                }
            }
        }
        all.putAll(cache);
        List<PlayerData> list = new ArrayList<>(all.values());
        list.sort(Comparator.comparingInt((PlayerData d) -> d.strength).reversed()
                .thenComparing(Comparator.comparingInt((PlayerData d) -> d.kills).reversed()));
        return list.size() > limit ? list.subList(0, limit) : list;
    }

    // ---------- seasons ----------

    /** Saves the current top 25 to plugins/StrengthSMP/seasons/<name>.yml. Returns null on failure. */
    public File archiveSeason(String name) {
        File dir = new File(plugin.getDataFolder(), "seasons");
        dir.mkdirs();
        File out = new File(dir, name.replaceAll("[^A-Za-z0-9_-]", "_") + ".yml");
        YamlConfiguration y = new YamlConfiguration();
        int i = 1;
        for (PlayerData d : top(25)) {
            String base = "top." + i++;
            y.set(base + ".name", d.name);
            y.set(base + ".uuid", d.uuid.toString());
            y.set(base + ".strength", d.strength);
            y.set(base + ".kills", d.kills);
            y.set(base + ".deaths", d.deaths);
            y.set(base + ".best-streak", d.bestStreak);
            y.set(base + ".prestige", d.prestige);
        }
        try {
            y.save(out);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save season archive: " + ex.getMessage());
            return null;
        }
        return out;
    }

    /** Resets progress for every known player (online and offline). Returns how many files were reset. */
    public int resetAll(boolean keepPrestige) {
        int count = 0;
        File[] files = folder.listFiles((dir, n) -> n.endsWith(".yml"));
        if (files != null) {
            for (File f : files) {
                UUID id;
                try {
                    id = UUID.fromString(f.getName().substring(0, f.getName().length() - 4));
                } catch (IllegalArgumentException ex) {
                    continue;
                }
                PlayerData d = cache.get(id);
                boolean cached = d != null;
                if (!cached) d = load(id);
                resetData(d, keepPrestige);
                if (!cached) save(d);
                count++;
            }
        }
        for (PlayerData d : cache.values()) {
            resetData(d, keepPrestige);
            save(d);
        }
        return count;
    }

    private void resetData(PlayerData d, boolean keepPrestige) {
        d.strength = plugin.strength().min();
        d.kills = 0;
        d.deaths = 0;
        d.streak = 0;
        d.bestStreak = 0;
        d.totalGained = 0;
        if (!keepPrestige) d.prestige = 0;
        d.unlocked.clear();
        d.claimedMilestones.clear();
        d.selectedAbility = "";
    }
}
