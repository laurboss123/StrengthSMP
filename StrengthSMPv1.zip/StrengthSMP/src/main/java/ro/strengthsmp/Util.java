package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Locale;
import java.util.Map;

public final class Util {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private Util() {
    }

    /** Max-health attribute. On Paper 1.21.3+ change this single line to Attribute.MAX_HEALTH. */
    public static Attribute maxHealth() {
        return Attribute.GENERIC_MAX_HEALTH;
    }

    /** Knockback-resistance attribute. On Paper 1.21.3+ change this single line to Attribute.KNOCKBACK_RESISTANCE. */
    public static Attribute knockbackResistance() {
        return Attribute.GENERIC_KNOCKBACK_RESISTANCE;
    }

    public static Component color(String s) {
        return LEGACY.deserialize(s == null ? "" : s).decoration(TextDecoration.ITALIC, false);
    }

    public static String fmt(String msg, Object... kv) {
        for (int i = 0; i + 1 < kv.length; i += 2) {
            msg = msg.replace("%" + kv[i] + "%", String.valueOf(kv[i + 1]));
        }
        return msg;
    }

    public static String num(double d) {
        if (d == Math.rint(d)) return String.valueOf((long) d);
        return String.format(Locale.ROOT, "%.2f", d);
    }

    public static void give(Player p, ItemStack item) {
        if (item == null) return;
        Map<Integer, ItemStack> left = p.getInventory().addItem(item);
        left.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
    }
}
