package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Small team system: no friendly fire, team tag in tab/chat. Saved in plugins/StrengthSMP/teams.yml. */
public class TeamManager {

    public static final class Team {
        public final String name;
        public UUID leader;
        public final Map<UUID, String> members = new LinkedHashMap<>();

        Team(String name, UUID leader) {
            this.name = name;
            this.leader = leader;
        }
    }

    private record Invite(String team, long expires) {
    }

    private final StrengthSMP plugin;
    private final File file;
    private final Map<String, Team> teams = new LinkedHashMap<>();
    private final Map<UUID, String> byPlayer = new HashMap<>();
    private final Map<UUID, Invite> invites = new HashMap<>();

    public TeamManager(StrengthSMP plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "teams.yml");
    }

    // ---------- persistence ----------

    public void load() {
        teams.clear();
        byPlayer.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = y.getConfigurationSection("teams");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection s = sec.getConfigurationSection(key);
            if (s == null) continue;
            UUID leader;
            try {
                leader = UUID.fromString(s.getString("leader", ""));
            } catch (IllegalArgumentException ex) {
                continue;
            }
            Team t = new Team(s.getString("name", key), leader);
            ConfigurationSection ms = s.getConfigurationSection("members");
            if (ms != null) {
                for (String uid : ms.getKeys(false)) {
                    try {
                        UUID id = UUID.fromString(uid);
                        t.members.put(id, ms.getString(uid, "?"));
                        byPlayer.put(id, key);
                    } catch (IllegalArgumentException ignored) {
                        // bad entry
                    }
                }
            }
            if (t.members.isEmpty()) continue;
            if (!t.members.containsKey(t.leader)) t.leader = t.members.keySet().iterator().next();
            teams.put(key, t);
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, Team> en : teams.entrySet()) {
            String base = "teams." + en.getKey();
            Team t = en.getValue();
            y.set(base + ".name", t.name);
            y.set(base + ".leader", t.leader.toString());
            for (Map.Entry<UUID, String> m : t.members.entrySet()) {
                y.set(base + ".members." + m.getKey(), m.getValue());
            }
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save teams.yml: " + ex.getMessage());
        }
    }

    // ---------- queries ----------

    public Team teamOf(UUID id) {
        String k = byPlayer.get(id);
        return k == null ? null : teams.get(k);
    }

    public Team byName(String name) {
        return teams.get(name.toLowerCase(Locale.ROOT));
    }

    public boolean sameTeam(Player a, Player b) {
        String x = byPlayer.get(a.getUniqueId());
        return x != null && x.equals(byPlayer.get(b.getUniqueId()));
    }

    public List<String> teamNames() {
        List<String> out = new ArrayList<>();
        for (Team t : teams.values()) out.add(t.name);
        return out;
    }

    private int maxSize() {
        return Math.max(2, plugin.getConfig().getInt("team.max-size", 4));
    }

    /** Keeps the stored name current if the player changed username. */
    public void touch(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t != null) t.members.put(p.getUniqueId(), p.getName());
    }

    private void broadcast(Team t, String key, Object... kv) {
        for (UUID id : t.members.keySet()) {
            Player m = Bukkit.getPlayer(id);
            if (m != null) plugin.send(m, key, kv);
        }
    }

    // ---------- actions ----------

    public void create(Player p, String name) {
        if (teamOf(p.getUniqueId()) != null) {
            plugin.send(p, "team-already-in");
            return;
        }
        if (!name.matches("[A-Za-z0-9]{3,12}")) {
            plugin.send(p, "team-name-invalid");
            return;
        }
        String key = name.toLowerCase(Locale.ROOT);
        if (teams.containsKey(key)) {
            plugin.send(p, "team-name-taken");
            return;
        }
        Team t = new Team(name, p.getUniqueId());
        t.members.put(p.getUniqueId(), p.getName());
        teams.put(key, t);
        byPlayer.put(p.getUniqueId(), key);
        save();
        plugin.send(p, "team-created", "team", name);
        plugin.strength().refresh(p);
    }

    public void invite(Player p, String targetName) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            plugin.send(p, "team-none");
            return;
        }
        if (!t.leader.equals(p.getUniqueId())) {
            plugin.send(p, "team-not-leader");
            return;
        }
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            plugin.send(p, "player-offline");
            return;
        }
        if (target.equals(p) || teamOf(target.getUniqueId()) != null) {
            plugin.send(p, "team-target-in-team", "player", target.getName());
            return;
        }
        if (t.members.size() >= maxSize()) {
            plugin.send(p, "team-full");
            return;
        }
        invites.put(target.getUniqueId(), new Invite(t.name.toLowerCase(Locale.ROOT), System.currentTimeMillis() + 60_000L));
        plugin.send(p, "team-invite-sent", "player", target.getName());
        plugin.send(target, "team-invite-received", "player", p.getName(), "team", t.name);
    }

    public void accept(Player p) {
        Invite inv = invites.remove(p.getUniqueId());
        if (inv == null || System.currentTimeMillis() > inv.expires()) {
            plugin.send(p, "team-no-invite");
            return;
        }
        if (teamOf(p.getUniqueId()) != null) {
            plugin.send(p, "team-already-in");
            return;
        }
        Team t = teams.get(inv.team());
        if (t == null) {
            plugin.send(p, "team-no-invite");
            return;
        }
        if (t.members.size() >= maxSize()) {
            plugin.send(p, "team-full");
            return;
        }
        t.members.put(p.getUniqueId(), p.getName());
        byPlayer.put(p.getUniqueId(), inv.team());
        save();
        broadcast(t, "team-joined", "player", p.getName(), "team", t.name);
        plugin.strength().refresh(p);
    }

    public void leave(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            plugin.send(p, "team-none");
            return;
        }
        removeMember(t, p.getUniqueId());
        plugin.send(p, "team-left", "team", t.name);
        broadcast(t, "team-member-left", "player", p.getName());
    }

    public void kick(Player p, String name) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            plugin.send(p, "team-none");
            return;
        }
        if (!t.leader.equals(p.getUniqueId())) {
            plugin.send(p, "team-not-leader");
            return;
        }
        UUID target = null;
        for (Map.Entry<UUID, String> m : t.members.entrySet()) {
            if (m.getValue().equalsIgnoreCase(name)) target = m.getKey();
        }
        if (target == null || target.equals(p.getUniqueId())) {
            plugin.send(p, "team-not-member", "player", name);
            return;
        }
        Player online = Bukkit.getPlayer(target);
        removeMember(t, target);
        plugin.send(p, "team-kicked", "player", name);
        if (online != null) plugin.send(online, "team-you-kicked", "team", t.name);
    }

    public void disband(Player p) {
        Team t = teamOf(p.getUniqueId());
        if (t == null) {
            plugin.send(p, "team-none");
            return;
        }
        if (!t.leader.equals(p.getUniqueId())) {
            plugin.send(p, "team-not-leader");
            return;
        }
        List<UUID> ids = new ArrayList<>(t.members.keySet());
        teams.remove(t.name.toLowerCase(Locale.ROOT));
        for (UUID id : ids) byPlayer.remove(id);
        save();
        for (UUID id : ids) {
            Player m = Bukkit.getPlayer(id);
            if (m != null) {
                plugin.send(m, "team-disbanded", "team", t.name);
                plugin.strength().refresh(m);
            }
        }
    }

    public void info(CommandSender s, Team t) {
        s.sendMessage(Util.color("&8--- &bTeam " + t.name + " &8---"));
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<UUID, String> m : t.members.entrySet()) {
            if (sb.length() > 0) sb.append("&7, ");
            boolean online = Bukkit.getPlayer(m.getKey()) != null;
            sb.append(online ? "&a" : "&8").append(m.getValue());
            if (m.getKey().equals(t.leader)) sb.append(" &6(leader)");
        }
        s.sendMessage(Util.color("&fMembers (" + t.members.size() + "/" + maxSize() + "): " + sb));
    }

    private void removeMember(Team t, UUID id) {
        t.members.remove(id);
        byPlayer.remove(id);
        String key = t.name.toLowerCase(Locale.ROOT);
        if (t.members.isEmpty()) {
            teams.remove(key);
        } else if (t.leader.equals(id)) {
            t.leader = t.members.keySet().iterator().next();
        }
        save();
        Player op = Bukkit.getPlayer(id);
        if (op != null) plugin.strength().refresh(op);
    }
}
