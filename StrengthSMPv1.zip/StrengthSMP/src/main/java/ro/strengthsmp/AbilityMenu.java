package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Chest GUI for choosing the selected ability (Java players; Bedrock players get a native form when Floodgate is present). */
public class AbilityMenu implements InventoryHolder {
    private final Inventory inv;
    private final List<String> slots = new ArrayList<>();

    public AbilityMenu(StrengthSMP plugin, Player p) {
        inv = Bukkit.createInventory(this, 27, Util.color("&8" + plugin.ui("menu.title", "Abilities")));
        PlayerData d = plugin.data().get(p);
        AbilityManager am = plugin.abilities();
        int i = 0;
        for (AbilityManager.Ability a : am.listFor(p)) {
            if (i >= 27) break;
            ConfigurationSection c = am.cfg(a.id());
            boolean enabled = c.getBoolean("enabled", true);
            boolean unlocked = am.isUnlocked(p, a);
            ItemStack it = new ItemStack(enabled && unlocked ? a.icon() : Material.BARRIER);
            ItemMeta m = it.getItemMeta();
            boolean selected = a.id().equals(d.selectedAbility);
            m.displayName(Util.color((unlocked ? "&a" : "&c") + a.name()
                    + (selected ? " &e[" + plugin.ui("menu.selected", "SELECTED") + "]" : "")));
            List<Component> lore = new ArrayList<>();
            lore.add(Util.color("&7" + a.description()));
            double cd = c.getDouble("cooldown", 10) * (unlocked ? am.cooldownMult(p, a.id()) : 1.0);
            lore.add(Util.color("&7" + plugin.ui("menu.cooldown", "Cooldown") + ": &f" + Util.num(cd) + "s"));
            int need = c.getInt("unlock-strength", 0);
            if (!enabled) {
                lore.add(Util.color("&c" + plugin.ui("menu.disabled", "Disabled by admin")));
            } else if (!unlocked) {
                lore.add(Util.color(need >= 0
                        ? "&c" + plugin.ui("menu.requires", "Requires Strength %n%", "n", need)
                        : "&c" + plugin.ui("menu.scroll", "Unlock with a scroll")));
            } else {
                if (am.levelsEnabled()) {
                    int lvl = am.level(p, a.id());
                    lore.add(Util.color("&7" + plugin.ui("menu.level", "Level") + ": &6" + lvl + "&7/&6" + am.maxLevel()));
                    if (lvl < am.maxLevel()) {
                        lore.add(Util.color("&7" + plugin.ui("menu.progress", "Kills to next level") + ": &f"
                                + d.abilityKills.getOrDefault(a.id(), 0) + "&7/&f" + am.killsNeeded(p, a.id())));
                    }
                }
                lore.add(Util.color("&e" + plugin.ui("menu.click", "Click to select")));
            }
            m.lore(lore);
            it.setItemMeta(m);
            inv.setItem(i, it);
            slots.add(a.id());
            i++;
        }
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }

    public String idAt(int slot) {
        return slot >= 0 && slot < slots.size() ? slots.get(slot) : null;
    }
}
