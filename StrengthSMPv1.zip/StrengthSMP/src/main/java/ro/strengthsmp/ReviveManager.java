package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/**
 * Optional elimination: with elimination.enabled a player who dies (in PvP by default) while at or below
 * elimination.at-strength is out and becomes a spectator, until somebody uses a Revive Beacon on them
 * (/revive <player>) or an admin runs /ssmp revive <player>. Combine it with death-penalty.enabled for a
 * "lose Strength on death, lose everything at zero" server.
 */
public class ReviveManager {
    private final StrengthSMP plugin;

    public ReviveManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("elimination.enabled", false);
    }

    /** Called after a death. strengthBefore = Strength the victim had when they died. */
    public void onDeath(Player victim, int strengthBefore, boolean validPvp) {
        if (!enabled()) return;
        if (plugin.getConfig().getBoolean("elimination.only-pvp", true) && !validPvp) return;
        int threshold = Math.max(plugin.strength().min(), plugin.getConfig().getInt("elimination.at-strength", 0));
        if (strengthBefore > threshold) return;
        PlayerData d = plugin.data().get(victim);
        d.eliminated = true;
        d.streak = 0;
        Bukkit.broadcast(plugin.msg("eliminated", "player", victim.getName()));
    }

    /** Puts eliminated players in spectator mode (called on join and respawn); fixes players revived while offline. */
    public void applyState(Player p) {
        PlayerData d = plugin.data().get(p);
        if (d.eliminated) {
            if (p.getGameMode() != GameMode.SPECTATOR) p.setGameMode(GameMode.SPECTATOR);
            plugin.send(p, "eliminated-notice");
        } else if (d.reviveFix) {
            d.reviveFix = false;
            if (p.getGameMode() == GameMode.SPECTATOR) p.setGameMode(GameMode.SURVIVAL);
            plugin.send(p, "revived-notice");
        }
    }

    /**
     * Revives a player. byPlayer != null: the Revive Beacon in their main hand is consumed.
     * byPlayer == null: admin revive, nothing is consumed.
     */
    public boolean revive(CommandSender sender, Player byPlayer, String name) {
        PlayerData d = plugin.data().findByName(name);
        if (d == null || !d.eliminated) {
            plugin.send(sender, "revive-not-eliminated");
            return false;
        }
        if (byPlayer != null) {
            ItemStack hand = byPlayer.getInventory().getItemInMainHand();
            if (!"revive_beacon".equals(plugin.items().idOf(hand))) {
                plugin.send(byPlayer, "revive-need-beacon");
                return false;
            }
            hand.setAmount(hand.getAmount() - 1);
            byPlayer.getInventory().setItemInMainHand(hand.getAmount() <= 0 ? null : hand);
        }
        int restore = Math.max(plugin.strength().min(),
                Math.min(plugin.strength().max(), plugin.getConfig().getInt("elimination.revive-strength", 1)));
        d.eliminated = false;
        d.streak = 0;
        Player target = Bukkit.getPlayer(d.uuid);
        if (target != null) {
            d.reviveFix = false;
            plugin.strength().setStrength(target, restore, false);
            target.setGameMode(GameMode.SURVIVAL);
            if (byPlayer != null) target.teleport(byPlayer.getLocation());
            plugin.send(target, "revived-notice");
        } else {
            d.strength = restore;
            d.reviveFix = true;
            plugin.data().save(d);
        }
        String who = d.name == null || d.name.isEmpty() ? name : d.name;
        Bukkit.broadcast(plugin.msg("revived", "player", who,
                "by", byPlayer != null ? byPlayer.getName() : sender.getName()));
        return true;
    }
}
