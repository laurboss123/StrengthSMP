package ro.strengthsmp;

import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.GameMode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Server events:
 *  - Blood Moon: every valid kill gives more Strength for a while (events.bloodmoon.strength-multiplier).
 *  - KOTH: stand alone (or with your team) in the zone until the capture bar is full (events.koth).
 * Both can be started by an admin (/ssmp event ...) or automatically (auto-interval-minutes > 0).
 */
public class EventManager {
    private final StrengthSMP plugin;

    // blood moon
    private boolean bloodActive = false;
    private long bloodEnd = 0L;
    private long bloodTotal = 1L;
    private long nextBloodAuto = 0L;
    private BossBar bloodBar;
    private final Set<UUID> bloodShown = new HashSet<>();

    // koth
    private boolean kothActive = false;
    private long kothEnd = 0L;
    private long nextKothAuto = 0L;
    private String holderKey = null;
    private String holderName = "";
    private int progress = 0;
    private BossBar kothBar;
    private final Set<UUID> kothShown = new HashSet<>();

    public EventManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long now = System.currentTimeMillis();
        nextBloodAuto = now + autoMs("events.bloodmoon.auto-interval-minutes");
        nextKothAuto = now + autoMs("events.koth.auto-interval-minutes");
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    public void shutdown() {
        if (bloodActive) stopBloodMoon(false);
        if (kothActive) stopKoth(false);
    }

    private long autoMs(String path) {
        long min = plugin.getConfig().getLong(path, 0L);
        return min <= 0 ? Long.MAX_VALUE / 4 : min * 60_000L;
    }

    // ================= Blood Moon =================

    public boolean bloodActive() {
        return bloodActive;
    }

    /** How much Strength one valid kill gives right now (1 normally). */
    public int strengthGain() {
        if (!bloodActive) return 1;
        return Math.max(1, plugin.getConfig().getInt("events.bloodmoon.strength-multiplier", 2));
    }

    public String bloodLeft() {
        if (!bloodActive) return "";
        return clock(bloodEnd - System.currentTimeMillis());
    }

    public void startBloodMoon(int minutes) {
        if (bloodActive) stopBloodMoon(false);
        int mins = Math.max(1, minutes);
        bloodActive = true;
        bloodTotal = mins * 60_000L;
        bloodEnd = System.currentTimeMillis() + bloodTotal;
        bloodBar = BossBar.bossBar(Util.color("&4Blood Moon"), 1.0f, BossBar.Color.RED, BossBar.Overlay.PROGRESS);
        bloodShown.clear();
        if (plugin.getConfig().getBoolean("events.bloodmoon.set-night", true) && !Bukkit.getWorlds().isEmpty()) {
            Bukkit.getWorlds().get(0).setTime(18000L);
        }
        Bukkit.broadcast(plugin.msg("bloodmoon-start", "minutes", mins, "multiplier", strengthGain()));
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 0.7f);
        }
        updateBlood();
    }

    public void stopBloodMoon(boolean announce) {
        if (!bloodActive) return;
        bloodActive = false;
        if (bloodBar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) p.hideBossBar(bloodBar);
        }
        bloodShown.clear();
        bloodBar = null;
        if (announce) Bukkit.broadcast(plugin.msg("bloodmoon-end"));
        nextBloodAuto = System.currentTimeMillis() + autoMs("events.bloodmoon.auto-interval-minutes");
    }

    private void updateBlood() {
        if (!bloodActive || bloodBar == null) return;
        long left = bloodEnd - System.currentTimeMillis();
        bloodBar.name(Util.color("&4&l" + plugin.ui("event.bloodmoon", "Blood Moon") + " &c- Strength x" + strengthGain()
                + " &7- " + clock(left)));
        bloodBar.progress((float) Math.max(0.0, Math.min(1.0, (double) left / (double) bloodTotal)));
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (bloodShown.add(p.getUniqueId())) p.showBossBar(bloodBar);
        }
    }

    // ================= KOTH =================

    public boolean kothActive() {
        return kothActive;
    }

    public Location kothCenter() {
        if (!plugin.locations().contains("koth.world")) return null;
        World w = Bukkit.getWorld(plugin.locations().getString("koth.world", ""));
        if (w == null) return null;
        return new Location(w, plugin.locations().getDouble("koth.x"), plugin.locations().getDouble("koth.y"),
                plugin.locations().getDouble("koth.z"));
    }

    public double kothRadius() {
        return Math.max(2.0, plugin.locations().getDouble("koth.radius", 8.0));
    }

    public void setKoth(Location l, double radius) {
        plugin.locations().set("koth.world", l.getWorld().getName());
        plugin.locations().set("koth.x", l.getX());
        plugin.locations().set("koth.y", l.getY());
        plugin.locations().set("koth.z", l.getZ());
        plugin.locations().set("koth.radius", radius);
        plugin.saveLocations();
    }

    public boolean startKoth() {
        Location c = kothCenter();
        if (c == null) return false;
        if (kothActive) stopKoth(false);
        kothActive = true;
        holderKey = null;
        holderName = "";
        progress = 0;
        kothEnd = System.currentTimeMillis() + plugin.getConfig().getInt("events.koth.max-minutes", 20) * 60_000L;
        kothBar = BossBar.bossBar(Util.color("&6KOTH"), 0.0f, BossBar.Color.YELLOW, BossBar.Overlay.PROGRESS);
        kothShown.clear();
        Bukkit.broadcast(plugin.msg("koth-start", "x", c.getBlockX(), "y", c.getBlockY(), "z", c.getBlockZ(),
                "seconds", capture()));
        updateKothBar();
        return true;
    }

    public void stopKoth(boolean announce) {
        if (!kothActive) return;
        kothActive = false;
        if (kothBar != null) {
            for (Player p : Bukkit.getOnlinePlayers()) p.hideBossBar(kothBar);
        }
        kothShown.clear();
        kothBar = null;
        if (announce) Bukkit.broadcast(plugin.msg("koth-end"));
        nextKothAuto = System.currentTimeMillis() + autoMs("events.koth.auto-interval-minutes");
    }

    private int capture() {
        return Math.max(5, plugin.getConfig().getInt("events.koth.capture-seconds", 120));
    }

    private void tickKoth() {
        Location c = kothCenter();
        if (c == null || c.getWorld() == null) {
            stopKoth(true);
            return;
        }
        if (System.currentTimeMillis() > kothEnd) {
            stopKoth(true);
            return;
        }
        double r = kothRadius();
        double yRange = plugin.getConfig().getDouble("events.koth.y-range", 12.0);
        Map<String, List<Player>> factions = new LinkedHashMap<>();
        Map<String, String> names = new LinkedHashMap<>();
        for (Player p : c.getWorld().getPlayers()) {
            if (p.isDead() || p.getGameMode() == GameMode.SPECTATOR || p.getGameMode() == GameMode.CREATIVE) continue;
            if (plugin.data().get(p).eliminated) continue;
            Location l = p.getLocation();
            double dx = l.getX() - c.getX();
            double dz = l.getZ() - c.getZ();
            if (dx * dx + dz * dz > r * r || Math.abs(l.getY() - c.getY()) > yRange) continue;
            TeamManager.Team t = plugin.teams().teamOf(p.getUniqueId());
            String key = t != null ? "team:" + t.name.toLowerCase(Locale.ROOT) : "p:" + p.getUniqueId();
            factions.computeIfAbsent(key, k -> new ArrayList<>()).add(p);
            names.putIfAbsent(key, t != null ? t.name : p.getName());
        }

        if (factions.size() == 1) {
            String key = factions.keySet().iterator().next();
            if (!key.equals(holderKey)) {
                holderKey = key;
                holderName = names.get(key);
                progress = 0;
            }
            progress++;
            if (progress >= capture()) {
                win(new ArrayList<>(factions.get(key)), holderName);
                return;
            }
        } else if (factions.isEmpty()) {
            if (progress > 0) progress--;
            if (progress == 0) {
                holderKey = null;
                holderName = "";
            }
        }
        // contested (2+ groups in the zone): nobody progresses

        // zone ring
        World w = c.getWorld();
        int points = 28;
        for (int i = 0; i < points; i++) {
            double a = 2 * Math.PI * i / points;
            w.spawnParticle(Particle.END_ROD, c.getX() + Math.cos(a) * r, c.getY() + 0.6, c.getZ() + Math.sin(a) * r,
                    1, 0, 0, 0, 0);
        }
        updateKothBar(factions.size() > 1);
    }

    private void win(List<Player> winners, String name) {
        FileConfiguration cfg = plugin.getConfig();
        ConfigurationSection rs = cfg.getConfigurationSection("events.koth.rewards");
        for (Player p : winners) {
            plugin.rewards().grant(p, rs);
        }
        Bukkit.broadcast(plugin.msg("koth-won", "winner", name));
        stopKoth(false);
    }

    private void updateKothBar() {
        updateKothBar(false);
    }

    private void updateKothBar(boolean contested) {
        if (!kothActive || kothBar == null) return;
        String who = holderName.isEmpty() ? plugin.ui("event.koth-empty", "empty") : holderName;
        String state = contested ? " &c(" + plugin.ui("event.koth-contested", "contested") + ")" : "";
        kothBar.name(Util.color("&6&lKOTH &e- " + who + " &7" + progress + "/" + capture() + state));
        kothBar.progress((float) Math.max(0.0, Math.min(1.0, (double) progress / (double) capture())));
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (kothShown.add(p.getUniqueId())) p.showBossBar(kothBar);
        }
    }

    // ================= timer =================

    private void tick() {
        long now = System.currentTimeMillis();
        if (bloodActive) {
            if (now >= bloodEnd) stopBloodMoon(true);
            else updateBlood();
        } else if (now >= nextBloodAuto) {
            startBloodMoon(plugin.getConfig().getInt("events.bloodmoon.duration-minutes", 60));
        }
        if (kothActive) {
            tickKoth();
        } else if (now >= nextKothAuto) {
            if (!startKoth()) nextKothAuto = now + autoMs("events.koth.auto-interval-minutes");
        }
    }

    private static String clock(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60);
    }
}
