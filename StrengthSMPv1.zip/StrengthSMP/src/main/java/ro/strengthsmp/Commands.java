package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class Commands implements CommandExecutor, TabCompleter {
    private final StrengthSMP plugin;
    private final Random random = new Random();

    public Commands(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "strength" -> strengthCmd(sender, args);
            case "ability" -> abilityCmd(sender, args);
            case "withdraw" -> withdrawCmd(sender);
            case "prestige" -> prestigeCmd(sender);
            case "upgrade" -> upgradeCmd(sender);
            case "reroll" -> rerollCmd(sender);
            case "leaderboard" -> leaderboardCmd(sender, args);
            case "ssmp" -> adminCmd(sender, args);
            case "pvp" -> pvpCmd(sender, args);
            case "team" -> teamCmd(sender, args);
            case "bounty" -> bountyCmd(sender);
            case "category" -> categoryCmd(sender);
            case "duel" -> duelCmd(sender, args);
            case "quests" -> questsCmd(sender);
            case "revive" -> reviveCmd(sender, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    private Player playerOnly(CommandSender s) {
        if (s instanceof Player p) return p;
        s.sendMessage(plugin.ui("players-only", "This command can only be used by players."));
        return null;
    }

    // ---------- /strength ----------

    private void strengthCmd(CommandSender sender, String[] args) {
        Player target;
        if (args.length >= 1) {
            target = Bukkit.getPlayerExact(args[0]);
            if (target == null) {
                plugin.send(sender, "player-offline");
                return;
            }
        } else {
            target = playerOnly(sender);
            if (target == null) return;
        }
        PlayerData d = plugin.data().get(target);
        StrengthManager sm = plugin.strength();
        StrengthManager.Rank r = sm.rankFor(d.strength);
        StrengthManager.Rank next = sm.nextRank(d.strength);

        sender.sendMessage(Util.color("&8--- &c" + target.getName() + " &8---"));
        sender.sendMessage(Util.color("&f" + plugin.ui("sb.strength", "Strength") + ": &c" + d.strength + "&7/" + sm.max()
                + "  &f" + plugin.ui("cmd.damage-bonus", "Damage bonus") + ": &c+" + Util.num(sm.damageBonus(d))));
        sender.sendMessage(Util.color("&f" + plugin.ui("sb.rank", "Rank") + ": " + r.color() + r.display()
                + (next != null ? " &7(" + plugin.ui("cmd.next", "next") + ": " + next.color() + next.display() + " &7"
                + plugin.ui("cmd.at", "at") + " " + next.min() + ")" : " &7(" + plugin.ui("cmd.max-rank", "max rank") + ")")));
        sender.sendMessage(Util.color("&f" + plugin.ui("sb.kills", "Kills") + ": &a" + d.kills + "  &f" + plugin.ui("sb.deaths", "Deaths")
                + ": &c" + d.deaths + "  &fK/D: &e" + Util.num((double) d.kills / Math.max(1, d.deaths))));
        sender.sendMessage(Util.color("&f" + plugin.ui("cmd.streak", "Kill streak") + ": &6" + d.streak + " &7("
                + plugin.ui("cmd.best", "best") + " " + d.bestStreak + ")"
                + "  &f" + plugin.ui("cmd.total", "Total gained") + ": &a" + d.totalGained));
        sender.sendMessage(Util.color("&f" + plugin.ui("sb.week", "Week kills") + ": &a" + d.weekKills
                + "  &f" + plugin.ui("cmd.duels", "Duels") + ": &a" + d.duelWins + "&7W &c" + d.duelLosses + "&7L"));
        if (plugin.getConfig().getBoolean("prestige.enabled", false)) {
            sender.sendMessage(Util.color("&f" + plugin.ui("sb.prestige", "Prestige") + ": &d" + d.prestige));
        }
        if (plugin.categories().enabled()) {
            sender.sendMessage(Util.color("&f" + plugin.ui("cmd.category", "Weapon category") + ": &e" + CategoryManager.display(d.category)));
        }
    }

    // ---------- /category ----------

    private void categoryCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        if (!plugin.categories().enabled()) {
            plugin.send(p, "category-disabled");
            return;
        }
        plugin.categories().ensure(p);
        plugin.send(p, "category-current", "category", CategoryManager.display(plugin.data().get(p).category));
        String passive = plugin.passives().enabled() ? plugin.passives().describe(plugin.data().get(p).category) : "";
        if (!passive.isEmpty()) plugin.send(p, "category-passive", "passive", passive);
    }

    // ---------- /ability ----------

    private void abilityCmd(CommandSender sender, String[] args) {
        Player p = playerOnly(sender);
        if (p == null) return;
        AbilityManager am = plugin.abilities();
        if (args.length == 0) {
            plugin.forms().openAbilities(p);
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "list" -> {
                for (AbilityManager.Ability a : am.listFor(p)) {
                    boolean ok = am.cfg(a.id()).getBoolean("enabled", true) && am.isUnlocked(p, a);
                    String lvl = ok && am.levelsEnabled() ? " &6Lv" + am.level(p, a.id()) : "";
                    p.sendMessage(Util.color((ok ? "&a[x] " : "&7[ ] ") + a.name() + lvl + " &8- &7" + a.description()));
                }
            }
            case "upgrade" -> am.upgradeWithStone(p, args.length > 1 ? args[1] : plugin.data().get(p).selectedAbility);
            case "select" -> {
                if (args.length < 2) p.sendMessage(Util.color("&cUsage: /ability select <id>"));
                else am.select(p, args[1]);
            }
            case "cycle" -> am.cycle(p);
            case "use" -> {
                String id = args.length > 1 ? args[1] : plugin.data().get(p).selectedAbility;
                if (id == null || id.isEmpty()) plugin.send(p, "ability-none");
                else am.use(p, id, false);
            }
            default -> {
                if (am.get(args[0]) != null) am.use(p, args[0], false);
                else p.sendMessage(Util.color("&cUsage: /ability [list|select <id>|cycle|use [id]|upgrade [id]|<id>]"));
            }
        }
    }

    // ---------- /withdraw ----------

    private void withdrawCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        if (!plugin.getConfig().getBoolean("crystals.withdraw-enabled", true)) {
            plugin.send(p, "withdraw-disabled");
            return;
        }
        PlayerData d = plugin.data().get(p);
        if (d.strength <= plugin.strength().min()) {
            plugin.send(p, "withdraw-min");
            return;
        }
        ItemStack crystal = plugin.items().create("strength_crystal", 1);
        if (crystal == null) return;
        plugin.strength().setStrength(p, d.strength - 1, false);
        Util.give(p, crystal);
        plugin.send(p, "withdraw-ok", "level", d.strength);
    }

    // ---------- /prestige ----------

    private void prestigeCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("prestige.enabled", false)) {
            plugin.send(p, "prestige-disabled");
            return;
        }
        PlayerData d = plugin.data().get(p);
        if (d.strength < plugin.strength().max()) {
            plugin.send(p, "prestige-need", "max", plugin.strength().max());
            return;
        }
        d.prestige++;
        d.claimedMilestones.clear();
        plugin.strength().setStrength(p, c.getInt("prestige.reset-to", 0), false);
        for (String cmd : c.getStringList("prestige.commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", p.getName()));
        }
        plugin.send(p, "prestige-ok", "prestige", d.prestige);
    }

    // ---------- /upgrade /reroll ----------

    private void upgradeCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        ItemManager items = plugin.items();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!items.isUpgradable(hand)) {
            plugin.send(p, "upgrade-invalid");
            return;
        }
        FileConfiguration c = plugin.getConfig();
        int lvl = items.upgradeLevel(hand);
        int max = c.getInt("upgrade.max-level", 5);
        if (lvl >= max) {
            plugin.send(p, "upgrade-max");
            return;
        }
        if (!items.consumeOne(p, "upgrade_stone")) {
            plugin.send(p, "upgrade-no-stone");
            return;
        }
        double chance = Math.max(0.1, c.getDouble("upgrade.base-success-chance", 0.9)
                - lvl * c.getDouble("upgrade.chance-loss-per-level", 0.1));
        // re-read the hand: consuming a stone may have changed the stack we hold
        hand = p.getInventory().getItemInMainHand();
        if (random.nextDouble() < chance) {
            items.setUpgradeLevel(hand, lvl + 1);
            p.getInventory().setItemInMainHand(hand);
            plugin.send(p, "upgrade-ok", "level", lvl + 1);
        } else {
            plugin.send(p, "upgrade-fail");
        }
    }

    private void rerollCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        ItemManager items = plugin.items();
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (!items.isRerollable(hand)) {
            plugin.send(p, "reroll-invalid");
            return;
        }
        if (!items.consumeOne(p, "reroll_token")) {
            plugin.send(p, "reroll-no-token");
            return;
        }
        hand = p.getInventory().getItemInMainHand();
        items.reroll(hand);
        p.getInventory().setItemInMainHand(hand);
        plugin.send(p, "reroll-ok");
    }

    // ---------- /pvp ----------

    private void pvpCmd(CommandSender sender, String[] args) {
        Player p = playerOnly(sender);
        if (p == null) return;
        ProtectionManager pm = plugin.protection();
        if (args.length >= 1 && args[0].equalsIgnoreCase("on")) {
            if (!pm.isProtected(p)) plugin.send(p, "pvp-already-on");
            else pm.end(p, true);
            return;
        }
        if (pm.isProtected(p)) {
            plugin.send(p, "pvp-protected", "time", pm.format(plugin.data().get(p).protectionSeconds));
        } else {
            plugin.send(p, "pvp-on");
        }
    }

    // ---------- /team ----------

    private void teamCmd(CommandSender sender, String[] args) {
        Player p = playerOnly(sender);
        if (p == null) return;
        TeamManager tm = plugin.teams();
        String usage = "&cUsage: /team <create <name>|invite <player>|accept|leave|kick <player>|disband|info [team]>";
        if (args.length == 0) {
            TeamManager.Team t = tm.teamOf(p.getUniqueId());
            if (t == null) p.sendMessage(Util.color(usage));
            else tm.info(p, t);
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> {
                if (args.length < 2) p.sendMessage(Util.color("&cUsage: /team create <name>"));
                else tm.create(p, args[1]);
            }
            case "invite" -> {
                if (args.length < 2) p.sendMessage(Util.color("&cUsage: /team invite <player>"));
                else tm.invite(p, args[1]);
            }
            case "accept" -> tm.accept(p);
            case "leave" -> tm.leave(p);
            case "kick" -> {
                if (args.length < 2) p.sendMessage(Util.color("&cUsage: /team kick <player>"));
                else tm.kick(p, args[1]);
            }
            case "disband" -> tm.disband(p);
            case "info" -> {
                TeamManager.Team t = args.length > 1 ? tm.byName(args[1]) : tm.teamOf(p.getUniqueId());
                if (t == null) plugin.send(p, "team-none");
                else tm.info(p, t);
            }
            default -> p.sendMessage(Util.color(usage));
        }
    }

    // ---------- /bounty ----------

    private void bountyCmd(CommandSender sender) {
        BountyManager bm = plugin.bounty();
        sender.sendMessage(Util.color("&8--- &c" + plugin.ui("cmd.bounties", "Bounties") + " &8---"));
        int n = 0;
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerData d = plugin.data().get(p);
            if (bm.hasBounty(d)) {
                sender.sendMessage(Util.color("&c" + p.getName() + " &7- " + plugin.ui("cmd.streak", "Kill streak") + " &6" + d.streak));
                n++;
            }
        }
        if (n == 0) {
            sender.sendMessage(Util.color("&7" + plugin.ui("cmd.no-bounty", "No active bounties. Reach a kill streak of &6%n% &7to get one.",
                    "n", bm.minStreak())));
        }
    }

    // ---------- /leaderboard (/top) ----------

    private void leaderboardCmd(CommandSender sender, String[] args) {
        String mode = args.length > 0 ? args[0].toLowerCase(Locale.ROOT) : "strength";
        if (!List.of("strength", "kills", "streak", "week").contains(mode)) mode = "strength";
        List<PlayerData> top = plugin.data().topBy(mode, 10);
        String title = switch (mode) {
            case "kills" -> plugin.ui("top.kills", "Top Kills");
            case "streak" -> plugin.ui("top.streak", "Top Kill Streak");
            case "week" -> plugin.ui("top.week", "Top This Week");
            default -> plugin.ui("top.strength", "Top Strength");
        };
        sender.sendMessage(Util.color("&8--- &c" + title + " &8---"));
        int i = 1;
        for (PlayerData d : top) {
            String name = d.name == null || d.name.isEmpty() ? d.uuid.toString().substring(0, 8) : d.name;
            String value = switch (mode) {
                case "kills" -> "&c" + d.kills + " &7" + plugin.ui("sb.kills", "Kills").toLowerCase(Locale.ROOT);
                case "streak" -> "&c" + d.bestStreak + " &7" + plugin.ui("cmd.best", "best");
                case "week" -> "&c" + d.weekKills + " &7" + plugin.ui("sb.kills", "Kills").toLowerCase(Locale.ROOT);
                default -> "&c" + plugin.ui("sb.strength", "Strength") + " " + d.strength + " &7(" + d.kills + " "
                        + plugin.ui("sb.kills", "Kills").toLowerCase(Locale.ROOT) + ")";
            };
            sender.sendMessage(Util.color("&7" + i + ". &f" + name + " &8- " + value));
            i++;
        }
        if (mode.equals("week") && plugin.weekly().enabled()) {
            sender.sendMessage(Util.color("&7" + plugin.ui("top.reset", "Prizes in") + ": &e" + plugin.weekly().untilText()));
        }
    }

    // ---------- /quests ----------

    private void questsCmd(CommandSender sender) {
        Player p = playerOnly(sender);
        if (p == null) return;
        plugin.forms().openQuests(p);
    }

    // ---------- /duel ----------

    private void duelCmd(CommandSender sender, String[] args) {
        Player p = playerOnly(sender);
        if (p == null) return;
        if (args.length == 0) {
            p.sendMessage(Util.color("&cUsage: /duel <player> | accept | deny"));
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "accept" -> plugin.duels().accept(p);
            case "deny" -> plugin.duels().deny(p);
            default -> plugin.duels().challenge(p, args[0]);
        }
    }

    // ---------- /revive ----------

    private void reviveCmd(CommandSender sender, String[] args) {
        Player p = playerOnly(sender);
        if (p == null) return;
        if (!plugin.revive().enabled()) {
            plugin.send(p, "revive-disabled");
            return;
        }
        if (args.length == 0) {
            p.sendMessage(Util.color("&cUsage: /revive <player> (hold a Revive Beacon)"));
            return;
        }
        plugin.revive().revive(p, p, args[0]);
    }

    // ---------- /ssmp (admin) ----------

    private void adminCmd(CommandSender sender, String[] args) {
        if (!sender.hasPermission("strengthsmp.admin")) {
            plugin.send(sender, "no-permission");
            return;
        }
        if (args.length == 0) {
            sender.sendMessage(Util.color("&cUsage: /ssmp <set|add|remove|reset|give|unlock|category|season|event|arena|koth|weekly|revive|reload> ..."));
            return;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            plugin.reload();
            sender.sendMessage(Util.color("&aStrengthSMP reloaded."));
            return;
        }
        if (sub.equals("season")) {
            seasonCmd(sender, args);
            return;
        }
        if (sub.equals("event")) {
            eventCmd(sender, args);
            return;
        }
        if (sub.equals("arena")) {
            arenaCmd(sender, args);
            return;
        }
        if (sub.equals("koth")) {
            kothCmd(sender, args);
            return;
        }
        if (sub.equals("weekly")) {
            if (args.length >= 2 && args[1].equalsIgnoreCase("end")) {
                plugin.weekly().payout();
                sender.sendMessage(Util.color("&aWeekly prizes paid out and a new week started."));
            } else {
                sender.sendMessage(Util.color("&7Next weekly payout in &e" + plugin.weekly().untilText() + "&7. Use &e/ssmp weekly end &7to pay out now."));
            }
            return;
        }
        if (sub.equals("revive")) {
            if (args.length < 2) {
                sender.sendMessage(Util.color("&cUsage: /ssmp revive <player>"));
            } else {
                plugin.revive().revive(sender, null, args[1]);
            }
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(Util.color("&cUsage: /ssmp " + sub + " <player> ..."));
            return;
        }
        Player t = Bukkit.getPlayerExact(args[1]);
        if (t == null) {
            plugin.send(sender, "player-offline");
            return;
        }
        PlayerData d = plugin.data().get(t);
        StrengthManager sm = plugin.strength();
        switch (sub) {
            case "set", "add", "remove" -> {
                if (args.length < 3) {
                    sender.sendMessage(Util.color("&cUsage: /ssmp " + sub + " <player> <amount>"));
                    return;
                }
                int n;
                try {
                    n = Integer.parseInt(args[2]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage(Util.color("&cThe amount must be a number."));
                    return;
                }
                int value = sub.equals("set") ? n : sub.equals("add") ? d.strength + n : d.strength - n;
                sm.setStrength(t, value, false);
                sender.sendMessage(Util.color("&a" + t.getName() + " now has Strength " + d.strength));
            }
            case "reset" -> {
                sm.setStrength(t, sm.min(), false);
                d.claimedMilestones.clear();
                if (args.length >= 3 && args[2].equalsIgnoreCase("stats")) {
                    d.kills = 0;
                    d.deaths = 0;
                    d.streak = 0;
                    d.bestStreak = 0;
                    d.totalGained = 0;
                    d.prestige = 0;
                    plugin.strength().refresh(t);
                }
                sender.sendMessage(Util.color("&a" + t.getName() + " was reset."));
            }
            case "give" -> {
                if (args.length < 3) {
                    sender.sendMessage(Util.color("&cUsage: /ssmp give <player> <item> [amount]"));
                    return;
                }
                int amount = 1;
                if (args.length >= 4) {
                    try {
                        amount = Math.max(1, Integer.parseInt(args[3]));
                    } catch (NumberFormatException ignored) {
                        amount = 1;
                    }
                }
                ItemStack item = plugin.items().create(args[2], amount);
                if (item == null) {
                    sender.sendMessage(Util.color("&cUnknown item: " + args[2]));
                    return;
                }
                Util.give(t, item);
                sender.sendMessage(Util.color("&aGave " + amount + "x " + args[2] + " to " + t.getName()));
            }
            case "category" -> {
                if (args.length < 3 || !CategoryManager.valid(args[2])) {
                    sender.sendMessage(Util.color("&cUsage: /ssmp category <player> <sword|axe|shield|trident|bow|crossbow|mace>"));
                    return;
                }
                plugin.categories().set(t, args[2]);
                plugin.send(t, "category-current", "category", CategoryManager.display(d.category));
                sender.sendMessage(Util.color("&a" + t.getName() + " category is now " + CategoryManager.display(d.category)));
            }
            case "unlock" -> {
                if (args.length < 3 || plugin.abilities().get(args[2]) == null) {
                    sender.sendMessage(Util.color("&cUsage: /ssmp unlock <player> <ability>"));
                    return;
                }
                d.unlocked.add(args[2].toLowerCase(Locale.ROOT));
                plugin.abilities().ensureSelection(t);
                sender.sendMessage(Util.color("&aUnlocked " + args[2] + " for " + t.getName()));
            }
            default -> sender.sendMessage(Util.color("&cUnknown subcommand."));
        }
    }

    private void eventCmd(CommandSender sender, String[] args) {
        String usage = "&cUsage: /ssmp event <bloodmoon [minutes]|koth|stop|status>";
        if (args.length < 2) {
            sender.sendMessage(Util.color(usage));
            return;
        }
        EventManager ev = plugin.events();
        switch (args[1].toLowerCase(Locale.ROOT)) {
            case "bloodmoon" -> {
                int mins = plugin.getConfig().getInt("events.bloodmoon.duration-minutes", 60);
                if (args.length >= 3) {
                    try {
                        mins = Math.max(1, Integer.parseInt(args[2]));
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(Util.color("&cThe minutes must be a number."));
                        return;
                    }
                }
                ev.startBloodMoon(mins);
            }
            case "koth" -> {
                if (!ev.startKoth()) {
                    sender.sendMessage(Util.color("&cNo KOTH zone yet. Stand in the middle of it and run /ssmp koth set [radius]."));
                }
            }
            case "stop" -> {
                ev.stopBloodMoon(true);
                ev.stopKoth(true);
            }
            case "status" -> sender.sendMessage(Util.color("&7Blood Moon: " + (ev.bloodActive() ? "&con (" + ev.bloodLeft() + ")" : "&aoff")
                    + " &8| &7KOTH: " + (ev.kothActive() ? "&con" : "&aoff")));
            default -> sender.sendMessage(Util.color(usage));
        }
    }

    private void arenaCmd(CommandSender sender, String[] args) {
        Player p = playerOnly(sender);
        if (p == null) return;
        if (args.length < 2 || !(args[1].equalsIgnoreCase("set1") || args[1].equalsIgnoreCase("set2"))) {
            sender.sendMessage(Util.color("&cUsage: /ssmp arena <set1|set2> (stand where each duelist should spawn)"));
            return;
        }
        int n = args[1].equalsIgnoreCase("set1") ? 1 : 2;
        plugin.duels().setArena(n, p.getLocation());
        sender.sendMessage(Util.color("&aDuel arena spawn " + n + " saved."));
    }

    private void kothCmd(CommandSender sender, String[] args) {
        Player p = playerOnly(sender);
        if (p == null) return;
        if (args.length < 2 || !args[1].equalsIgnoreCase("set")) {
            sender.sendMessage(Util.color("&cUsage: /ssmp koth set [radius] (stand in the middle of the zone)"));
            return;
        }
        double radius = 8.0;
        if (args.length >= 3) {
            try {
                radius = Math.max(2.0, Double.parseDouble(args[2]));
            } catch (NumberFormatException ex) {
                sender.sendMessage(Util.color("&cThe radius must be a number."));
                return;
            }
        }
        plugin.events().setKoth(p.getLocation(), radius);
        sender.sendMessage(Util.color("&aKOTH zone saved (radius " + Util.num(radius) + "). Start it with /ssmp event koth"));
    }

    private void seasonCmd(CommandSender sender, String[] args) {
        if (args.length < 3 || !args[2].equalsIgnoreCase("confirm")) {
            sender.sendMessage(Util.color("&cThis archives the leaderboard and resets Strength, kills, deaths and abilities for ALL players."));
            sender.sendMessage(Util.color("&cRun: /ssmp season <name> confirm"));
            return;
        }
        java.io.File out = plugin.data().archiveSeason(args[1]);
        if (out == null) {
            sender.sendMessage(Util.color("&cCould not archive the leaderboard. Nothing was reset."));
            return;
        }
        int n = plugin.data().resetAll(plugin.getConfig().getBoolean("season.keep-prestige", true));
        for (Player p : Bukkit.getOnlinePlayers()) {
            plugin.abilities().ensureSelection(p);
            plugin.strength().refresh(p);
        }
        Bukkit.broadcast(plugin.msg("season-ended", "season", args[1]));
        sender.sendMessage(Util.color("&aArchived to seasons/" + out.getName() + " and reset " + n + " players."));
    }

    // ---------- tab completion ----------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);

        if (name.equals("strength") && args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (name.equals("ability")) {
            if (args.length == 1) {
                out.addAll(List.of("list", "select", "cycle", "use", "upgrade"));
                plugin.abilities().all().forEach(a -> out.add(a.id()));
            } else if (args.length == 2 && (args[0].equalsIgnoreCase("select") || args[0].equalsIgnoreCase("use")
                    || args[0].equalsIgnoreCase("upgrade"))) {
                plugin.abilities().all().forEach(a -> out.add(a.id()));
            }
        } else if (name.equals("pvp") && args.length == 1) {
            out.add("on");
        } else if (name.equals("duel") && args.length == 1) {
            out.addAll(List.of("accept", "deny"));
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (name.equals("revive") && args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if ((name.equals("leaderboard")) && args.length == 1) {
            out.addAll(List.of("strength", "kills", "streak", "week"));
        } else if (name.equals("team")) {
            if (args.length == 1) {
                out.addAll(List.of("create", "invite", "accept", "leave", "kick", "disband", "info"));
            } else if (args.length == 2 && (args[0].equalsIgnoreCase("invite") || args[0].equalsIgnoreCase("kick"))) {
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            } else if (args.length == 2 && args[0].equalsIgnoreCase("info")) {
                out.addAll(plugin.teams().teamNames());
            }
        } else if (name.equals("ssmp") && sender.hasPermission("strengthsmp.admin")) {
            if (args.length == 1) {
                out.addAll(List.of("set", "add", "remove", "reset", "give", "unlock", "category", "season",
                        "event", "arena", "koth", "weekly", "revive", "reload"));
            } else if (args.length == 2 && args[0].equalsIgnoreCase("event")) {
                out.addAll(List.of("bloodmoon", "koth", "stop", "status"));
            } else if (args.length == 2 && args[0].equalsIgnoreCase("arena")) {
                out.addAll(List.of("set1", "set2"));
            } else if (args.length == 2 && args[0].equalsIgnoreCase("koth")) {
                out.add("set");
            } else if (args.length == 2 && args[0].equalsIgnoreCase("weekly")) {
                out.add("end");
            } else if (args.length == 2) {
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            } else if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
                out.addAll(plugin.items().ids());
                plugin.abilities().all().forEach(a -> out.add("scroll_" + a.id()));
            } else if (args.length == 3 && args[0].equalsIgnoreCase("unlock")) {
                plugin.abilities().all().forEach(a -> out.add(a.id()));
            } else if (args.length == 3 && args[0].equalsIgnoreCase("category")) {
                out.addAll(CategoryManager.ALL);
            } else if (args.length == 3 && args[0].equalsIgnoreCase("reset")) {
                out.add("stats");
            }
        }
        out.removeIf(s -> !s.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
