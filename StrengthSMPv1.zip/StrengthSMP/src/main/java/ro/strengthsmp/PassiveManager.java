package ro.strengthsmp;

import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlotGroup;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Passive bonus per weapon category, applied as attribute modifiers (config.yml: passive.<category>).
 * Attribute names are looked up through the registry, so they work on any Paper version
 * (attack_speed, knockback_resistance, movement_speed, armor, attack_damage, ...).
 */
public class PassiveManager {
    private record Want(Attribute attr, NamespacedKey key, double amount, AttributeModifier.Operation op) {
    }

    private final StrengthSMP plugin;
    private final String namespace;
    private final Set<String> warned = new HashSet<>();

    public PassiveManager(StrengthSMP plugin) {
        this.plugin = plugin;
        this.namespace = new NamespacedKey(plugin, "x").getNamespace();
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("passive.enabled", true) && plugin.categories().enabled();
    }

    /** Short description of the category passive, for /category. */
    public String describe(String category) {
        if (category == null || category.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (Map<?, ?> m : plugin.getConfig().getMapList("passive." + category)) {
            Object text = m.get("text");
            if (text == null) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(text);
        }
        return plugin.ui("passive." + category, sb.toString());
    }

    private Attribute resolve(String name) {
        String n = name.toLowerCase(Locale.ROOT).replace("generic.", "").replace("generic_", "").replace("player.", "");
        for (String k : new String[]{"generic." + n, n, "player." + n}) {
            try {
                Attribute a = Registry.ATTRIBUTE.get(NamespacedKey.minecraft(k));
                if (a != null) return a;
            } catch (Exception ignored) {
                // invalid key, try the next form
            }
        }
        return null;
    }

    private List<Want> desired(Player p) {
        List<Want> list = new ArrayList<>();
        if (!enabled()) return list;
        String cat = plugin.data().get(p).category;
        if (cat == null || cat.isEmpty()) return list;
        FileConfiguration c = plugin.getConfig();
        int i = 0;
        for (Map<?, ?> m : c.getMapList("passive." + cat)) {
            i++;
            Object an = m.get("attribute");
            Object am = m.get("amount");
            if (an == null || !(am instanceof Number num)) continue;
            Attribute attr = resolve(String.valueOf(an));
            if (attr == null) {
                if (warned.add(String.valueOf(an))) {
                    plugin.getLogger().warning("passive." + cat + ": unknown attribute '" + an + "'");
                }
                continue;
            }
            AttributeModifier.Operation op = AttributeModifier.Operation.ADD_NUMBER;
            Object o = m.get("operation");
            if (o != null) {
                try {
                    op = AttributeModifier.Operation.valueOf(String.valueOf(o).toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException ignored) {
                    // keep ADD_NUMBER
                }
            }
            list.add(new Want(attr, new NamespacedKey(plugin, "passive_" + cat + "_" + i), num.doubleValue(), op));
        }
        return list;
    }

    private boolean ours(AttributeModifier m) {
        NamespacedKey k = m.getKey();
        return k.getNamespace().equals(namespace) && k.getKey().startsWith("passive_");
    }

    /** Adds the passives of the player's category and removes stale ones. Cheap enough to call often. */
    public void apply(Player p) {
        List<Want> want = desired(p);
        for (Attribute a : Registry.ATTRIBUTE) {
            AttributeInstance inst = p.getAttribute(a);
            if (inst == null) continue;
            for (AttributeModifier m : new ArrayList<>(inst.getModifiers())) {
                if (!ours(m)) continue;
                boolean keep = false;
                for (Want w : want) {
                    if (w.attr().equals(a) && w.key().equals(m.getKey())
                            && Math.abs(w.amount() - m.getAmount()) < 1e-9 && w.op() == m.getOperation()) {
                        keep = true;
                        break;
                    }
                }
                if (!keep) inst.removeModifier(m);
            }
        }
        for (Want w : want) {
            AttributeInstance inst = p.getAttribute(w.attr());
            if (inst == null) continue;
            boolean has = false;
            for (AttributeModifier m : inst.getModifiers()) {
                if (w.key().equals(m.getKey())) {
                    has = true;
                    break;
                }
            }
            if (!has) inst.addModifier(new AttributeModifier(w.key(), w.amount(), w.op(), EquipmentSlotGroup.ANY));
        }
    }
}
