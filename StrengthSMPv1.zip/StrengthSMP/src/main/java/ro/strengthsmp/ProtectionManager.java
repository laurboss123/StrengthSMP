package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.Locale;

/** New-player PvP protection. Counts down only while the player is online. */
public class ProtectionManager {
    private final StrengthSMP plugin;

    public ProtectionManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("protection.enabled", true);
    }

    public boolean isProtected(Player p) {
        return enabled() && plugin.data().get(p).protectionSeconds > 0;
    }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    private void tick() {
        if (!enabled()) return;
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerData d = plugin.data().get(p);
            if (d.protectionSeconds <= 0) continue;
            d.protectionSeconds--;
            if (d.protectionSeconds <= 0) end(p, false);
        }
    }

    public void end(Player p, boolean manual) {
        PlayerData d = plugin.data().get(p);
        d.protectionSeconds = 0;
        plugin.send(p, manual ? "protection-ended-manual" : "protection-ended");
        plugin.strength().refresh(p);
    }

    public String format(int seconds) {
        return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
    }
}
