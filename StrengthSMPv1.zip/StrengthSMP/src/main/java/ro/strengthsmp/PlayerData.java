package ro.strengthsmp;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class PlayerData {
    public final UUID uuid;
    public String name = "";
    public int strength;
    public int kills;
    public int deaths;
    public int streak;
    public int bestStreak;
    public int totalGained;
    public int prestige;
    public int protectionSeconds;
    public String selectedAbility = "";
    public final Set<String> unlocked = new HashSet<>();
    public final Set<Integer> claimedMilestones = new HashSet<>();

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }
}
