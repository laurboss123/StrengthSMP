package ro.strengthsmp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class PlayerData {
    public final UUID uuid;
    public String name = "";
    public int strength;
    public int kills;
    public int deaths;
    public int streak;
    public int bestStreak;
    public int totalGained;
    public int prestige;
    public int protectionSeconds;
    public String selectedAbility = "";
    public String category = "";
    public boolean starterBook = false;
    public final Set<String> unlocked = new HashSet<>();
    public final Set<Integer> claimedMilestones = new HashSet<>();

    // ---- v2.4 ----
    public int weekKills;
    public int duelWins;
    public int duelLosses;
    public boolean eliminated;
    public boolean reviveFix;                 // offline revive: put the player back in survival on next join
    public long questDay = -1;
    public final Map<String, Integer> questProgress = new HashMap<>();
    public final Set<String> questDone = new HashSet<>();
    public final Map<String, Integer> abilityLevels = new HashMap<>();
    public final Map<String, Integer> abilityKills = new HashMap<>();
    public final List<String> pending = new ArrayList<>();   // rewards waiting for the player to come online

    public PlayerData(UUID uuid) {
        this.uuid = uuid;
    }
}
