package ro.strengthsmp;

import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.net.InetSocketAddress;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Configurable anti-farming rules for Strength rewards. */
public class AntiFarm {
    private final StrengthSMP plugin;
    private final Map<UUID, Long> lifeStart = new HashMap<>();
    private final Map<String, Deque<Long>> log = new HashMap<>();

    public AntiFarm(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void markLife(Player p) {
        lifeStart.put(p.getUniqueId(), System.currentTimeMillis());
    }

    private String key(Player killer, Player victim) {
        return killer.getUniqueId() + ":" + victim.getUniqueId();
    }

    /** Returns null if the kill is valid, otherwise a short reason. */
    public String check(Player killer, Player victim) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("anti-farm.enabled", true)) return null;
        long now = System.currentTimeMillis();

        if (c.getBoolean("anti-farm.same-ip-check", false) && sameIp(killer, victim)) {
            return "same IP address";
        }

        int minLife = c.getInt("anti-farm.min-victim-life-seconds", 10);
        Long start = lifeStart.get(victim.getUniqueId());
        if (minLife > 0 && start != null && now - start < minLife * 1000L) {
            return "victim just spawned";
        }

        double radius = c.getDouble("anti-farm.spawn-protection-radius", 20.0);
        if (radius > 0) {
            Location sp = victim.getWorld().getSpawnLocation();
            if (victim.getLocation().distance(sp) < radius) return "kill inside the spawn area";
        }

        Deque<Long> dq = log.get(key(killer, victim));
        if (dq != null) {
            long cd = c.getInt("anti-farm.same-victim-cooldown-seconds", 60) * 1000L;
            if (!dq.isEmpty() && now - dq.peekLast() < cd) return "same victim too soon";
            long hourAgo = now - 3_600_000L;
            while (!dq.isEmpty() && dq.peekFirst() < hourAgo) dq.pollFirst();
            if (dq.size() >= c.getInt("anti-farm.max-kills-per-victim-per-hour", 5)) {
                return "kill limit on this victim reached";
            }
        }
        return null;
    }

    public void record(Player killer, Player victim) {
        log.computeIfAbsent(key(killer, victim), k -> new ArrayDeque<>()).addLast(System.currentTimeMillis());
    }

    private boolean sameIp(Player a, Player b) {
        InetSocketAddress x = a.getAddress();
        InetSocketAddress y = b.getAddress();
        return x != null && y != null && x.getAddress() != null && x.getAddress().equals(y.getAddress());
    }
}
