package ro.strengthsmp;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.Locale;

/** PlaceholderAPI: %strengthsmp_strength%, _rank, _kills, _deaths, _kd, _streak, _best_streak, _prestige,
 *  _ability, _category, _cooldown, _team, _bounty, _protection */
public class StrengthPlaceholders extends PlaceholderExpansion {
    private final StrengthSMP plugin;

    public StrengthPlaceholders(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        return "strengthsmp";
    }

    @Override
    public String getAuthor() {
        return "StrengthSMP";
    }

    @Override
    public String getVersion() {
        return plugin.getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (player == null) return "";
        PlayerData d = plugin.data().get(player.getUniqueId());
        Player online = player.getPlayer();
        switch (params.toLowerCase(Locale.ROOT)) {
            case "strength":
                return String.valueOf(d.strength);
            case "rank":
                return plugin.strength().rankFor(d.strength).display();
            case "kills":
                return String.valueOf(d.kills);
            case "deaths":
                return String.valueOf(d.deaths);
            case "kd":
                return Util.num((double) d.kills / Math.max(1, d.deaths));
            case "streak":
                return String.valueOf(d.streak);
            case "best_streak":
                return String.valueOf(d.bestStreak);
            case "prestige":
                return String.valueOf(d.prestige);
            case "category":
                return CategoryManager.display(d.category);
            case "ability": {
                AbilityManager.Ability a = plugin.abilities().get(d.selectedAbility);
                return a == null ? "None" : a.name();
            }
            case "cooldown": {
                if (online == null) return "";
                AbilityManager.Ability a = plugin.abilities().get(d.selectedAbility);
                if (a == null) return "";
                long left = plugin.abilities().cooldownLeft(online, a.id());
                return left > 0 ? HudManager.sec(left) + "s" : "Ready";
            }
            case "team": {
                TeamManager.Team t = plugin.teams().teamOf(d.uuid);
                return t == null ? "" : t.name;
            }
            case "bounty":
                return plugin.bounty().hasBounty(d) ? "yes" : "no";
            case "protection":
                return d.protectionSeconds > 0 ? plugin.protection().format(d.protectionSeconds) : "";
            default:
                return null;
        }
    }
}
