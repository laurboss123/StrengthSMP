package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Sidebar scoreboard (Geyser shows it on Bedrock too). Only rebuilt when the text changes. */
public class ScoreboardManager {
    private final StrengthSMP plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();
    private final Map<UUID, List<String>> last = new HashMap<>();

    public ScoreboardManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void update(Player p) {
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) return;
        if (Bukkit.getScoreboardManager() == null) return;
        PlayerData d = plugin.data().get(p);
        StrengthManager.Rank r = plugin.strength().rankFor(d.strength);

        List<String> lines = new ArrayList<>();
        lines.add("&1 ");
        lines.add("&fStrength: &c" + d.strength);
        lines.add("&fRank: " + r.color() + r.display());
        lines.add("&fPrestige: &d" + d.prestige);
        lines.add("&2 ");
        lines.add("&fKills: &a" + d.kills);
        lines.add("&fDeaths: &c" + d.deaths);
        lines.add("&fStreak: &6" + d.streak + (plugin.bounty().hasBounty(d) ? " &4(Bounty)" : ""));
        lines.add("&3 ");
        String ability = plugin.hud().selectedName(p);
        lines.add("&fAbility: &e" + (ability != null ? ability : "none"));
        if (ability != null) lines.add("&fStatus: " + plugin.hud().statusText(p));
        TeamManager.Team t = plugin.teams().teamOf(p.getUniqueId());
        if (t != null) lines.add("&fTeam: &b" + t.name);
        if (plugin.protection().isProtected(p)) {
            lines.add("&fProtection: &a" + plugin.protection().format(d.protectionSeconds));
        }
        lines.add("&4 ");

        Scoreboard board = boards.computeIfAbsent(p.getUniqueId(), k -> Bukkit.getScoreboardManager().getNewScoreboard());
        if (lines.equals(last.get(p.getUniqueId())) && p.getScoreboard() == board) return;
        last.put(p.getUniqueId(), lines);

        Objective old = board.getObjective("ssmp");
        if (old != null) old.unregister();
        Objective obj = board.registerNewObjective("ssmp", Criteria.DUMMY,
                Util.color(plugin.getConfig().getString("scoreboard.title", "&c&lSTRENGTH SMP")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        int score = lines.size();
        for (String l : lines) {
            obj.getScore(ChatColor.translateAlternateColorCodes('&', l)).setScore(score--);
        }
        p.setScoreboard(board);
    }

    public void remove(UUID id) {
        boards.remove(id);
        last.remove(id);
    }
}
