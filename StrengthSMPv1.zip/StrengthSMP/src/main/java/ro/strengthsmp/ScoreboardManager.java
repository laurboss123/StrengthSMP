package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Sidebar scoreboard (Geyser shows it on Bedrock too). Only rebuilt when the text changes. */
public class ScoreboardManager {
    private final StrengthSMP plugin;
    private final Map<UUID, Scoreboard> boards = new HashMap<>();
    private final Map<UUID, List<String>> last = new HashMap<>();

    public ScoreboardManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void update(Player p) {
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) return;
        if (Bukkit.getScoreboardManager() == null) return;
        PlayerData d = plugin.data().get(p);
        StrengthManager.Rank r = plugin.strength().rankFor(d.strength);

        List<String> lines = new ArrayList<>();
        lines.add("&1 ");
        lines.add("&f" + plugin.ui("sb.strength", "Strength") + ": &c" + d.strength);
        lines.add("&f" + plugin.ui("sb.rank", "Rank") + ": " + r.color() + r.display());
        if (plugin.getConfig().getBoolean("prestige.enabled", false)) {
            lines.add("&f" + plugin.ui("sb.prestige", "Prestige") + ": &d" + d.prestige);
        }
        lines.add("&2 ");
        lines.add("&f" + plugin.ui("sb.kills", "Kills") + ": &a" + d.kills);
        lines.add("&f" + plugin.ui("sb.deaths", "Deaths") + ": &c" + d.deaths);
        lines.add("&f" + plugin.ui("sb.streak", "Streak") + ": &6" + d.streak
                + (plugin.bounty().hasBounty(d) ? " &4(" + plugin.ui("bounty.tag", "Bounty") + ")" : ""));
        lines.add("&f" + plugin.ui("sb.week", "Week kills") + ": &a" + d.weekKills);
        lines.add("&3 ");
        if (plugin.categories().enabled()) {
            lines.add("&f" + plugin.ui("sb.weapon", "Weapon") + ": &6" + CategoryManager.display(d.category));
        }
        String ability = plugin.hud().selectedName(p);
        lines.add("&f" + plugin.ui("sb.ability", "Ability") + ": &e" + (ability != null ? ability : plugin.ui("none", "none")));
        if (ability != null) lines.add("&f" + plugin.ui("sb.status", "Status") + ": " + plugin.hud().statusText(p));
        TeamManager.Team t = plugin.teams().teamOf(p.getUniqueId());
        if (t != null) lines.add("&f" + plugin.ui("sb.team", "Team") + ": &b" + t.name);
        if (plugin.protection().isProtected(p)) {
            lines.add("&f" + plugin.ui("sb.protection", "Protection") + ": &a" + plugin.protection().format(d.protectionSeconds));
        }
        if (plugin.events().bloodActive()) {
            lines.add("&4" + plugin.ui("event.bloodmoon", "Blood Moon") + ": &c" + plugin.events().bloodLeft());
        }

        Scoreboard board = boards.computeIfAbsent(p.getUniqueId(), k -> Bukkit.getScoreboardManager().getNewScoreboard());
        if (lines.equals(last.get(p.getUniqueId())) && p.getScoreboard() == board) return;
        last.put(p.getUniqueId(), lines);

        Objective old = board.getObjective("ssmp");
        if (old != null) old.unregister();
        Objective obj = board.registerNewObjective("ssmp", Criteria.DUMMY,
                Util.color(plugin.getConfig().getString("scoreboard.title", "&c&lSTRENGTH SMP")));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        int score = lines.size();
        for (String l : lines) {
            obj.getScore(ChatColor.translateAlternateColorCodes('&', l)).setScore(score--);
        }
        p.setScoreboard(board);
    }

    public void remove(UUID id) {
        boards.remove(id);
        last.remove(id);
    }
}
