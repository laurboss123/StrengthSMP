package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Square spawn zone (default 150x150, centered on the world spawn point).
 * Inside it: no PvP (including abilities), no building/breaking, no explosions, no fire spread.
 * Admins (strengthsmp.admin) bypass the build rules.
 */
public class SpawnProtection implements Listener {
    private final StrengthSMP plugin;
    private final Map<UUID, Long> lastMsg = new HashMap<>();

    public SpawnProtection(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("spawn-protection.enabled", true);
    }

    private World zoneWorld() {
        String name = plugin.getConfig().getString("spawn-protection.world", "");
        World w = name == null || name.isEmpty() ? null : Bukkit.getWorld(name);
        return w != null ? w : Bukkit.getWorlds().get(0);
    }

    /** True if the location is inside the square zone. */
    public boolean inZone(Location l) {
        if (!enabled() || l == null || l.getWorld() == null) return false;
        World w = zoneWorld();
        if (!l.getWorld().equals(w)) return false;
        double half = plugin.getConfig().getDouble("spawn-protection.size", 150) / 2.0;
        Location c = w.getSpawnLocation();
        return Math.abs(l.getX() - (c.getBlockX() + 0.5)) <= half && Math.abs(l.getZ() - (c.getBlockZ() + 0.5)) <= half;
    }

    /** PvP is blocked if either player stands in the zone. */
    public boolean blocksPvp(Player a, Player b) {
        if (!plugin.getConfig().getBoolean("spawn-protection.no-pvp", true)) return false;
        return inZone(a.getLocation()) || inZone(b.getLocation());
    }

    private boolean denies(Player p, Location l) {
        if (!plugin.getConfig().getBoolean("spawn-protection.no-build", false)) return false;
        if (p.hasPermission("strengthsmp.admin")) return false;
        if (!inZone(l)) return false;
        long now = System.currentTimeMillis();
        Long last = lastMsg.get(p.getUniqueId());
        if (last == null || now - last > 2000) {
            lastMsg.put(p.getUniqueId(), now);
            plugin.hud().flash(p, plugin.raw("spawn-protected"));
        }
        return true;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (denies(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (denies(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent e) {
        if (denies(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent e) {
        if (denies(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent e) {
        if (!plugin.getConfig().getBoolean("spawn-protection.no-build", false) || !inZone(e.getBlock().getLocation())) return;
        if (e.getPlayer() != null) {
            if (denies(e.getPlayer(), e.getBlock().getLocation())) e.setCancelled(true);
        } else {
            e.setCancelled(true); // lava / spread / lightning fire
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent e) {
        if (plugin.getConfig().getBoolean("spawn-protection.no-build", false) && inZone(e.getBlock().getLocation())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent e) {
        if (!plugin.getConfig().getBoolean("spawn-protection.no-build", false)) return;
        e.blockList().removeIf(b -> inZone(b.getLocation()));
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) {
        if (!plugin.getConfig().getBoolean("spawn-protection.no-build", false)) return;
        e.blockList().removeIf(b -> inZone(b.getLocation()));
    }
}
