package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Native Bedrock forms through the Floodgate API. Everything is done with reflection, so the plugin has no
 * compile-time dependency on Floodgate and simply falls back to the chest menu if anything is missing.
 */
public class FormsManager {
    private final StrengthSMP plugin;
    private boolean ready = false;
    private boolean failed = false;
    private Object api;
    private Method isFloodgatePlayer;
    private Method sendForm;
    private Method simpleBuilder;
    private Method bTitle;
    private Method bContent;
    private Method bButton;
    private Method bHandler;
    private Method bBuild;
    private Method clicked;

    public FormsManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("bedrock-forms.enabled", true);
    }

    private boolean init() {
        if (ready) return true;
        if (failed) return false;
        if (Bukkit.getPluginManager().getPlugin("floodgate") == null) {
            failed = true;
            return false;
        }
        try {
            Class<?> apiClass = Class.forName("org.geysermc.floodgate.api.FloodgateApi");
            api = apiClass.getMethod("getInstance").invoke(null);
            if (api == null) return false; // not ready yet, try again later
            Class<?> formClass = Class.forName("org.geysermc.cumulus.form.Form");
            Class<?> simpleForm = Class.forName("org.geysermc.cumulus.form.SimpleForm");
            Class<?> builderClass = Class.forName("org.geysermc.cumulus.form.SimpleForm$Builder");
            Class<?> responseClass = Class.forName("org.geysermc.cumulus.response.SimpleFormResponse");
            isFloodgatePlayer = apiClass.getMethod("isFloodgatePlayer", UUID.class);
            sendForm = apiClass.getMethod("sendForm", UUID.class, formClass);
            simpleBuilder = simpleForm.getMethod("builder");
            bTitle = builderClass.getMethod("title", String.class);
            bContent = builderClass.getMethod("content", String.class);
            bButton = builderClass.getMethod("button", String.class);
            bHandler = builderClass.getMethod("validResultHandler", Consumer.class);
            bBuild = builderClass.getMethod("build");
            clicked = responseClass.getMethod("clickedButtonId");
            ready = true;
            plugin.getLogger().info("Floodgate found: Bedrock players get native forms.");
            return true;
        } catch (Throwable t) {
            failed = true;
            plugin.getLogger().warning("Bedrock forms unavailable (" + t.getClass().getSimpleName()
                    + "), using the chest menu instead.");
            return false;
        }
    }

    public boolean isBedrock(Player p) {
        if (!enabled() || !init()) return false;
        try {
            return (boolean) isFloodgatePlayer.invoke(api, p.getUniqueId());
        } catch (Throwable t) {
            return false;
        }
    }

    /** Sends a simple form. onClick receives the button index and runs on the main server thread. */
    private boolean send(Player p, String title, String content, List<String> buttons, Consumer<Integer> onClick) {
        try {
            Object builder = simpleBuilder.invoke(null);
            bTitle.invoke(builder, color(title));
            bContent.invoke(builder, color(content));
            for (String b : buttons) bButton.invoke(builder, color(b));
            Consumer<Object> handler = response -> {
                try {
                    int id = (int) clicked.invoke(response);
                    Bukkit.getScheduler().runTask(plugin, () -> onClick.accept(id));
                } catch (Throwable ignored) {
                    // form closed or response unreadable
                }
            };
            bHandler.invoke(builder, handler);
            Object form = bBuild.invoke(builder);
            return (boolean) sendForm.invoke(api, p.getUniqueId(), form);
        } catch (Throwable t) {
            plugin.getLogger().warning("Could not send Bedrock form: " + t);
            return false;
        }
    }

    private static String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    // ---------- forms ----------

    /** Opens the ability form for Bedrock players, the chest menu for everybody else. */
    public void openAbilities(Player p) {
        if (isBedrock(p) && abilityForm(p)) return;
        p.openInventory(new AbilityMenu(plugin, p).getInventory());
    }

    private boolean abilityForm(Player p) {
        AbilityManager am = plugin.abilities();
        PlayerData d = plugin.data().get(p);
        List<AbilityManager.Ability> list = am.listFor(p);
        List<String> buttons = new ArrayList<>();
        for (AbilityManager.Ability a : list) {
            ConfigurationSection c = am.cfg(a.id());
            boolean enabled = c.getBoolean("enabled", true);
            boolean unlocked = am.isUnlocked(p, a);
            String tag = a.id().equals(d.selectedAbility) ? " &2[" + plugin.ui("menu.selected", "SELECTED") + "]" : "";
            if (!enabled) {
                buttons.add("&8" + a.name() + "\n&8" + plugin.ui("menu.disabled", "Disabled by admin"));
            } else if (!unlocked) {
                int need = c.getInt("unlock-strength", 0);
                buttons.add("&8" + a.name() + "\n&c" + (need >= 0
                        ? plugin.ui("menu.requires", "Requires Strength %n%", "n", need)
                        : plugin.ui("menu.scroll", "Unlock with a scroll")));
            } else {
                double cd = c.getDouble("cooldown", 10) * am.cooldownMult(p, a.id());
                buttons.add("&0" + a.name() + tag + "\n&8" + plugin.ui("menu.level", "Level") + " " + am.level(p, a.id())
                        + "/" + am.maxLevel() + " - " + Util.num(cd) + "s");
            }
        }
        int upgradeIdx = buttons.size();
        buttons.add("&1" + plugin.ui("form.upgrade", "Upgrade selected ability") + "\n&8" + plugin.ui("form.upgrade-hint", "uses 1 Upgrade Stone"));
        int questIdx = buttons.size();
        buttons.add("&6" + plugin.ui("form.quests", "Daily quests"));

        AbilityManager.Ability sel = am.get(d.selectedAbility);
        String content = plugin.ui("form.category", "Weapon category") + ": " + CategoryManager.display(d.category)
                + "\n" + plugin.ui("form.selected", "Selected") + ": " + (sel != null ? sel.name() : plugin.ui("none", "none"))
                + "\n\n" + plugin.ui("form.pick", "Pick an ability:");
        return send(p, plugin.ui("menu.title", "Abilities"), content, buttons, idx -> {
            if (!p.isOnline()) return;
            if (idx == upgradeIdx) {
                am.upgradeWithStone(p, d.selectedAbility);
            } else if (idx == questIdx) {
                questForm(p);
            } else if (idx >= 0 && idx < list.size()) {
                am.select(p, list.get(idx).id());
            }
        });
    }

    public void openQuests(Player p) {
        if (isBedrock(p) && questForm(p)) return;
        plugin.quests().show(p);
    }

    private boolean questForm(Player p) {
        if (!isBedrock(p)) {
            plugin.quests().show(p);
            return true;
        }
        if (!plugin.quests().enabled()) {
            plugin.send(p, "quests-disabled");
            return true;
        }
        String content = String.join("\n", plugin.quests().lines(p)) + "\n\n&7"
                + plugin.ui("quest.reset", "New quests every day at midnight (server time).");
        List<String> buttons = List.of(plugin.ui("form.back", "Back"));
        return send(p, plugin.ui("quest.title", "Daily quests"), content, buttons, idx -> {
            if (p.isOnline()) openAbilities(p);
        });
    }
}
