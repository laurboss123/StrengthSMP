package ro.strengthsmp;

import io.papermc.paper.chat.ChatRenderer;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.List;
import java.util.Locale;

/** Blocks teleport-style commands in combat and adds the [Rank] / team prefix in chat. */
public class ExtraListener implements Listener {
    private final StrengthSMP plugin;

    public ExtraListener(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        if (!plugin.getConfig().getBoolean("combat-commands.block", true)) return;
        Player p = e.getPlayer();
        if (!plugin.abilities().inCombat(p) || p.hasPermission("strengthsmp.admin")) return;

        String msg = e.getMessage();
        if (msg.length() < 2) return;
        String root = msg.substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        int colon = root.indexOf(':');
        if (colon >= 0) root = root.substring(colon + 1); // essentials:home -> home

        List<String> blocked = plugin.getConfig().getStringList("combat-commands.blocked");
        for (String b : blocked) {
            if (b.equalsIgnoreCase(root)) {
                e.setCancelled(true);
                plugin.send(p, "combat-command-blocked");
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        if (!plugin.getConfig().getBoolean("chat.enabled", true)) return;
        Player p = e.getPlayer();
        PlayerData d = plugin.data().get(p);
        StrengthManager.Rank r = plugin.strength().rankFor(d.strength);
        TeamManager.Team t = plugin.teams().teamOf(p.getUniqueId());

        String pre = r.color() + "[" + r.display() + "] ";
        if (t != null) pre += "&8<" + t.name + "> ";
        Component prefix = Util.color(pre);

        e.renderer(ChatRenderer.viewerUnaware((source, name, message) ->
                prefix.append(name).append(Component.text(": ", NamedTextColor.GRAY)).append(message)));
    }
}
