package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.potion.PotionEffect;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * 1v1 duels for training. Nobody dies: the lethal hit is cancelled and the duel ends. No Strength is lost or gained,
 * no combat tag, no drops. Both players go to the arena (/ssmp arena set1 | set2) and come back afterwards.
 */
public class DuelManager implements Listener {
    private static final class Duel {
        final UUID a;
        final UUID b;
        Location backA;
        Location backB;
        boolean started = false;
        long endAt;

        Duel(UUID a, UUID b) {
            this.a = a;
            this.b = b;
        }

        boolean has(UUID id) {
            return a.equals(id) || b.equals(id);
        }

        UUID other(UUID id) {
            return a.equals(id) ? b : a;
        }
    }

    private final StrengthSMP plugin;
    private final Map<UUID, Duel> duels = new HashMap<>();
    private final Map<UUID, UUID> requests = new HashMap<>();      // target -> challenger
    private final Map<UUID, Long> requestExpiry = new HashMap<>(); // target -> time
    private final Map<UUID, Location> returnLocs = new HashMap<>(); // players who left during a duel

    public DuelManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("duel.enabled", true);
    }

    public void start() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    public boolean inDuel(Player p) {
        return duels.containsKey(p.getUniqueId());
    }

    /** True if both players are fighting each other in a duel. */
    public boolean together(Player a, Player b) {
        Duel d = duels.get(a.getUniqueId());
        return d != null && d.has(b.getUniqueId());
    }

    // ---------- arena ----------

    public Location arena(int n) {
        String base = "arena.spawn" + n;
        if (!plugin.locations().contains(base + ".world")) return null;
        World w = Bukkit.getWorld(plugin.locations().getString(base + ".world", ""));
        if (w == null) return null;
        return new Location(w, plugin.locations().getDouble(base + ".x"), plugin.locations().getDouble(base + ".y"),
                plugin.locations().getDouble(base + ".z"), (float) plugin.locations().getDouble(base + ".yaw"),
                (float) plugin.locations().getDouble(base + ".pitch"));
    }

    public void setArena(int n, Location l) {
        String base = "arena.spawn" + n;
        plugin.locations().set(base + ".world", l.getWorld().getName());
        plugin.locations().set(base + ".x", l.getX());
        plugin.locations().set(base + ".y", l.getY());
        plugin.locations().set(base + ".z", l.getZ());
        plugin.locations().set(base + ".yaw", l.getYaw());
        plugin.locations().set(base + ".pitch", l.getPitch());
        plugin.saveLocations();
    }

    // ---------- requests ----------

    public void challenge(Player p, String targetName) {
        if (!enabled()) {
            plugin.send(p, "duel-disabled");
            return;
        }
        Player t = Bukkit.getPlayerExact(targetName);
        if (t == null || t.equals(p)) {
            plugin.send(p, "player-offline");
            return;
        }
        if (inDuel(p) || inDuel(t)) {
            plugin.send(p, "duel-busy");
            return;
        }
        if (plugin.data().get(p).eliminated || plugin.data().get(t).eliminated) {
            plugin.send(p, "duel-busy");
            return;
        }
        requests.put(t.getUniqueId(), p.getUniqueId());
        requestExpiry.put(t.getUniqueId(), System.currentTimeMillis() + plugin.getConfig().getInt("duel.request-seconds", 30) * 1000L);
        plugin.send(p, "duel-sent", "player", t.getName());
        plugin.send(t, "duel-received", "player", p.getName());
    }

    public void accept(Player p) {
        UUID from = requests.get(p.getUniqueId());
        Long exp = requestExpiry.get(p.getUniqueId());
        requests.remove(p.getUniqueId());
        requestExpiry.remove(p.getUniqueId());
        Player c = from == null ? null : Bukkit.getPlayer(from);
        if (c == null || exp == null || System.currentTimeMillis() > exp) {
            plugin.send(p, "duel-no-request");
            return;
        }
        if (inDuel(p) || inDuel(c)) {
            plugin.send(p, "duel-busy");
            return;
        }
        begin(c, p);
    }

    public void deny(Player p) {
        UUID from = requests.remove(p.getUniqueId());
        requestExpiry.remove(p.getUniqueId());
        if (from == null) {
            plugin.send(p, "duel-no-request");
            return;
        }
        Player c = Bukkit.getPlayer(from);
        plugin.send(p, "duel-denied-self");
        if (c != null) plugin.send(c, "duel-denied", "player", p.getName());
    }

    // ---------- fight ----------

    private void begin(Player a, Player b) {
        Duel d = new Duel(a.getUniqueId(), b.getUniqueId());
        d.backA = a.getLocation();
        d.backB = b.getLocation();
        d.endAt = System.currentTimeMillis() + plugin.getConfig().getInt("duel.max-seconds", 300) * 1000L + 5000L;
        duels.put(a.getUniqueId(), d);
        duels.put(b.getUniqueId(), d);

        for (Player p : new Player[]{a, b}) {
            plugin.abilities().endCombat(p);
            plugin.abilities().clearBuffs(p);
            plugin.abilities().resetCooldowns(p.getUniqueId());
            heal(p);
        }
        Location s1 = arena(1);
        Location s2 = arena(2);
        if (s1 != null && s2 != null) {
            a.teleport(s1);
            b.teleport(s2);
        } else {
            plugin.send(a, "duel-no-arena");
            plugin.send(b, "duel-no-arena");
        }
        plugin.send(a, "duel-start", "player", b.getName());
        plugin.send(b, "duel-start", "player", a.getName());

        for (int i = 3; i >= 1; i--) {
            final int n = i;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (duels.get(d.a) != d) return;
                for (UUID id : new UUID[]{d.a, d.b}) {
                    Player p = Bukkit.getPlayer(id);
                    if (p != null) p.showTitle(Title.title(Util.color("&e" + n), Component.empty()));
                }
            }, (3 - i) * 20L);
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (duels.get(d.a) != d) return;
            d.started = true;
            for (UUID id : new UUID[]{d.a, d.b}) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) p.showTitle(Title.title(Util.color("&c" + plugin.ui("duel.fight", "FIGHT!")), Component.empty()));
            }
        }, 60L);
    }

    private void heal(Player p) {
        AttributeInstance mh = p.getAttribute(Util.maxHealth());
        double max = mh != null ? mh.getValue() : 20.0;
        p.setHealth(Math.max(1.0, max));
        p.setFoodLevel(20);
        p.setFireTicks(0);
        for (PotionEffect pe : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(pe.getType());
    }

    /** Ends a duel. winner == null means a draw. */
    private void end(Duel d, UUID winner, boolean countStats) {
        if (duels.get(d.a) != d) return;
        duels.remove(d.a);
        duels.remove(d.b);
        for (UUID id : new UUID[]{d.a, d.b}) {
            Location back = id.equals(d.a) ? d.backA : d.backB;
            Player p = Bukkit.getPlayer(id);
            if (p == null) {
                if (back != null) returnLocs.put(id, back);
                continue;
            }
            if (p.isDead()) continue;
            heal(p);
            plugin.abilities().clearBuffs(p);
            plugin.abilities().resetCooldowns(id);
            if (back != null && Bukkit.getWorld(back.getWorld().getName()) != null) p.teleport(back);
        }
        Player w = winner == null ? null : Bukkit.getPlayer(winner);
        UUID loserId = winner == null ? null : d.other(winner);
        Player l = loserId == null ? null : Bukkit.getPlayer(loserId);
        String wn = w != null ? w.getName() : nameOf(winner);
        String ln = l != null ? l.getName() : nameOf(loserId);
        if (winner == null) {
            for (UUID id : new UUID[]{d.a, d.b}) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) plugin.send(p, "duel-draw");
            }
            return;
        }
        if (countStats) {
            PlayerData wd = plugin.data().peek(winner);
            wd.duelWins++;
            if (w == null) plugin.data().save(wd);
            if (loserId != null) {
                PlayerData ld = plugin.data().peek(loserId);
                ld.duelLosses++;
                if (l == null) plugin.data().save(ld);
            }
        }
        Bukkit.broadcast(plugin.msg("duel-won", "winner", wn, "loser", ln));
    }

    private String nameOf(UUID id) {
        if (id == null) return "?";
        PlayerData pd = plugin.data().peek(id);
        return pd.name == null || pd.name.isEmpty() ? id.toString().substring(0, 8) : pd.name;
    }

    private void tick() {
        long now = System.currentTimeMillis();
        for (Duel d : new HashSet<>(duels.values())) {
            if (now > d.endAt) end(d, null, false);
        }
        for (Map.Entry<UUID, Long> en : new ArrayList<>(requestExpiry.entrySet())) {
            if (now > en.getValue()) {
                requestExpiry.remove(en.getKey());
                requests.remove(en.getKey());
            }
        }
    }

    // ---------- events ----------

    /** A lethal hit (or fall / void) during a duel ends it instead of killing the player. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player v)) return;
        Duel d = duels.get(v.getUniqueId());
        if (d == null) return;
        if (!d.started) {
            e.setCancelled(true);
            return;
        }
        if (e.getFinalDamage() >= v.getHealth()) {
            e.setCancelled(true);
            end(d, d.other(v.getUniqueId()), true);
        }
    }

    /** Called from CombatListener if a duelist dies anyway (for example a /kill). The duel just ends. */
    public void onDeath(Player victim) {
        Duel d = duels.get(victim.getUniqueId());
        if (d != null) end(d, d.other(victim.getUniqueId()), false);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        requests.remove(p.getUniqueId());
        requestExpiry.remove(p.getUniqueId());
        Duel d = duels.get(p.getUniqueId());
        if (d != null) end(d, d.other(p.getUniqueId()), true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Location back = returnLocs.remove(e.getPlayer().getUniqueId());
        if (back != null && back.getWorld() != null && e.getPlayer().getGameMode() != GameMode.SPECTATOR) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> e.getPlayer().teleport(back), 2L);
        }
    }
}
