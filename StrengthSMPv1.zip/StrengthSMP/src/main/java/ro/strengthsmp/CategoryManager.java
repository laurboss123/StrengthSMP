package ro.strengthsmp;

import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Weapon categories. Every player gets one random category on first join.
 * The category decides which weapon fires the selected ability on right-click.
 */
public class CategoryManager {
    public static final List<String> ALL = List.of("sword", "axe", "shield", "trident", "bow", "crossbow", "mace");

    private final StrengthSMP plugin;
    private final Random random = new Random();

    public CategoryManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("category.enabled", true);
    }

    public static boolean valid(String id) {
        return id != null && ALL.contains(id.toLowerCase(Locale.ROOT));
    }

    public static String display(String id) {
        if (id == null || id.isEmpty()) return "None";
        return id.substring(0, 1).toUpperCase(Locale.ROOT) + id.substring(1).toLowerCase(Locale.ROOT);
    }

    /** Gives the player a random category if they have none yet. */
    public void ensure(Player p) {
        if (!enabled()) return;
        PlayerData d = plugin.data().get(p);
        if (valid(d.category)) return;
        d.category = ALL.get(random.nextInt(ALL.size()));
        plugin.send(p, "category-assigned", "category", display(d.category));
    }

    /** Picks a new random category, always different from the current one. Returns the new one. */
    public String reroll(Player p) {
        PlayerData d = plugin.data().get(p);
        List<String> pool = new ArrayList<>(ALL);
        pool.remove(d.category);
        d.category = pool.get(random.nextInt(pool.size()));
        plugin.abilities().ensureSelection(p);
        return d.category;
    }

    public void set(Player p, String id) {
        plugin.data().get(p).category = id.toLowerCase(Locale.ROOT);
        plugin.abilities().ensureSelection(p);
    }

    /** Ranged / blocking categories must not cancel the vanilla right-click (drawing a bow, raising a shield). */
    public static boolean keepsVanillaUse(String category) {
        return category.equals("bow") || category.equals("crossbow")
                || category.equals("trident") || category.equals("shield");
    }

    public static boolean matches(String category, Material t) {
        if (category == null) return false;
        return switch (category) {
            case "sword" -> t.name().endsWith("_SWORD");
            case "axe" -> t.name().endsWith("_AXE");
            case "mace" -> t == Material.MACE;
            case "trident" -> t == Material.TRIDENT;
            case "bow" -> t == Material.BOW;
            case "crossbow" -> t == Material.CROSSBOW;
            case "shield" -> t == Material.SHIELD;
            default -> false;
        };
    }
}
