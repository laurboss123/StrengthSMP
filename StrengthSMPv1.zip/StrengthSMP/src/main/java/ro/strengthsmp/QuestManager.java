package ro.strengthsmp;

import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Daily quests. Every day the same set of quests is picked for everybody from quests.pool.
 * Types: KILL_PLAYERS, USE_ABILITY, DAMAGE_PLAYERS (hit points dealt), KILL_MOBS.
 * Rewards use the shared reward format (give-items / strength / commands).
 */
public class QuestManager implements Listener {
    public record Quest(String id, String type, int amount, String name, ConfigurationSection rewards) {
    }

    private final StrengthSMP plugin;
    private long cachedDay = -1;
    private List<Quest> cached = new ArrayList<>();

    public QuestManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("quests.enabled", true);
    }

    public long today() {
        return LocalDate.now().toEpochDay();
    }

    public void invalidate() {
        cachedDay = -1;
    }

    /** Today's quests (same for every player). */
    public List<Quest> daily() {
        long day = today();
        if (day == cachedDay) return cached;
        List<Quest> all = new ArrayList<>();
        ConfigurationSection pool = plugin.getConfig().getConfigurationSection("quests.pool");
        if (pool != null) {
            for (String id : pool.getKeys(false)) {
                ConfigurationSection s = pool.getConfigurationSection(id);
                if (s == null) continue;
                all.add(new Quest(id, s.getString("type", "KILL_PLAYERS").toUpperCase(Locale.ROOT),
                        Math.max(1, s.getInt("amount", 1)), s.getString("name", id),
                        s.getConfigurationSection("rewards")));
            }
        }
        int count = Math.max(1, plugin.getConfig().getInt("quests.daily-count", 3));
        if (all.size() > count) {
            Collections.shuffle(all, new Random(day * 31L + 7L));
            all = new ArrayList<>(all.subList(0, count));
        }
        cached = all;
        cachedDay = day;
        return cached;
    }

    public String name(Quest q) {
        return plugin.ui("quest." + q.id(), q.name());
    }

    /** Resets the player's quest progress when a new day has started. */
    public void ensureDay(PlayerData d) {
        long day = today();
        if (d.questDay != day) {
            d.questDay = day;
            d.questProgress.clear();
            d.questDone.clear();
        }
    }

    public void add(Player p, String type, int amount) {
        if (!enabled() || amount <= 0) return;
        PlayerData d = plugin.data().get(p);
        ensureDay(d);
        for (Quest q : daily()) {
            if (!q.type().equals(type) || d.questDone.contains(q.id())) continue;
            int now = d.questProgress.merge(q.id(), amount, Integer::sum);
            if (now >= q.amount()) complete(p, d, q);
        }
    }

    private void complete(Player p, PlayerData d, Quest q) {
        d.questDone.add(q.id());
        plugin.send(p, "quest-complete", "quest", name(q));
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.2f);
        plugin.rewards().grant(p, q.rewards());
    }

    /** Chat-formatted quest list (also used by the Bedrock form). */
    public List<String> lines(Player p) {
        List<String> out = new ArrayList<>();
        PlayerData d = plugin.data().get(p);
        ensureDay(d);
        for (Quest q : daily()) {
            boolean done = d.questDone.contains(q.id());
            int prog = Math.min(q.amount(), d.questProgress.getOrDefault(q.id(), 0));
            if (done) {
                out.add("&a[x] &f" + name(q) + " &8- &a" + plugin.ui("quest.done", "Done"));
            } else {
                out.add("&7[ ] &f" + name(q) + " &8- &e" + prog + "&7/&e" + q.amount());
            }
        }
        if (out.isEmpty()) out.add("&7" + plugin.ui("quest.none", "No quests today."));
        return out;
    }

    public void show(Player p) {
        if (!enabled()) {
            plugin.send(p, "quests-disabled");
            return;
        }
        p.sendMessage(Util.color("&8--- &6" + plugin.ui("quest.title", "Daily quests") + " &8---"));
        for (String l : lines(p)) p.sendMessage(Util.color(l));
        p.sendMessage(Util.color("&7" + plugin.ui("quest.reset", "New quests every day at midnight (server time).")));
    }

    @EventHandler(ignoreCancelled = true)
    public void onMobDeath(EntityDeathEvent e) {
        if (e.getEntity() instanceof Player) return;
        Player k = e.getEntity().getKiller();
        if (k != null) add(k, "KILL_MOBS", 1);
    }
}
