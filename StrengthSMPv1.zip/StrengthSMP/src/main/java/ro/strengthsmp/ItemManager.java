package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;

/** Custom weapons, armor, scrolls, crystals, upgrade stones and reroll tokens (items.yml). */
public class ItemManager {

    public record Stats(double damage, double lifesteal, double crit, double health, double reduction) {
        public static final Stats NONE = new Stats(0, 0, 0, 0, 0);

        public Stats plus(Stats o) {
            return new Stats(damage + o.damage, lifesteal + o.lifesteal, crit + o.crit,
                    health + o.health, reduction + o.reduction);
        }
    }

    private final StrengthSMP plugin;
    private final NamespacedKey idKey;
    private final NamespacedKey upgradeKey;
    private final NamespacedKey rollDamageKey;
    private final NamespacedKey rollLifestealKey;
    private final NamespacedKey rollCritKey;
    private final List<NamespacedKey> recipeKeys = new ArrayList<>();
    private final Random random = new Random();
    private FileConfiguration cfg = new YamlConfiguration();

    public ItemManager(StrengthSMP plugin) {
        this.plugin = plugin;
        idKey = new NamespacedKey(plugin, "custom_item");
        upgradeKey = new NamespacedKey(plugin, "upgrade_level");
        rollDamageKey = new NamespacedKey(plugin, "roll_damage");
        rollLifestealKey = new NamespacedKey(plugin, "roll_lifesteal");
        rollCritKey = new NamespacedKey(plugin, "roll_crit");
    }

    public void load() {
        File f = new File(plugin.getDataFolder(), "items.yml");
        if (!f.exists()) plugin.saveResource("items.yml", false);
        cfg = YamlConfiguration.loadConfiguration(f);
        for (NamespacedKey k : recipeKeys) Bukkit.removeRecipe(k);
        recipeKeys.clear();
        ConfigurationSection items = cfg.getConfigurationSection("items");
        if (items == null) return;
        for (String id : items.getKeys(false)) {
            ConfigurationSection s = items.getConfigurationSection(id);
            if (s != null) registerRecipe(id, s);
        }
    }

    public Set<String> ids() {
        ConfigurationSection items = cfg.getConfigurationSection("items");
        return items == null ? Set.of() : items.getKeys(false);
    }

    private ConfigurationSection section(String id) {
        return cfg.getConfigurationSection("items." + id);
    }

    // ---------- identify ----------

    public String idOf(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }

    public String boundAbility(String id) {
        ConfigurationSection s = section(id);
        return s == null ? null : s.getString("ability", "");
    }

    // ---------- create ----------

    public ItemStack create(String id, int amount) {
        return build(id, amount, true);
    }

    private ItemStack build(String id, int amount, boolean roll) {
        if (id.startsWith("scroll_")) return createScroll(id.substring(7), amount);
        ConfigurationSection s = section(id);
        if (s == null) return null;
        Material m = Material.matchMaterial(s.getString("material", "STONE"));
        if (m == null) m = Material.STONE;
        ItemStack item = new ItemStack(m, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(idKey, PersistentDataType.STRING, id);
        if (roll) {
            double rd = roll(s, "damage");
            double rl = roll(s, "lifesteal");
            double rc = roll(s, "crit");
            if (rd > 0) pdc.set(rollDamageKey, PersistentDataType.DOUBLE, rd);
            if (rl > 0) pdc.set(rollLifestealKey, PersistentDataType.DOUBLE, rl);
            if (rc > 0) pdc.set(rollCritKey, PersistentDataType.DOUBLE, rc);
        }
        item.setItemMeta(meta);
        refresh(item);
        return item;
    }

    private ItemStack createScroll(String abilityId, int amount) {
        AbilityManager.Ability a = plugin.abilities().get(abilityId);
        if (a == null) return null;
        ItemStack item = new ItemStack(Material.PAPER, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Util.color("&eScroll of &6" + a.name()));
        meta.lore(List.of(Util.color("&7" + a.description()),
                Util.color("&7Right-click to permanently unlock this ability."),
                Util.color("&8Rarity: &9RARE")));
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, "scroll_" + a.id());
        item.setItemMeta(meta);
        return item;
    }

    private double roll(ConfigurationSection s, String key) {
        double max = s.getDouble("rolls." + key, 0);
        if (max <= 0) return 0;
        return Math.round(random.nextDouble() * max * 100.0) / 100.0;
    }

    // ---------- stats ----------

    public Stats stats(ItemStack item) {
        String id = idOf(item);
        if (id == null) return Stats.NONE;
        ConfigurationSection s = section(id);
        if (s == null) return Stats.NONE;
        ConfigurationSection st = s.getConfigurationSection("stats");
        if (st == null) return Stats.NONE;
        PersistentDataContainer pdc = item.getItemMeta().getPersistentDataContainer();
        int up = pdc.getOrDefault(upgradeKey, PersistentDataType.INTEGER, 0);
        double upDmg = up * plugin.getConfig().getDouble("upgrade.damage-per-level", 0.5);
        return new Stats(
                st.getDouble("damage-bonus") + pdc.getOrDefault(rollDamageKey, PersistentDataType.DOUBLE, 0.0) + upDmg,
                st.getDouble("lifesteal") + pdc.getOrDefault(rollLifestealKey, PersistentDataType.DOUBLE, 0.0),
                st.getDouble("crit-chance") + pdc.getOrDefault(rollCritKey, PersistentDataType.DOUBLE, 0.0),
                st.getDouble("health-bonus"),
                st.getDouble("damage-reduction"));
    }

    public Stats armorStats(Player p) {
        Stats total = Stats.NONE;
        for (ItemStack piece : p.getInventory().getArmorContents()) {
            if (piece != null) total = total.plus(stats(piece));
        }
        return total;
    }

    // ---------- upgrade / reroll ----------

    public boolean isUpgradable(ItemStack item) {
        String id = idOf(item);
        if (id == null) return false;
        ConfigurationSection s = section(id);
        return s != null && s.getConfigurationSection("stats") != null;
    }

    public boolean isRerollable(ItemStack item) {
        String id = idOf(item);
        if (id == null) return false;
        ConfigurationSection s = section(id);
        return s != null && s.getConfigurationSection("rolls") != null;
    }

    public int upgradeLevel(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return 0;
        return item.getItemMeta().getPersistentDataContainer().getOrDefault(upgradeKey, PersistentDataType.INTEGER, 0);
    }

    public void setUpgradeLevel(ItemStack item, int level) {
        ItemMeta meta = item.getItemMeta();
        meta.getPersistentDataContainer().set(upgradeKey, PersistentDataType.INTEGER, level);
        item.setItemMeta(meta);
        refresh(item);
    }

    public void reroll(ItemStack item) {
        String id = idOf(item);
        ConfigurationSection s = id == null ? null : section(id);
        if (s == null) return;
        ItemMeta meta = item.getItemMeta();
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.remove(rollDamageKey);
        pdc.remove(rollLifestealKey);
        pdc.remove(rollCritKey);
        double rd = roll(s, "damage");
        double rl = roll(s, "lifesteal");
        double rc = roll(s, "crit");
        if (rd > 0) pdc.set(rollDamageKey, PersistentDataType.DOUBLE, rd);
        if (rl > 0) pdc.set(rollLifestealKey, PersistentDataType.DOUBLE, rl);
        if (rc > 0) pdc.set(rollCritKey, PersistentDataType.DOUBLE, rc);
        item.setItemMeta(meta);
        refresh(item);
    }

    /** Removes one item with the given custom id from the player's inventory. */
    public boolean consumeOne(Player p, String id) {
        PlayerInventory inv = p.getInventory();
        ItemStack[] contents = inv.getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack it = contents[i];
            if (it != null && id.equals(idOf(it))) {
                if (it.getAmount() <= 1) inv.setItem(i, null);
                else it.setAmount(it.getAmount() - 1);
                return true;
            }
        }
        return false;
    }

    // ---------- name / lore ----------

    private String rarityColor(String rarity) {
        return switch (rarity) {
            case "UNCOMMON" -> "&a";
            case "RARE" -> "&9";
            case "EPIC" -> "&5";
            case "LEGENDARY" -> "&6";
            default -> "&7";
        };
    }

    public void refresh(ItemStack item) {
        String id = idOf(item);
        if (id == null || id.startsWith("scroll_")) return;
        ConfigurationSection s = section(id);
        if (s == null) return;
        ItemMeta meta = item.getItemMeta();
        int up = upgradeLevel(item);
        String rarity = s.getString("rarity", "COMMON").toUpperCase();
        meta.displayName(Util.color(s.getString("name", id) + (up > 0 ? " &7(+" + up + ")" : "")));

        List<Component> lore = new ArrayList<>();
        for (String line : s.getStringList("lore")) lore.add(Util.color(line));
        Stats st = stats(item);
        if (s.getConfigurationSection("stats") != null) {
            if (st.damage() != 0) lore.add(Util.color("&7Damage: &c+" + Util.num(st.damage())));
            if (st.lifesteal() != 0) lore.add(Util.color("&7Lifesteal: &c" + Math.round(st.lifesteal() * 100) + "%"));
            if (st.crit() != 0) lore.add(Util.color("&7Crit chance: &c" + Math.round(st.crit() * 100) + "%"));
            if (st.health() != 0) lore.add(Util.color("&7Health: &c+" + Util.num(st.health())));
            if (st.reduction() != 0) lore.add(Util.color("&7Damage reduction: &9" + Math.round(st.reduction() * 100) + "%"));
        }
        String ab = s.getString("ability", "");
        if (!ab.isEmpty()) {
            AbilityManager.Ability a = plugin.abilities().get(ab);
            lore.add(Util.color("&7Right-click: &e" + (a != null ? a.name() : ab)));
        }
        if (isUpgradable(item)) {
            lore.add(Util.color("&7Upgrade: &e" + up + "/" + plugin.getConfig().getInt("upgrade.max-level", 5)));
        }
        lore.add(Util.color("&8Rarity: " + rarityColor(rarity) + rarity));
        meta.lore(lore);
        item.setItemMeta(meta);
    }

    // ---------- recipes ----------

    private void registerRecipe(String id, ConfigurationSection s) {
        ConfigurationSection r = s.getConfigurationSection("recipe");
        if (r == null) return;
        List<String> shape = r.getStringList("shape");
        ConfigurationSection ing = r.getConfigurationSection("ingredients");
        if (shape.isEmpty() || ing == null) return;
        try {
            ItemStack result = build(id, r.getInt("amount", 1), false);
            if (result == null) return;
            NamespacedKey key = new NamespacedKey(plugin, "recipe_" + id);
            ShapedRecipe rec = new ShapedRecipe(key, result);
            rec.shape(shape.toArray(new String[0]));
            for (String k : ing.getKeys(false)) {
                RecipeChoice choice = choice(ing.getString(k, ""));
                if (choice == null) {
                    plugin.getLogger().warning("Recipe " + id + ": unknown ingredient '" + ing.getString(k) + "'");
                    return;
                }
                rec.setIngredient(k.charAt(0), choice);
            }
            Bukkit.addRecipe(rec);
            recipeKeys.add(key);
        } catch (Exception ex) {
            plugin.getLogger().warning("Could not register recipe for " + id + ": " + ex.getMessage());
        }
    }

    private RecipeChoice choice(String value) {
        if (value.startsWith("custom:")) {
            ItemStack it = build(value.substring(7), 1, false);
            return it == null ? null : new RecipeChoice.ExactChoice(it);
        }
        Material m = Material.matchMaterial(value);
        return m == null ? null : new RecipeChoice.MaterialChoice(m);
    }
}
