package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Join/quit, ability activation, scrolls, crystals, ability menu. */
public class PlayerListener implements Listener {
    private final StrengthSMP plugin;
    private final Map<UUID, Long> protectorCooldown = new HashMap<>();

    public PlayerListener(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void setup(Player p) {
        plugin.data().get(p);
        plugin.antiFarm().markLife(p);
        plugin.categories().ensure(p);
        plugin.abilities().ensureSelection(p);
        giveStarterBook(p);
        plugin.teams().touch(p);
        plugin.strength().refresh(p);
        plugin.revive().applyState(p);
        plugin.rewards().deliverPending(p);
        plugin.quests().ensureDay(plugin.data().get(p));
        if (plugin.protection().isProtected(p)) {
            plugin.send(p, "protection-join", "time", plugin.protection().format(plugin.data().get(p).protectionSeconds));
        }
    }

    /** One free Ability Reroll Book per player, given on the first join after this feature exists. */
    private void giveStarterBook(Player p) {
        if (!plugin.getConfig().getBoolean("starter-items.reroll-book", true)) return;
        PlayerData d = plugin.data().get(p);
        if (d.starterBook) return;
        ItemStack book = plugin.items().create("ability_reroll_book", 1);
        if (book == null) return;
        d.starterBook = true;
        Util.give(p, book);
        p.sendMessage(plugin.msg("starter-book"));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        setup(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        // combat logging: leaving while combat-tagged = death (drops items, killer gets credit)
        if (plugin.getConfig().getBoolean("combat-log.enabled", true) && plugin.abilities().inCombat(p)
                && !p.isDead() && p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR) {
            Bukkit.broadcast(plugin.msg("combat-log", "player", p.getName()));
            plugin.combatLoggers().add(p.getUniqueId());
            p.setHealth(0.0);
        }
        plugin.data().unload(p.getUniqueId());
        plugin.abilities().clear(p.getUniqueId());
        plugin.scoreboards().remove(p.getUniqueId());
        plugin.hud().remove(p.getUniqueId());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        plugin.antiFarm().markLife(p);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.strength().refresh(p);
            plugin.revive().applyState(p);
        }, 2L);
    }

    // ---------- activation ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item == null || item.getType().isAir()) return;

        Player p = e.getPlayer();
        CategoryManager cm = plugin.categories();

        if (e.getHand() == EquipmentSlot.OFF_HAND) {
            // a shield held alone in the off hand can fire an ability (shield category)
            if (plugin.getConfig().getBoolean("abilities.weapon-click", true) && cm.enabled()
                    && item.getType() == Material.SHIELD
                    && "shield".equals(plugin.data().get(p).category)
                    && p.getInventory().getItemInMainHand().getType().isAir()) {
                fireWeaponAbility(p, e, "shield");
            }
            return;
        }
        if (e.getHand() != EquipmentSlot.HAND) return;

        ItemManager items = plugin.items();
        AbilityManager am = plugin.abilities();
        String id = items.idOf(item);

        if (id != null) {
            if (id.startsWith("scroll_")) {
                e.setCancelled(true);
                readScroll(p, item, id.substring(7));
                return;
            }
            switch (id) {
                case "strength_crystal" -> {
                    e.setCancelled(true);
                    useCrystal(p, item);
                    return;
                }
                case "ability_reroll_book" -> {
                    e.setCancelled(true);
                    useRerollBook(p, item);
                    return;
                }
                case "strength_gift" -> {
                    e.setCancelled(true);
                    useGift(p, item);
                    return;
                }
                case "strength_protector" -> {
                    e.setCancelled(true);
                    useProtector(p, item);
                    return;
                }
                case "strength_tracker" -> {
                    e.setCancelled(true);
                    useTracker(p);
                    return;
                }
                case "dash_core" -> {
                    e.setCancelled(true);
                    useDashCore(p, item);
                    return;
                }
                case "strength_fragment" -> {
                    e.setCancelled(true);
                    return;
                }
                case "revive_beacon" -> {
                    e.setCancelled(true);
                    plugin.send(p, "revive-hint");
                    return;
                }
                default -> {
                }
            }
            String bound = items.boundAbility(id);
            if (bound != null && !bound.isEmpty()) {
                if (am.use(p, bound, true)) e.setCancelled(true);
                return;
            }
        }

        if (!plugin.getConfig().getBoolean("abilities.weapon-click", true)) return;
        Material t = item.getType();
        String cat = plugin.data().get(p).category;
        if (cm.enabled()) {
            boolean ok = CategoryManager.matches(cat, t)
                    || ("shield".equals(cat) && isWeapon(t)
                    && p.getInventory().getItemInOffHand().getType() == Material.SHIELD);
            if (!ok) return;
            fireWeaponAbility(p, e, cat);
        } else {
            boolean weapon = t == Material.MACE || t.name().endsWith("_SWORD") || t.name().endsWith("_AXE");
            if (!weapon) return;
            fireWeaponAbility(p, e, "sword");
        }
    }

    private static boolean isWeapon(Material t) {
        String n = t.name();
        return n.endsWith("_SWORD") || n.endsWith("_AXE") || t == Material.MACE || t == Material.TRIDENT
                || t == Material.BOW || t == Material.CROSSBOW;
    }

    /** Right-click = selected ability, sneak + right-click = next ability. */
    private void fireWeaponAbility(Player p, PlayerInteractEvent e, String category) {
        AbilityManager am = plugin.abilities();
        boolean cancel = !CategoryManager.keepsVanillaUse(category);
        if (p.isSneaking()) {
            if (cancel) e.setCancelled(true);
            am.cycle(p);
            return;
        }
        String sel = plugin.data().get(p).selectedAbility;
        if (sel.isEmpty()) return;
        if (!cancel) {
            // bow / crossbow / trident / shield: right-click also draws or blocks, so stay quiet when the
            // ability is already armed (second click of a crossbow) or still on cooldown
            if (am.weapons().hasArmed(p) || am.cooldownLeft(p, sel) > 0) return;
        }
        if (am.use(p, sel, false) && cancel) e.setCancelled(true);
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (!plugin.getConfig().getBoolean("abilities.swap-key", false)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        String sel = plugin.data().get(p).selectedAbility;
        if (!sel.isEmpty()) plugin.abilities().use(p, sel, false);
    }

    private void readScroll(Player p, ItemStack item, String abilityId) {
        AbilityManager.Ability a = plugin.abilities().get(abilityId);
        if (a == null) {
            plugin.send(p, "ability-unknown");
            return;
        }
        PlayerData d = plugin.data().get(p);
        if (d.unlocked.contains(a.id())) {
            plugin.send(p, "scroll-already", "ability", a.name());
            return;
        }
        d.unlocked.add(a.id());
        item.setAmount(item.getAmount() - 1);
        plugin.abilities().ensureSelection(p);
        plugin.send(p, "scroll-unlocked", "ability", a.name());
    }

    private void useCrystal(Player p, ItemStack item) {
        PlayerData d = plugin.data().get(p);
        if (d.strength >= plugin.strength().max()) {
            plugin.send(p, "crystal-max");
            return;
        }
        item.setAmount(item.getAmount() - 1);
        plugin.strength().setStrength(p, d.strength + 1, true);
        plugin.hud().flash(p, Util.color("&6" + plugin.ui("sb.strength", "Strength") + ": &c" + d.strength));
    }

    private void useRerollBook(Player p, ItemStack item) {
        if (!plugin.categories().enabled()) {
            plugin.send(p, "category-disabled");
            return;
        }
        String now = plugin.categories().reroll(p);
        item.setAmount(item.getAmount() - 1);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        plugin.send(p, "category-rerolled", "category", CategoryManager.display(now));
    }

    private void useGift(Player p, ItemStack item) {
        int range = plugin.getConfig().getInt("special-items.gift.range", 6);
        Entity t = p.getTargetEntity(range);
        if (!(t instanceof Player target) || target.equals(p)) {
            plugin.send(p, "gift-no-target");
            return;
        }
        PlayerData me = plugin.data().get(p);
        PlayerData other = plugin.data().get(target);
        int floor = Math.max(1, plugin.strength().min());
        if (me.strength <= floor) {
            plugin.send(p, "gift-min");
            return;
        }
        if (other.strength >= plugin.strength().max()) {
            plugin.send(p, "gift-target-max", "player", target.getName());
            return;
        }
        item.setAmount(item.getAmount() - 1);
        plugin.strength().setStrength(p, me.strength - 1, false);
        plugin.strength().setStrength(target, other.strength + 1, true);
        plugin.send(p, "gift-sent", "player", target.getName(), "level", me.strength);
        plugin.send(target, "gift-received", "player", p.getName(), "level", other.strength);
    }

    private void useProtector(Player p, ItemStack item) {
        long now = System.currentTimeMillis();
        long until = protectorCooldown.getOrDefault(p.getUniqueId(), 0L);
        if (now < until) {
            plugin.send(p, "protector-cooldown", "seconds", (until - now + 999) / 1000);
            return;
        }
        double seconds = plugin.getConfig().getDouble("special-items.protector.duration", 5);
        int amp = plugin.getConfig().getInt("special-items.protector.amplifier", 1);
        double cd = plugin.getConfig().getDouble("special-items.protector.cooldown", 60);
        p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, (int) (seconds * 20), amp));
        protectorCooldown.put(p.getUniqueId(), now + (long) (cd * 1000));
        item.setAmount(item.getAmount() - 1);
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1f);
        plugin.hud().flash(p, Util.color("&9Strength Protector &e" + plugin.ui("hud.activated", "activated!")));
    }

    private void useTracker(Player p) {
        int range = plugin.getConfig().getInt("special-items.tracker.range", 30);
        Entity t = p.getTargetEntity(range);
        if (!(t instanceof Player target) || target.equals(p)) {
            plugin.send(p, "tracker-no-target");
            return;
        }
        PlayerData d = plugin.data().get(target);
        plugin.send(p, "tracker-result", "player", target.getName(), "strength", d.strength);
        plugin.hud().flash(p, Util.color("&e" + target.getName() + " &7- " + plugin.ui("sb.strength", "Strength") + " &c" + d.strength));
    }

    private void useDashCore(Player p, ItemStack item) {
        AbilityManager.Ability dash = plugin.abilities().get("dash");
        if (dash == null) return;
        if (dash.exec().run(p, plugin.abilities().cfg("dash"))) {
            item.setAmount(item.getAmount() - 1);
            plugin.hud().flash(p, Util.color("&bDash Core &e" + plugin.ui("hud.activated", "activated!")));
        }
    }

    // ---------- ability menu ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof AbilityMenu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !(e.getClickedInventory().getHolder() instanceof AbilityMenu)) return;
        String id = menu.idAt(e.getSlot());
        if (id == null) return;
        plugin.abilities().select(p, id);
        p.closeInventory();
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof AbilityMenu) e.setCancelled(true);
    }
}
