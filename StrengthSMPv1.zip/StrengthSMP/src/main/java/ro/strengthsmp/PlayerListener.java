package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/** Join/quit, ability activation, scrolls, crystals, ability menu. */
public class PlayerListener implements Listener {
    private final StrengthSMP plugin;

    public PlayerListener(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void setup(Player p) {
        plugin.data().get(p);
        plugin.antiFarm().markLife(p);
        plugin.abilities().ensureSelection(p);
        plugin.teams().touch(p);
        plugin.strength().refresh(p);
        if (plugin.protection().isProtected(p)) {
            plugin.send(p, "protection-join", "time", plugin.protection().format(plugin.data().get(p).protectionSeconds));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        setup(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        // combat logging: leaving while combat-tagged = death (drops items, killer gets credit)
        if (plugin.getConfig().getBoolean("combat-log.enabled", true) && plugin.abilities().inCombat(p)
                && !p.isDead() && p.getGameMode() != GameMode.CREATIVE && p.getGameMode() != GameMode.SPECTATOR) {
            Bukkit.broadcast(plugin.msg("combat-log", "player", p.getName()));
            plugin.combatLoggers().add(p.getUniqueId());
            p.setHealth(0.0);
        }
        plugin.data().unload(p.getUniqueId());
        plugin.abilities().clear(p.getUniqueId());
        plugin.scoreboards().remove(p.getUniqueId());
        plugin.hud().remove(p.getUniqueId());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        plugin.antiFarm().markLife(p);
        Bukkit.getScheduler().runTaskLater(plugin, () -> plugin.strength().refresh(p), 2L);
    }

    // ---------- activation ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = e.getItem();
        if (item == null || item.getType().isAir()) return;

        Player p = e.getPlayer();
        ItemManager items = plugin.items();
        AbilityManager am = plugin.abilities();
        String id = items.idOf(item);

        if (id != null) {
            if (id.startsWith("scroll_")) {
                e.setCancelled(true);
                readScroll(p, item, id.substring(7));
                return;
            }
            if (id.equals("strength_crystal")) {
                e.setCancelled(true);
                useCrystal(p, item);
                return;
            }
            String bound = items.boundAbility(id);
            if (bound != null && !bound.isEmpty()) {
                if (am.use(p, bound, true)) e.setCancelled(true);
                return;
            }
        }

        if (!plugin.getConfig().getBoolean("abilities.weapon-click", true)) return;
        Material t = item.getType();
        boolean weapon = t == Material.MACE || t.name().endsWith("_SWORD") || t.name().endsWith("_AXE");
        if (!weapon) return;

        if (p.isSneaking()) {
            e.setCancelled(true);
            am.cycle(p);
            return;
        }
        String sel = plugin.data().get(p).selectedAbility;
        if (sel.isEmpty()) return;
        if (am.use(p, sel, false)) e.setCancelled(true);
    }

    @EventHandler
    public void onSwap(PlayerSwapHandItemsEvent e) {
        if (!plugin.getConfig().getBoolean("abilities.swap-key", false)) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        String sel = plugin.data().get(p).selectedAbility;
        if (!sel.isEmpty()) plugin.abilities().use(p, sel, false);
    }

    private void readScroll(Player p, ItemStack item, String abilityId) {
        AbilityManager.Ability a = plugin.abilities().get(abilityId);
        if (a == null) {
            plugin.send(p, "ability-unknown");
            return;
        }
        PlayerData d = plugin.data().get(p);
        if (d.unlocked.contains(a.id())) {
            plugin.send(p, "scroll-already", "ability", a.name());
            return;
        }
        d.unlocked.add(a.id());
        item.setAmount(item.getAmount() - 1);
        plugin.abilities().ensureSelection(p);
        plugin.send(p, "scroll-unlocked", "ability", a.name());
    }

    private void useCrystal(Player p, ItemStack item) {
        PlayerData d = plugin.data().get(p);
        if (d.strength >= plugin.strength().max()) {
            plugin.send(p, "crystal-max");
            return;
        }
        item.setAmount(item.getAmount() - 1);
        plugin.strength().setStrength(p, d.strength + 1, true);
        plugin.hud().flash(p, Util.color("&6Strength: &c" + d.strength));
    }

    // ---------- ability menu ----------

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof AbilityMenu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || !(e.getClickedInventory().getHolder() instanceof AbilityMenu)) return;
        String id = menu.idAt(e.getSlot());
        if (id == null) return;
        plugin.abilities().select(p, id);
        p.closeInventory();
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof AbilityMenu) e.setCancelled(true);
    }
}
