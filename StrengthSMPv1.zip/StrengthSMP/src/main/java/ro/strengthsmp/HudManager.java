package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Action-bar HUD: selected ability + cooldown, active buffs, combat tag, PvP protection. Also refreshes the scoreboard. */
public class HudManager {
    private final StrengthSMP plugin;
    private final Map<UUID, Long> pause = new HashMap<>();

    public HudManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long interval = Math.max(2L, plugin.getConfig().getLong("hud.interval-ticks", 10L));
        Bukkit.getScheduler().runTaskTimer(plugin, this::run, 20L, interval);
    }

    public void remove(UUID id) {
        pause.remove(id);
    }

    /** One-off action-bar message (crit, kill, ability used...). The HUD waits a moment so it stays readable. */
    public void flash(Player p, Component c) {
        p.sendActionBar(c);
        long hold = plugin.getConfig().getLong("hud.message-hold-ms", 2000L);
        pause.put(p.getUniqueId(), System.currentTimeMillis() + hold);
    }

    private void run() {
        boolean hud = plugin.getConfig().getBoolean("hud.enabled", true);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (hud) showActionBar(p);
            plugin.scoreboards().update(p);
        }
    }

    // ---------- helpers shared with the scoreboard / placeholders ----------

    public static String sec(long ms) {
        return String.valueOf((ms + 999) / 1000);
    }

    /** Name of the selected ability, or null if none. */
    public String selectedName(Player p) {
        PlayerData d = plugin.data().get(p);
        AbilityManager.Ability a = plugin.abilities().get(d.selectedAbility);
        return a == null ? null : a.name();
    }

    /** "&aReady" or "&c5s" for the selected ability, or null if none. */
    public String statusText(Player p) {
        PlayerData d = plugin.data().get(p);
        AbilityManager.Ability a = plugin.abilities().get(d.selectedAbility);
        if (a == null) return null;
        long left = plugin.abilities().cooldownLeft(p, a.id());
        return left > 0 ? "&c" + sec(left) + "s" : "&a" + plugin.ui("hud.ready", "Ready");
    }

    private void showActionBar(Player p) {
        Long until = pause.get(p.getUniqueId());
        if (until != null && System.currentTimeMillis() < until) return;

        AbilityManager am = plugin.abilities();
        List<String> parts = new ArrayList<>();

        String name = selectedName(p);
        String lvl = "";
        if (name != null && am.levelsEnabled()) lvl = " &7Lv" + am.level(p, plugin.data().get(p).selectedAbility);
        if (plugin.categories().enabled()) {
            String cat = CategoryManager.display(plugin.data().get(p).category);
            parts.add("&e" + cat + (name != null ? "&7: &6" + name + lvl + " " + statusText(p) : ""));
        } else if (name != null) {
            parts.add("&6" + name + lvl + " " + statusText(p));
        }

        for (Map.Entry<String, Long> en : am.activeLeft(p).entrySet()) {
            AbilityManager.Ability a = am.get(en.getKey());
            if (a != null) parts.add("&b" + a.name() + " " + sec(en.getValue()) + "s");
        }

        long combat = am.combatLeft(p);
        if (combat > 0) parts.add("&c" + plugin.ui("hud.combat", "Combat") + " " + sec(combat) + "s");

        PlayerData d = plugin.data().get(p);
        if (plugin.protection().isProtected(p)) {
            parts.add("&a" + plugin.ui("hud.protected", "Protected") + " " + plugin.protection().format(d.protectionSeconds));
        }

        if (plugin.events().bloodActive()) parts.add("&4" + plugin.ui("event.bloodmoon", "Blood Moon") + " " + plugin.events().bloodLeft());
        if (plugin.duels().inDuel(p)) parts.add("&5" + plugin.ui("duel.tag", "Duel"));

        if (parts.isEmpty()) return;
        p.sendActionBar(Util.color(String.join(" &8| ", parts)));
    }
}
