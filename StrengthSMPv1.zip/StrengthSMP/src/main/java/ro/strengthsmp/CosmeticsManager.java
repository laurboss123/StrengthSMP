package ro.strengthsmp;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Particles and sounds on every rewarded kill, chosen by the killer's rank (config.yml: cosmetics.kill-effects.<rank id>). */
public class CosmeticsManager {
    private final StrengthSMP plugin;
    private final Set<String> warned = new HashSet<>();

    public CosmeticsManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public void killEffect(Player killer, Player victim) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("cosmetics.enabled", true)) return;
        PlayerData d = plugin.data().get(killer);
        String rank = plugin.strength().rankFor(d.strength).id();
        ConfigurationSection s = c.getConfigurationSection("cosmetics.kill-effects." + rank);
        if (s == null) s = c.getConfigurationSection("cosmetics.kill-effects.default");
        if (s == null) return;

        Location loc = victim.getLocation().add(0, 1, 0);
        World w = loc.getWorld();
        if (w == null) return;

        String particleName = s.getString("particle", "CRIT");
        try {
            Particle part = Particle.valueOf(particleName.toUpperCase(Locale.ROOT));
            w.spawnParticle(part, loc, Math.max(1, s.getInt("count", 20)), 0.4, 0.6, 0.4, s.getDouble("speed", 0.05));
        } catch (IllegalArgumentException ex) {
            if (warned.add(particleName)) {
                plugin.getLogger().warning("cosmetics: unknown or unsupported particle '" + particleName + "'");
            }
        }

        String sound = s.getString("sound", "");
        if (sound != null && !sound.isEmpty()) {
            w.playSound(loc, sound, 1.0f, (float) s.getDouble("pitch", 1.0));
        }
        if (s.getBoolean("lightning", false)) {
            w.strikeLightningEffect(loc);
        }
    }
}
