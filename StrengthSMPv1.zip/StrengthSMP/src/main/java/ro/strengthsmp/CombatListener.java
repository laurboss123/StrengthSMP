package ro.strengthsmp;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.potion.PotionEffectType;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/** Kill rewards, Strength damage scaling, items, lifesteal, shields, crits. */
public class CombatListener implements Listener {
    private final StrengthSMP plugin;
    private final Map<UUID, Long> lastDeath = new HashMap<>();
    private final Random random = new Random();

    public CombatListener(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    private Player attackerOf(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile pr && pr.getShooter() instanceof Player s) return s;
        return null;
    }

    // ---------- damage ----------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        FileConfiguration cfg = plugin.getConfig();
        AbilityManager am = plugin.abilities();
        ItemManager items = plugin.items();
        Player attacker = attackerOf(e.getDamager());
        Entity victim = e.getEntity();
        double dmg = e.getDamage();
        double lifesteal = 0.0;

        // Counterattack: did the victim just block this hit with a shield?
        if (victim instanceof Player bv && bv.isBlocking()
                && e.isApplicable(EntityDamageEvent.DamageModifier.BLOCKING)
                && e.getDamage(EntityDamageEvent.DamageModifier.BLOCKING) < 0) {
            am.weapons().onBlocked(bv);
        }

        // teammates and protected newbies cannot be hurt by (or hurt) other players
        if (attacker != null && victim instanceof Player vp && !attacker.equals(vp)) {
            if (plugin.teams().sameTeam(attacker, vp) && !cfg.getBoolean("team.friendly-fire", false)) {
                e.setCancelled(true);
                plugin.hud().flash(attacker, plugin.raw("team-friendly-fire"));
                return;
            }
            if (plugin.spawnProt().blocksPvp(attacker, vp)) {
                e.setCancelled(true);
                plugin.hud().flash(attacker, plugin.raw("spawn-no-pvp"));
                return;
            }
            ProtectionManager pm = plugin.protection();
            if (pm.isProtected(attacker)) {
                e.setCancelled(true);
                plugin.hud().flash(attacker, plugin.raw("protection-you-protected"));
                return;
            }
            if (pm.isProtected(vp)) {
                e.setCancelled(true);
                plugin.hud().flash(attacker, plugin.raw("protection-target-protected", "player", vp.getName()));
                return;
            }
        }

        if (attacker != null && victim instanceof LivingEntity && !am.isAbilityDamage()
                && (victim instanceof Player || cfg.getBoolean("strength.apply-to-mobs", true))) {
            PlayerData ad = plugin.data().get(attacker);
            boolean melee = e.getDamager() instanceof Player;
            ItemManager.Stats hand = melee
                    ? items.stats(attacker.getInventory().getItemInMainHand())
                    : ItemManager.Stats.NONE;
            ItemManager.Stats armor = items.armorStats(attacker);

            dmg += plugin.strength().damageBonus(ad) + hand.damage() + armor.damage();
            if (am.isActive(attacker, "berserker")) {
                dmg *= am.cfg("berserker").getDouble("multiplier", 1.3);
            }

            double crit = cfg.getDouble("combat.base-crit-chance", 0.0) + hand.crit() + armor.crit();
            if (crit > 0 && random.nextDouble() < crit) {
                dmg *= cfg.getDouble("combat.crit-multiplier", 1.5);
                attacker.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 15, 0.3, 0.3, 0.3, 0.1);
                plugin.hud().flash(attacker, Util.color("&cCritical hit!"));
            }

            // weapon-category abilities: next-hit bonuses, marks, special arrows / bolts / tridents
            dmg = am.weapons().outgoing(attacker, (LivingEntity) victim, e.getDamager(), dmg);

            lifesteal = hand.lifesteal() + armor.lifesteal();
            if (am.isActive(attacker, "lifesteal")) {
                lifesteal += am.cfg("lifesteal").getDouble("percent", 0.2);
            }
        }

        if (victim instanceof LivingEntity lv) {
            double red = 0.0;
            if (lv instanceof Player vp) {
                red = items.armorStats(vp).reduction() + am.weapons().incomingReduction(vp); // armor + Iron Will + Fortress
            }
            if (am.weapons().isArmorBroken(lv)) { // Armor Break lowers resistance
                red -= am.cfg("armor_break").getDouble("resistance-loss", 0.3);
            }
            red = Math.min(red, cfg.getDouble("combat.max-damage-reduction", 0.8));
            if (red != 0) dmg *= (1.0 - red);
            if (lv instanceof Player vp2 && am.isActive(vp2, "blood_rage")) {
                dmg *= 1.0 + am.cfg("blood_rage").getDouble("damage-taken-bonus", 0.15);
            }
        }

        double cap = cfg.getDouble("combat.max-damage-per-hit", 200.0);
        if (Double.isNaN(dmg) || dmg < 0) dmg = 0;
        dmg = Math.min(dmg, cap);
        e.setDamage(dmg);

        // Reflect: send part of the damage back to whoever hit us (next tick, through the ability damage path)
        if (victim instanceof Player rv && dmg > 0 && !am.isAbilityDamage() && am.isActive(rv, "reflect")) {
            LivingEntity src = attacker != null ? attacker
                    : (e.getDamager() instanceof LivingEntity le ? le : null);
            if (src != null && !src.equals(rv)) {
                final double back = dmg * am.cfg("reflect").getDouble("percent", 0.3);
                final LivingEntity target = src;
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (rv.isOnline() && !rv.isDead() && target.isValid() && !target.isDead() && am.canHarm(rv, target)) {
                        am.damage(rv, target, back);
                        target.getWorld().spawnParticle(Particle.CRIT, target.getLocation().add(0, 1, 0), 12, 0.3, 0.4, 0.3, 0.1);
                    }
                });
            }
        }

        if (attacker != null && lifesteal > 0 && dmg > 0 && !attacker.isDead()) {
            AttributeInstance mh = attacker.getAttribute(Util.maxHealth());
            double max = mh != null ? mh.getValue() : 20.0;
            attacker.setHealth(Math.max(0.1, Math.min(max, attacker.getHealth() + dmg * lifesteal)));
        }

        if (attacker != null && victim instanceof Player target && !attacker.equals(target)) {
            am.tagCombat(attacker);
            am.tagCombat(target);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent e) {
        if (e.getEntity().getShooter() instanceof Player p) plugin.abilities().weapons().onLaunch(e.getEntity(), p);
    }

    @EventHandler(ignoreCancelled = true)
    public void onProjectileHit(ProjectileHitEvent e) {
        plugin.abilities().weapons().onHit(e);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFall(EntityDamageEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL && e.getEntity() instanceof Player p
                && plugin.abilities().isActive(p, "nofall")) {
            e.setCancelled(true);
        }
    }

    // ---------- kills ----------

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        long now = System.currentTimeMillis();
        Long last = lastDeath.get(victim.getUniqueId());
        if (last != null && now - last < 1000) return; // prevents duplicate rewards for one death
        lastDeath.put(victim.getUniqueId(), now);

        PlayerData vd = plugin.data().get(victim);
        vd.deaths++;
        int victimStreak = vd.streak;
        vd.streak = 0;
        plugin.abilities().clearBuffs(victim);
        plugin.abilities().endCombat(victim);

        Player killer = victim.getKiller();
        boolean validPvp = killer != null && !killer.equals(victim) && isDirectPvp(victim, killer);
        boolean loggedOut = plugin.combatLoggers().remove(victim.getUniqueId());
        boolean reward = !loggedOut || plugin.getConfig().getBoolean("combat-log.reward-killer", true);
        if (validPvp && reward) handleKill(killer, victim, victimStreak);

        FileConfiguration cfg = plugin.getConfig();
        if (cfg.getBoolean("death-penalty.enabled", false)
                && (validPvp || !cfg.getBoolean("death-penalty.only-pvp", true))) {
            int loss = cfg.getInt("death-penalty.amount", 1);
            plugin.strength().setStrength(victim, vd.strength - loss, false);
        }
        plugin.strength().refresh(victim);
    }

    /** Last damage must come from the killer (melee or their projectile) - no void/fall kills. */
    private boolean isDirectPvp(Player victim, Player killer) {
        if (!plugin.getConfig().getBoolean("kills.pvp-only", true)) return true;
        EntityDamageEvent last = victim.getLastDamageCause();
        if (last instanceof EntityDamageByEntityEvent ebe) {
            Player a = attackerOf(ebe.getDamager());
            return a != null && a.equals(killer);
        }
        return false;
    }

    private void handleKill(Player killer, Player victim, int victimStreak) {
        PlayerData kd = plugin.data().get(killer);
        kd.kills++;
        kd.streak++;
        kd.bestStreak = Math.max(kd.bestStreak, kd.streak);
        plugin.bounty().announceKill(killer, victim, kd.streak, victimStreak);

        String reason = plugin.antiFarm().check(killer, victim);
        if (reason != null) {
            plugin.send(killer, "kill-no-reward", "reason", reason);
            plugin.strength().refresh(killer);
            return;
        }
        plugin.bounty().claim(killer, victim, victimStreak);

        int max = plugin.strength().max();
        if (kd.strength >= max) {
            plugin.send(killer, "kill-max", "victim", victim.getName(), "max", max);
            plugin.antiFarm().record(killer, victim);
            plugin.strength().refresh(killer);
            return;
        }

        int old = kd.strength;
        plugin.strength().setStrength(killer, old + 1, true); // exactly +1 per valid kill
        kd.totalGained += Math.max(0, kd.strength - old);
        plugin.antiFarm().record(killer, victim);
        feedback(killer, victim, kd.strength);
    }

    private void feedback(Player killer, Player victim, int level) {
        FileConfiguration c = plugin.getConfig();
        killer.sendMessage(plugin.msg("kill", "victim", victim.getName(), "level", level));
        if (c.getBoolean("feedback.action-bar", true)) {
            plugin.hud().flash(killer, Util.color("&6Strength: &c" + level));
        }
        if (c.getBoolean("feedback.title", true)) {
            killer.showTitle(Title.title(Util.color("&c+1 Strength"), Util.color("&7Level " + level),
                    Title.Times.times(Duration.ofMillis(200), Duration.ofMillis(1000), Duration.ofMillis(300))));
        }
        if (c.getBoolean("feedback.sound", true)) {
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
        if (c.getBoolean("feedback.particles", true)) {
            killer.getWorld().spawnParticle(Particle.CRIT, killer.getLocation().add(0, 1, 0), 30, 0.5, 0.8, 0.5, 0.2);
        }
    }
}
