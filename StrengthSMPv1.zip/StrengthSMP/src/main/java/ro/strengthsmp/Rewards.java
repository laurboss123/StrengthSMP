package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * Shared reward format used by quests, KOTH, weekly prizes and bounties:
 *   give-items: ["strength_crystal:1", "upgrade_stone:2", "random_scroll:1"]
 *   strength: 1
 *   commands: ["say %player% won"]
 * Rewards for offline players are kept as pending lines and delivered when they join.
 */
public class Rewards {
    private final StrengthSMP plugin;

    public Rewards(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    /** Converts a reward section to pending-reward lines (item:..., strength:..., cmd:...). */
    public List<String> specs(ConfigurationSection s) {
        List<String> out = new ArrayList<>();
        if (s == null) return out;
        for (String item : s.getStringList("give-items")) out.add("item:" + item);
        int st = s.getInt("strength", 0);
        if (st > 0) out.add("strength:" + st);
        for (String cmd : s.getStringList("commands")) out.add("cmd:" + cmd);
        return out;
    }

    public void grant(Player p, ConfigurationSection s) {
        for (String spec : specs(s)) deliver(p, spec);
    }

    public void deliver(Player p, String spec) {
        if (spec.startsWith("item:")) {
            plugin.strength().giveItemSpec(p, spec.substring(5));
        } else if (spec.startsWith("strength:")) {
            try {
                int n = Integer.parseInt(spec.substring(9));
                PlayerData d = plugin.data().get(p);
                plugin.strength().setStrength(p, d.strength + n, true);
            } catch (NumberFormatException ignored) {
                // bad line, skip
            }
        } else if (spec.startsWith("cmd:")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), spec.substring(4).replace("%player%", p.getName()));
        }
    }

    /** Delivers everything that was queued while the player was offline. */
    public void deliverPending(Player p) {
        PlayerData d = plugin.data().get(p);
        if (d.pending.isEmpty()) return;
        List<String> list = new ArrayList<>(d.pending);
        d.pending.clear();
        for (String spec : list) deliver(p, spec);
        plugin.send(p, "rewards-delivered");
    }
}
