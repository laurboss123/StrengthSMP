package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Modular ability framework. To add an ability: call register(...) with an Executor
 * and add a section under abilities.list.<id> in config.yml.
 */
public class AbilityManager {

    public interface Executor {
        /** Return true if the ability fired (cooldown is only consumed on success). */
        boolean run(Player p, ConfigurationSection cfg);
    }

    public record Ability(String id, String name, String description, Material icon, String category, Executor exec) {
    }

    private final StrengthSMP plugin;
    private final Map<String, Ability> abilities = new LinkedHashMap<>();
    private final Map<UUID, Map<String, Long>> cooldowns = new HashMap<>();
    private final Map<UUID, Map<String, Long>> active = new HashMap<>();
    private final Map<UUID, Long> lastAny = new HashMap<>();
    private final Map<UUID, Long> combat = new HashMap<>();
    private final Map<UUID, String> lastUsed = new HashMap<>();
    private boolean abilityDamage = false;
    private WeaponAbilities weapons;

    public AbilityManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    // ---------- registry ----------

    /** Ability that belongs to no weapon category (item-bound only). */
    public void register(String id, String name, String description, Material icon, Executor exec) {
        register(id, name, description, icon, null, exec);
    }

    /** Ability that only players of the given weapon category can select and use. */
    public void register(String id, String name, String description, Material icon, String category, Executor exec) {
        abilities.put(id, new Ability(id, name, description, icon, category, exec));
        String perm = "strengthsmp.ability." + id;
        if (Bukkit.getPluginManager().getPermission(perm) == null) {
            Bukkit.getPluginManager().addPermission(new Permission(perm, PermissionDefault.TRUE));
        }
    }

    public Ability get(String id) {
        return id == null ? null : abilities.get(id.toLowerCase());
    }

    public Collection<Ability> all() {
        return abilities.values();
    }

    public ConfigurationSection cfg(String id) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("abilities.list." + id);
        return s != null ? s : new YamlConfiguration();
    }

    public WeaponAbilities weapons() {
        return weapons;
    }

    /** True if the player's weapon category may use this ability (always true when categories are off). */
    public boolean categoryOk(Player p, Ability a) {
        if (!plugin.categories().enabled()) return true;
        return a.category() != null && a.category().equals(plugin.data().get(p).category);
    }

    /** Abilities of the player's own weapon category (what the menu and /ability list show). */
    public List<Ability> listFor(Player p) {
        List<Ability> list = new ArrayList<>();
        for (Ability a : abilities.values()) {
            if (categoryOk(p, a)) list.add(a);
        }
        return list;
    }

    // ---------- state ----------

    public boolean isUnlocked(Player p, Ability a) {
        PlayerData d = plugin.data().get(p);
        if (d.unlocked.contains(a.id())) return true;
        int need = cfg(a.id()).getInt("unlock-strength", 0);
        return need >= 0 && d.strength >= need;
    }

    public void activate(Player p, String key, double seconds) {
        active.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>())
                .put(key, System.currentTimeMillis() + (long) (seconds * 1000));
    }

    public boolean isActive(Player p, String key) {
        Map<String, Long> m = active.get(p.getUniqueId());
        if (m == null) return false;
        Long t = m.get(key);
        if (t == null) return false;
        if (System.currentTimeMillis() > t) {
            m.remove(key);
            return false;
        }
        return true;
    }

    public void endBuff(Player p, String key) {
        Map<String, Long> m = active.get(p.getUniqueId());
        if (m != null) m.remove(key);
    }

    public void clearBuffs(Player p) {
        active.remove(p.getUniqueId());
        if (weapons != null) weapons.clearState(p.getUniqueId());
    }

    public void clear(UUID id) {
        active.remove(id);
        cooldowns.remove(id);
        lastAny.remove(id);
        combat.remove(id);
        lastUsed.remove(id);
        if (weapons != null) weapons.clearState(id);
    }

    /** Removes every ability cooldown of a player (duels). */
    public void resetCooldowns(UUID id) {
        cooldowns.remove(id);
        lastAny.remove(id);
    }

    // ---------- ability levels ----------

    public boolean levelsEnabled() {
        return plugin.getConfig().getBoolean("ability-levels.enabled", true);
    }

    public int maxLevel() {
        return Math.max(1, plugin.getConfig().getInt("ability-levels.max-level", 5));
    }

    /** Level of an ability for this player (1 = base). */
    public int level(Player p, String id) {
        if (!levelsEnabled()) return 1;
        int lvl = plugin.data().get(p).abilityLevels.getOrDefault(id, 1);
        return Math.max(1, Math.min(maxLevel(), lvl));
    }

    /** Cooldown multiplier (1.0 = base, lower = faster). Capped at -50%. */
    public double cooldownMult(Player p, String id) {
        double red = (level(p, id) - 1) * plugin.getConfig().getDouble("ability-levels.cooldown-reduction-per-level", 0.05);
        return 1.0 - Math.max(0.0, Math.min(0.5, red));
    }

    /** Damage multiplier for ability damage (1.0 = base). */
    public double damageMult(Player p, String id) {
        return 1.0 + (level(p, id) - 1) * plugin.getConfig().getDouble("ability-levels.damage-per-level", 0.10);
    }

    /** Kills with the ability selected that are needed for the next level. */
    public int killsNeeded(Player p, String id) {
        return Math.max(1, plugin.getConfig().getInt("ability-levels.kills-per-level", 10) * level(p, id));
    }

    private boolean raise(Player p, String id) {
        PlayerData d = plugin.data().get(p);
        int lvl = level(p, id);
        if (lvl >= maxLevel()) return false;
        d.abilityLevels.put(id, lvl + 1);
        d.abilityKills.remove(id);
        Ability a = get(id);
        plugin.send(p, "ability-level-up", "ability", a != null ? a.name() : id, "level", lvl + 1);
        p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.4f);
        return true;
    }

    /** A rewarded PvP kill counts toward the level of the ability the killer had selected. */
    public void creditKill(Player killer) {
        if (!levelsEnabled()) return;
        PlayerData d = plugin.data().get(killer);
        String id = d.selectedAbility;
        if (id == null || id.isEmpty() || get(id) == null || level(killer, id) >= maxLevel()) return;
        int n = d.abilityKills.merge(id, 1, Integer::sum);
        if (n >= killsNeeded(killer, id)) raise(killer, id);
    }

    /** Uses one Upgrade Stone to raise an ability by one level (/ability upgrade). */
    public boolean upgradeWithStone(Player p, String id) {
        if (!levelsEnabled() || !plugin.getConfig().getBoolean("ability-levels.upgrade-stone", true)) {
            plugin.send(p, "ability-level-disabled");
            return false;
        }
        Ability a = get(id);
        if (a == null || !categoryOk(p, a) || !isUnlocked(p, a)) {
            plugin.send(p, "ability-none");
            return false;
        }
        if (level(p, a.id()) >= maxLevel()) {
            plugin.send(p, "ability-level-max", "ability", a.name());
            return false;
        }
        if (!plugin.items().consumeOne(p, "upgrade_stone")) {
            plugin.send(p, "upgrade-no-stone");
            return false;
        }
        return raise(p, a.id());
    }

    public void tagCombat(Player p) {
        double sec = plugin.getConfig().getDouble("combat.combat-tag-seconds", 10);
        combat.put(p.getUniqueId(), System.currentTimeMillis() + (long) (sec * 1000));
    }

    public boolean inCombat(Player p) {
        Long t = combat.get(p.getUniqueId());
        return t != null && System.currentTimeMillis() < t;
    }

    public void endCombat(Player p) {
        combat.remove(p.getUniqueId());
    }

    public long combatLeft(Player p) {
        Long t = combat.get(p.getUniqueId());
        return t == null ? 0L : Math.max(0L, t - System.currentTimeMillis());
    }

    /** Milliseconds of cooldown left for an ability (0 = ready). */
    public long cooldownLeft(Player p, String id) {
        Map<String, Long> m = cooldowns.get(p.getUniqueId());
        if (m == null) return 0L;
        return Math.max(0L, m.getOrDefault(id, 0L) - System.currentTimeMillis());
    }

    /** Active timed effects: key -> milliseconds left (expired ones are skipped). */
    public Map<String, Long> activeLeft(Player p) {
        Map<String, Long> out = new LinkedHashMap<>();
        Map<String, Long> m = active.get(p.getUniqueId());
        if (m == null) return out;
        long now = System.currentTimeMillis();
        for (Map.Entry<String, Long> en : m.entrySet()) {
            if (en.getValue() > now) out.put(en.getKey(), en.getValue() - now);
        }
        return out;
    }

    public boolean isAbilityDamage() {
        return abilityDamage;
    }

    /** Damage dealt by an ability: skips Strength/item bonuses so it is not boosted twice. */
    public void damage(Player src, LivingEntity target, double amount) {
        abilityDamage = true;
        try {
            String id = lastUsed.get(src.getUniqueId());
            double mult = id == null ? 1.0 : damageMult(src, id);
            target.damage(amount * mult, src);
        } finally {
            abilityDamage = false;
        }
    }

    public boolean canHarm(Player p, LivingEntity t) {
        if (t.equals(p) || t instanceof ArmorStand || t.isDead()) return false;
        if (t instanceof Player tp) {
            if (tp.getGameMode() == GameMode.CREATIVE || tp.getGameMode() == GameMode.SPECTATOR) return false;
            if (!tp.getWorld().getPVP()) return false;
            if (plugin.duels().together(p, tp)) return true;
            if (plugin.teams().sameTeam(p, tp) && !plugin.getConfig().getBoolean("team.friendly-fire", false)) return false;
            if (plugin.protection().isProtected(p) || plugin.protection().isProtected(tp)) return false;
            if (plugin.spawnProt().blocksPvp(p, tp)) return false;
        }
        return true;
    }

    // ---------- selection ----------

    public List<String> available(Player p) {
        List<String> list = new ArrayList<>();
        for (Ability a : abilities.values()) {
            if (categoryOk(p, a) && cfg(a.id()).getBoolean("enabled", true) && isUnlocked(p, a)) list.add(a.id());
        }
        return list;
    }

    public void ensureSelection(Player p) {
        PlayerData d = plugin.data().get(p);
        List<String> av = available(p);
        if (!av.contains(d.selectedAbility)) {
            d.selectedAbility = av.isEmpty() ? "" : av.get(0);
        }
    }

    public void select(Player p, String id) {
        Ability a = get(id);
        if (a == null) {
            plugin.send(p, "ability-unknown");
            return;
        }
        if (!cfg(a.id()).getBoolean("enabled", true)) {
            plugin.send(p, "ability-disabled", "ability", a.name());
            return;
        }
        if (!categoryOk(p, a)) {
            sendWrongCategory(p, a);
            return;
        }
        if (!isUnlocked(p, a)) {
            sendLocked(p, a);
            return;
        }
        plugin.data().get(p).selectedAbility = a.id();
        plugin.send(p, "ability-selected", "ability", a.name());
    }

    public void cycle(Player p) {
        PlayerData d = plugin.data().get(p);
        List<String> av = available(p);
        if (av.isEmpty()) {
            plugin.send(p, "ability-none");
            return;
        }
        int idx = av.indexOf(d.selectedAbility);
        d.selectedAbility = av.get((idx + 1) % av.size());
        Ability a = get(d.selectedAbility);
        plugin.hud().flash(p, Util.color("&e" + plugin.ui("hud.selected", "Selected ability") + ": &6"
                + (a != null ? a.name() : d.selectedAbility)));
    }

    private void sendWrongCategory(Player p, Ability a) {
        plugin.send(p, "ability-wrong-category", "ability", a.name(),
                "category", CategoryManager.display(a.category()),
                "own", CategoryManager.display(plugin.data().get(p).category));
    }

    private void sendLocked(Player p, Ability a) {
        int need = cfg(a.id()).getInt("unlock-strength", 0);
        if (need >= 0) plugin.send(p, "ability-locked", "ability", a.name(), "need", need);
        else plugin.send(p, "ability-locked-scroll", "ability", a.name());
    }

    // ---------- use ----------

    public boolean use(Player p, String id, boolean ignoreUnlock) {
        Ability a = get(id);
        if (a == null) {
            plugin.send(p, "ability-unknown");
            return false;
        }
        ConfigurationSection c = cfg(a.id());
        if (!c.getBoolean("enabled", true)) {
            plugin.send(p, "ability-disabled", "ability", a.name());
            return false;
        }
        if (!p.hasPermission("strengthsmp.ability." + a.id())) {
            plugin.send(p, "no-permission");
            return false;
        }
        if (p.getGameMode() == GameMode.SPECTATOR) return false;
        if (!ignoreUnlock && !categoryOk(p, a)) {
            sendWrongCategory(p, a);
            return false;
        }
        if (!ignoreUnlock && !isUnlocked(p, a)) {
            sendLocked(p, a);
            return false;
        }
        if (c.getBoolean("blocked-in-combat", false) && inCombat(p)) {
            plugin.send(p, "ability-combat", "ability", a.name());
            return false;
        }

        long now = System.currentTimeMillis();
        long globalCd = (long) (plugin.getConfig().getDouble("abilities.global-cooldown", 1.0) * 1000);
        Long la = lastAny.get(p.getUniqueId());
        if (la != null && now - la < globalCd) return false;

        Map<String, Long> cds = cooldowns.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
        long until = cds.getOrDefault(a.id(), 0L);
        if (now < until) {
            plugin.send(p, "ability-cooldown", "ability", a.name(), "seconds", (until - now + 999) / 1000);
            return false;
        }

        if (!a.exec().run(p, c)) return false;

        cds.put(a.id(), now + (long) (c.getDouble("cooldown", 10) * cooldownMult(p, a.id()) * 1000));
        lastAny.put(p.getUniqueId(), now);
        lastUsed.put(p.getUniqueId(), a.id());
        plugin.quests().add(p, "USE_ABILITY", 1);
        plugin.hud().flash(p, Util.color("&6" + a.name() + " &e" + plugin.ui("hud.activated", "activated!")));
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
        return true;
    }

    // ---------- built-in abilities ----------

    /** All abilities live in WeaponAbilities, grouped by weapon category. */
    public void registerDefaults() {
        weapons = new WeaponAbilities(plugin, this);
        weapons.register();
    }
}
