package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

/** Kill feed, kill-streak announcements and bounties (players on a long streak carry a bounty). */
public class BountyManager {
    private final StrengthSMP plugin;

    public BountyManager(StrengthSMP plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("bounty.enabled", true);
    }

    public int minStreak() {
        return Math.max(1, plugin.getConfig().getInt("bounty.min-streak", 5));
    }

    public boolean hasBounty(PlayerData d) {
        return enabled() && d.streak >= minStreak();
    }

    /** Called for every valid PvP kill (even when anti-farm gives no reward). */
    public void announceKill(Player killer, Player victim, int killerStreak, int victimStreak) {
        FileConfiguration c = plugin.getConfig();
        if (c.getBoolean("killfeed.enabled", true)) {
            Bukkit.broadcast(plugin.msg("kill-feed", "killer", killer.getName(), "victim", victim.getName()));
        }
        if (victimStreak >= c.getInt("killstreak.end-announce-min", 3)) {
            Bukkit.broadcast(plugin.msg("streak-ended", "killer", killer.getName(),
                    "victim", victim.getName(), "streak", victimStreak));
        }
        if (enabled() && killerStreak == minStreak()) {
            Bukkit.broadcast(plugin.msg("bounty-placed", "player", killer.getName(), "streak", killerStreak));
        } else if (c.getIntegerList("killstreak.announce-at").contains(killerStreak)) {
            Bukkit.broadcast(plugin.msg("streak-announce", "player", killer.getName(), "streak", killerStreak));
        }
    }

    /** Called for a rewarded kill; pays out if the victim carried a bounty. */
    public void claim(Player killer, Player victim, int victimStreak) {
        if (!enabled() || victimStreak < minStreak()) return;
        FileConfiguration c = plugin.getConfig();
        Bukkit.broadcast(plugin.msg("bounty-claimed", "killer", killer.getName(), "victim", victim.getName()));
        int extra = c.getInt("bounty.reward-strength", 0);
        if (extra > 0) {
            plugin.strength().setStrength(killer, plugin.data().get(killer).strength + extra, true);
        }
        for (String spec : c.getStringList("bounty.reward-items")) {
            plugin.strength().giveItemSpec(killer, spec);
        }
        for (String cmd : c.getStringList("bounty.reward-commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", killer.getName()));
        }
    }
}
