package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Trident;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * All weapon-category abilities (sword, axe, mace, shield, trident, bow, crossbow).
 * No ability here ever breaks blocks. Everything is server-side, so Java and Bedrock (Geyser) behave the same.
 *
 * Ranged abilities (trident / bow / crossbow) "arm" the next shot: the cooldown starts when you use the
 * ability, and the next projectile you fire gets the effect.
 */
public class WeaponAbilities {

    private record Mark(UUID victim, long until) {
    }

    private static final Set<String> TRIDENT_IDS = Set.of("thunder_throw", "whirlpool", "poseidon_wrath", "kraken_grasp");
    private static final Set<String> ON_HIT_IDS = Set.of("thunder_throw", "whirlpool", "explosive_arrow", "blast_bolt", "lightning_arrow", "thunder_bolt");

    private final StrengthSMP plugin;
    private final AbilityManager am;
    private final NamespacedKey tagKey;
    private final Random random = new Random();

    private final Map<UUID, String> armed = new HashMap<>();
    private final Map<UUID, Long> armorBroken = new HashMap<>();
    private final Map<UUID, Mark> marks = new HashMap<>();
    private final Set<UUID> meteor = new HashSet<>();

    public WeaponAbilities(StrengthSMP plugin, AbilityManager am) {
        this.plugin = plugin;
        this.am = am;
        this.tagKey = new NamespacedKey(plugin, "ability");
    }

    // =====================================================================
    //  registration
    // =====================================================================

    public void register() {
        registerSword();
        registerAxe();
        registerMace();
        registerShield();
        registerTrident();
        registerBow();
        registerCrossbow();

        // Item-only ability (Thunder Sword). Not part of any weapon category, so it never shows in the menu.
        am.register("lightning", "Lightning Strike", "Call lightning on the target you are looking at.",
                Material.LIGHTNING_ROD, (p, c) -> {
                    Entity t = p.getTargetEntity(c.getInt("range", 20));
                    if (!(t instanceof LivingEntity le) || !am.canHarm(p, le)) {
                        plugin.hud().flash(p, Util.color("&cNo valid target."));
                        return false;
                    }
                    if (c.getBoolean("real-lightning", false)) le.getWorld().strikeLightning(le.getLocation());
                    else le.getWorld().strikeLightningEffect(le.getLocation());
                    am.damage(p, le, c.getDouble("damage", 6.0));
                    return true;
                });
    }

    // ---------------------------------------------------------------- SWORD

    private void registerSword() {
        am.register("dash", "Dash", "Dash forward quickly.", Material.FEATHER, "sword", (p, c) -> {
            Vector dir = p.getLocation().getDirection().setY(0);
            if (dir.lengthSquared() < 0.0001) dir = new Vector(0, 0, 1);
            dir.normalize().multiply(c.getDouble("power", 1.8)).setY(c.getDouble("lift", 0.25));
            p.setVelocity(dir);
            am.activate(p, "nofall", 3);
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1f);
            p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 15, 0.3, 0.1, 0.3, 0.02);
            return true;
        });

        am.register("lifesteal", "Lifesteal", "Heal for 20% of the damage you deal.",
                Material.GHAST_TEAR, "sword", (p, c) -> {
                    am.activate(p, "lifesteal", c.getDouble("duration", 6));
                    p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.8, 0), 6, 0.3, 0.2, 0.3, 0);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITCH_DRINK, 1f, 1f);
                    return true;
                });

        am.register("berserker", "Berserker", "Deal 30% more damage for a few seconds.",
                Material.NETHERITE_SWORD, "sword", (p, c) -> {
                    am.activate(p, "berserker", c.getDouble("duration", 6));
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1f, 1f);
                    return true;
                });

        am.register("shadow_strike", "Shadow Strike", "Teleport behind a target within 5 blocks. Your next hit deals bonus damage.",
                Material.ENDER_EYE, "sword", (p, c) -> {
                    LivingEntity t = findTarget(p, c.getDouble("range", 5));
                    if (t == null) {
                        plugin.hud().flash(p, Util.color("&cNo target within range."));
                        return false;
                    }
                    Vector back = t.getLocation().getDirection().setY(0);
                    if (back.lengthSquared() < 0.0001) back = p.getLocation().getDirection().setY(0);
                    if (back.lengthSquared() < 0.0001) return false;
                    back.normalize();
                    Location dest = null;
                    for (double d : new double[]{1.5, 1.0}) {
                        Location cand = t.getLocation().clone().subtract(back.clone().multiply(d));
                        if (safeSpot(cand)) {
                            dest = cand;
                            break;
                        }
                    }
                    if (dest == null) {
                        plugin.hud().flash(p, Util.color("&cNo room behind the target."));
                        return false;
                    }
                    dest.setDirection(t.getEyeLocation().toVector().subtract(dest.clone().add(0, 1.62, 0).toVector()));
                    p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.2);
                    p.teleport(dest);
                    p.getWorld().spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.2);
                    p.getWorld().playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
                    am.activate(p, "shadow_strike", c.getDouble("window", 5));
                    return true;
                });

        am.register("blood_rage", "Blood Rage", "Attack faster for 5 seconds, but take 15% more damage.",
                Material.REDSTONE, "sword", (p, c) -> {
                    double dur = c.getDouble("duration", 5);
                    am.activate(p, "blood_rage", dur);
                    p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, (int) (dur * 20),
                            c.getInt("haste-amplifier", 2), false, false));
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.1);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WOLF_GROWL, 1f, 0.8f);
                    return true;
                });

        am.register("blade_storm", "Blade Storm", "Spin and slash every enemy around you.",
                Material.DIAMOND_SWORD, "sword", (p, c) -> {
                    double r = c.getDouble("radius", 3.5);
                    double dmg = c.getDouble("damage", 5.0);
                    double kb = c.getDouble("knockback", 0.6);
                    for (LivingEntity le : enemiesAround(p, r)) {
                        am.damage(p, le, dmg);
                        launch(le, away(p.getLocation(), le.getLocation(), kb, 0.3));
                    }
                    p.getWorld().spawnParticle(Particle.SWEEP_ATTACK, p.getLocation().add(0, 1, 0), 12, r / 2, 0.3, r / 2, 0);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.8f);
                    return true;
                });

        am.register("parry", "Parry", "Take 80% less damage for a very short time.",
                Material.IRON_SWORD, "sword", (p, c) -> {
                    am.activate(p, "parry", c.getDouble("duration", 1.5));
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1.4f);
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.1);
                    return true;
                });

        am.register("crescent_slash", "Crescent Slash", "Send a slash forward that damages every enemy in its path.",
                Material.GOLDEN_SWORD, "sword", (p, c) -> {
                    if (!lineWave(p, c.getDouble("length", 9), c.getDouble("damage", 6.0),
                            c.getDouble("knockback", 0.5), Particle.SWEEP_ATTACK)) return false;
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.6f);
                    return true;
                });

        am.register("rending_strike", "Rending Strike", "Your next hit makes the target bleed for a few seconds.",
                Material.REDSTONE_BLOCK, "sword", (p, c) -> {
                    am.activate(p, "rending_strike", c.getDouble("window", 8));
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1f, 0.8f);
                    return true;
                });

        am.register("phantom_step", "Phantom Step", "Become fast and nearly invisible for a few seconds.",
                Material.PHANTOM_MEMBRANE, "sword", (p, c) -> {
                    double dur = c.getDouble("duration", 4);
                    pot(p, PotionEffectType.SPEED, dur, c.getInt("speed-amplifier", 2));
                    pot(p, PotionEffectType.INVISIBILITY, dur, 0);
                    p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 30, 0.3, 0.6, 0.3, 0.3);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.6f);
                    return true;
                });
    }

    // ---------------------------------------------------------------- AXE

    private void registerAxe() {
        am.register("ground_slam", "Ground Slam", "Slam the ground, damaging and knocking back nearby enemies.",
                Material.IRON_AXE, "axe", (p, c) -> {
                    double r = c.getDouble("radius", 5);
                    double dmg = c.getDouble("damage", 6.0);
                    double kb = c.getDouble("knockback", 1.0);
                    for (Entity en : p.getNearbyEntities(r, r / 2, r)) {
                        if (en instanceof LivingEntity le && am.canHarm(p, le)) {
                            am.damage(p, le, dmg);
                            launch(le, away(p.getLocation(), le.getLocation(), kb, 0.45));
                        }
                    }
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 40, r / 2, 0.2, r / 2, 0.1);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
                    return true;
                });

        am.register("armor_break", "Armor Break", "Your next hit lowers the target's damage resistance for 4 seconds.",
                Material.NETHERITE_AXE, "axe", (p, c) -> {
                    am.activate(p, "armor_break", c.getDouble("window", 8));
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BREAK, 1f, 1f);
                    return true;
                });

        am.register("heavy_strike", "Heavy Strike", "Your next axe hit deals 50% bonus damage.",
                Material.DIAMOND_AXE, "axe", (p, c) -> {
                    am.activate(p, "heavy_strike", c.getDouble("window", 10));
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_AXE_STRIP, 1f, 0.6f);
                    return true;
                });

        am.register("earthquake", "Earthquake", "A shockwave around you pushes nearby enemies away.",
                Material.COBBLESTONE, "axe", (p, c) -> {
                    double r = c.getDouble("radius", 6);
                    double kb = c.getDouble("knockback", 1.6);
                    for (Entity en : p.getNearbyEntities(r, r / 2, r)) {
                        if (en instanceof LivingEntity le && am.canHarm(p, le)) {
                            launch(le, away(p.getLocation(), le.getLocation(), kb, 0.4));
                        }
                    }
                    Location base = p.getLocation();
                    for (int i = 0; i < 24; i++) {
                        double a = Math.PI * 2 * i / 24.0;
                        base.getWorld().spawnParticle(Particle.CLOUD,
                                base.clone().add(Math.cos(a) * r * 0.8, 0.1, Math.sin(a) * r * 0.8), 2, 0.1, 0.05, 0.1, 0.01);
                    }
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.6f);
                    return true;
                });

        am.register("iron_will", "Iron Will", "Take 35% less damage for 4 seconds.",
                Material.IRON_CHESTPLATE, "axe", (p, c) -> {
                    am.activate(p, "iron_will", c.getDouble("duration", 4));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_PLACE, 0.7f, 1.2f);
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.05);
                    return true;
                });

        am.register("cleave", "Cleave", "Swing through every enemy in front of you.",
                Material.GOLDEN_AXE, "axe", (p, c) -> {
                    Vector dir = p.getLocation().getDirection().setY(0);
                    if (dir.lengthSquared() < 0.0001) return false;
                    dir.normalize();
                    for (LivingEntity le : enemiesAround(p, c.getDouble("range", 4.5))) {
                        Vector to = le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
                        if (to.lengthSquared() > 0.0001 && to.clone().normalize().dot(dir) < 0.3) continue;
                        am.damage(p, le, c.getDouble("damage", 6.0));
                        launch(le, away(p.getLocation(), le.getLocation(), c.getDouble("knockback", 0.7), 0.3));
                    }
                    p.getWorld().spawnParticle(Particle.SWEEP_ATTACK, p.getLocation().add(dir.clone().multiply(1.5)).add(0, 1, 0), 6, 0.8, 0.3, 0.8, 0);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 0.5f);
                    return true;
                });

        am.register("war_cry", "War Cry", "Weaken nearby enemies and speed yourself up.",
                Material.STONE_AXE, "axe", (p, c) -> {
                    double dur = c.getDouble("duration", 5);
                    for (LivingEntity le : enemiesAround(p, c.getDouble("radius", 7))) {
                        pot(le, PotionEffectType.WEAKNESS, dur, c.getInt("weakness-amplifier", 0));
                    }
                    pot(p, PotionEffectType.SPEED, dur, c.getInt("speed-amplifier", 1));
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1, 0), 30, 1.0, 0.5, 1.0, 0.1);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1f, 0.9f);
                    return true;
                });

        am.register("executioner", "Executioner", "Your next axe hit deals huge bonus damage to a target below 40% health.",
                Material.WOODEN_AXE, "axe", (p, c) -> {
                    am.activate(p, "executioner", c.getDouble("window", 10));
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_AXE_STRIP, 1f, 0.5f);
                    return true;
                });

        am.register("stagger", "Stagger", "Your next axe hit nearly stops the target for a moment.",
                Material.ANVIL, "axe", (p, c) -> {
                    am.activate(p, "stagger", c.getDouble("window", 8));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_PLACE, 0.7f, 0.8f);
                    return true;
                });

        am.register("savage_leap", "Savage Leap", "Leap forward through the air without taking fall damage.",
                Material.RABBIT_FOOT, "axe", (p, c) -> {
                    Vector dir = p.getLocation().getDirection().setY(0);
                    if (dir.lengthSquared() < 0.0001) dir = new Vector(0, 0, 1);
                    dir.normalize().multiply(c.getDouble("power", 1.3)).setY(c.getDouble("lift", 0.8));
                    p.setVelocity(dir);
                    am.activate(p, "nofall", 6);
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 20, 0.3, 0.1, 0.3, 0.05);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 1f);
                    return true;
                });
    }

    // ---------------------------------------------------------------- MACE

    private void registerMace() {
        am.register("meteor_smash", "Meteor Smash", "Jump into the air and slam down, damaging enemies where you land.",
                Material.MACE, "mace", (p, c) -> {
                    if (!meteor.add(p.getUniqueId())) return false;
                    Vector v = p.getVelocity();
                    v.setY(c.getDouble("lift", 1.1));
                    p.setVelocity(v);
                    am.activate(p, "nofall", 10);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 1f);
                    startMeteor(p, c);
                    return true;
                });

        am.register("gravity_crush", "Gravity Crush", "Pull nearby enemies toward you.",
                Material.ENDER_PEARL, "mace", (p, c) -> {
                    double r = c.getDouble("radius", 7);
                    double power = c.getDouble("power", 1.1);
                    pullToward(p, p.getLocation(), r, power);
                    p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 60, r / 3, 0.8, r / 3, 0.5);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);
                    return true;
                });

        am.register("seismic_wave", "Seismic Wave", "Send a wave forward that damages and knocks back enemies.",
                Material.DEEPSLATE, "mace", (p, c) -> {
                    Vector dir = p.getLocation().getDirection().setY(0);
                    if (dir.lengthSquared() < 0.0001) return false;
                    dir.normalize();
                    double length = c.getDouble("length", 10);
                    double dmg = c.getDouble("damage", 6.0);
                    double kb = c.getDouble("knockback", 1.2);
                    Set<UUID> hit = new HashSet<>();
                    World w = p.getWorld();
                    Location origin = p.getLocation();
                    for (int i = 1; i <= (int) length; i++) {
                        Location pt = origin.clone().add(dir.clone().multiply(i));
                        if (!pt.getBlock().isPassable() && !pt.clone().add(0, 1, 0).getBlock().isPassable()) break;
                        w.spawnParticle(Particle.CLOUD, pt.clone().add(0, 0.2, 0), 4, 0.3, 0.1, 0.3, 0.02);
                        w.spawnParticle(Particle.CRIT, pt.clone().add(0, 0.5, 0), 3, 0.3, 0.2, 0.3, 0.1);
                        for (Entity en : w.getNearbyEntities(pt, 1.3, 1.6, 1.3)) {
                            if (en instanceof LivingEntity le && am.canHarm(p, le) && hit.add(le.getUniqueId())) {
                                am.damage(p, le, dmg);
                                launch(le, dir.clone().multiply(kb).setY(0.4));
                            }
                        }
                    }
                    w.playSound(origin, Sound.ENTITY_WARDEN_SONIC_CHARGE, 0.6f, 1.6f);
                    return true;
                });

        am.register("overcharge", "Overcharge", "Your next mace hit deals 40% bonus damage.",
                Material.BLAZE_POWDER, "mace", (p, c) -> {
                    am.activate(p, "overcharge", c.getDouble("window", 10));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.4f);
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.1);
                    return true;
                });

        am.register("unstoppable", "Unstoppable", "Gain knockback resistance for 5 seconds.",
                Material.NETHERITE_INGOT, "mace", (p, c) -> {
                    double dur = c.getDouble("duration", 5);
                    am.activate(p, "unstoppable", dur);
                    AttributeInstance inst = p.getAttribute(Util.knockbackResistance());
                    if (inst != null) {
                        final AttributeModifier mod = new AttributeModifier(
                                new NamespacedKey(plugin, "unstoppable"), 1.0, AttributeModifier.Operation.ADD_NUMBER);
                        inst.addTransientModifier(mod);
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            AttributeInstance now = p.getAttribute(Util.knockbackResistance());
                            if (now != null) now.removeModifier(mod);
                        }, (long) (dur * 20));
                    }
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_NETHERITE, 1f, 1f);
                    return true;
                });

        am.register("lunge", "Lunge", "Lunge forward and smash every enemy in your path.",
                Material.IRON_BOOTS, "mace", (p, c) -> {
                    Vector dir = p.getLocation().getDirection().setY(0);
                    if (dir.lengthSquared() < 0.0001) dir = new Vector(0, 0, 1);
                    dir.normalize();
                    Location ahead = p.getLocation().add(dir.clone().multiply(c.getDouble("reach", 2.5)));
                    double r = c.getDouble("radius", 2.5);
                    for (Entity en : ahead.getWorld().getNearbyEntities(ahead, r, r, r)) {
                        if (en instanceof LivingEntity le && am.canHarm(p, le)) {
                            am.damage(p, le, c.getDouble("damage", 6.0));
                            launch(le, away(p.getLocation(), le.getLocation(), c.getDouble("knockback", 0.9), 0.35));
                        }
                    }
                    Vector v = dir.clone().multiply(c.getDouble("power", 1.7)).setY(c.getDouble("lift", 0.3));
                    p.setVelocity(v);
                    am.activate(p, "nofall", 4);
                    p.getWorld().spawnParticle(Particle.EXPLOSION, ahead, 2, 0.5, 0.2, 0.5, 0);
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 15, 0.3, 0.1, 0.3, 0.03);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 0.9f);
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_MACE_SMASH_GROUND, 0.8f, 1.2f);
                    return true;
                });

        am.register("crater_stomp", "Crater Stomp", "Stomp the ground to damage and slow nearby enemies.",
                Material.COBBLED_DEEPSLATE, "mace", (p, c) -> {
                    for (LivingEntity le : enemiesAround(p, c.getDouble("radius", 4.5))) {
                        am.damage(p, le, c.getDouble("damage", 5.0));
                        pot(le, PotionEffectType.SLOWNESS, c.getDouble("slow-seconds", 3), c.getInt("slow-amplifier", 1));
                        launch(le, away(p.getLocation(), le.getLocation(), c.getDouble("knockback", 0.8), 0.4));
                    }
                    p.getWorld().spawnParticle(Particle.EXPLOSION, p.getLocation(), 3, 1.5, 0.2, 1.5, 0);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.7f);
                    return true;
                });

        am.register("skyfall", "Skyfall", "Launch yourself very high. You take no fall damage.",
                Material.FIREWORK_ROCKET, "mace", (p, c) -> {
                    Vector v = p.getVelocity();
                    v.setY(c.getDouble("lift", 1.8));
                    p.setVelocity(v);
                    am.activate(p, "nofall", 10);
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 25, 0.3, 0.1, 0.3, 0.05);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 0.8f);
                    return true;
                });

        am.register("bone_crusher", "Bone Crusher", "Your next mace hit deals bonus damage and cripples the target.",
                Material.BONE, "mace", (p, c) -> {
                    am.activate(p, "bone_crusher", c.getDouble("window", 10));
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_SKELETON_HURT, 1f, 0.6f);
                    return true;
                });

        am.register("thunderclap", "Thunderclap", "A booming clap that damages and stuns nearby enemies.",
                Material.BELL, "mace", (p, c) -> {
                    for (LivingEntity le : enemiesAround(p, c.getDouble("radius", 5))) {
                        am.damage(p, le, c.getDouble("damage", 3.0));
                        pot(le, PotionEffectType.SLOWNESS, c.getDouble("stun-seconds", 1.5), 5);
                    }
                    p.getWorld().spawnParticle(Particle.EXPLOSION, p.getLocation().add(0, 1, 0), 2, 1.5, 0.3, 1.5, 0);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.7f, 1.4f);
                    return true;
                });

        am.register("dust_storm", "Dust Storm", "Blind nearby enemies while you move faster.",
                Material.SAND, "mace", (p, c) -> {
                    for (LivingEntity le : enemiesAround(p, c.getDouble("radius", 6))) {
                        pot(le, PotionEffectType.BLINDNESS, c.getDouble("blind-seconds", 3), 0);
                    }
                    pot(p, PotionEffectType.SPEED, c.getDouble("speed-seconds", 4), 1);
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1, 0), 80, 2.0, 0.8, 2.0, 0.05);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 0.6f);
                    return true;
                });
    }

    private void startMeteor(Player p, ConfigurationSection c) {
        final UUID id = p.getUniqueId();
        final double dive = c.getDouble("dive-speed", 2.0);
        final double radius = c.getDouble("radius", 4);
        final double dmg = c.getDouble("damage", 8.0);
        final double kb = c.getDouble("knockback", 0.9);
        new BukkitRunnable() {
            int ticks = 0;
            boolean diving = false;

            @Override
            public void run() {
                ticks++;
                if (!p.isOnline() || p.isDead() || ticks > 100) {
                    meteor.remove(id);
                    cancel();
                    return;
                }
                Vector v = p.getVelocity();
                if (!diving) {
                    if (ticks >= 3 && v.getY() <= 0.05) {
                        diving = true;
                        p.setVelocity(new Vector(0, -dive, 0));
                    }
                    return;
                }
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 4, 0.25, 0.25, 0.25, 0.01);
                boolean landed = p.isOnGround()
                        || p.getLocation().clone().subtract(0, 0.4, 0).getBlock().getType().isSolid();
                if (!landed) {
                    if (v.getY() > -dive * 0.6) p.setVelocity(v.setY(-dive));
                    return;
                }
                Location l = p.getLocation();
                for (Entity en : p.getNearbyEntities(radius, radius / 2, radius)) {
                    if (en instanceof LivingEntity le && am.canHarm(p, le)) {
                        am.damage(p, le, dmg);
                        launch(le, away(l, le.getLocation(), kb, 0.5));
                    }
                }
                l.getWorld().spawnParticle(Particle.EXPLOSION, l, 3, radius / 3, 0.2, radius / 3, 0);
                l.getWorld().spawnParticle(Particle.CLOUD, l, 40, radius / 2, 0.2, radius / 2, 0.1);
                l.getWorld().playSound(l, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.8f);
                meteor.remove(id);
                cancel();
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }

    // ---------------------------------------------------------------- SHIELD

    private void registerShield() {
        am.register("reflect", "Reflect", "Reflect 30% of incoming damage back to the attacker for 5 seconds.",
                Material.GOLDEN_CHESTPLATE, "shield", (p, c) -> {
                    am.activate(p, "reflect", c.getDouble("duration", 5));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.5f);
                    p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 15, 0.4, 0.6, 0.4, 0.02);
                    return true;
                });

        am.register("fortress", "Fortress", "Take 50% less damage for 5 seconds, but move slower.",
                Material.SHIELD, "shield", (p, c) -> {
                    double dur = c.getDouble("duration", 5);
                    am.activate(p, "fortress", dur);
                    p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (dur * 20),
                            c.getInt("slow-amplifier", 1), false, false));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6f, 1.4f);
                    return true;
                });

        am.register("shield_bash", "Shield Bash", "Hit an enemy with your shield for damage and knockback.",
                Material.IRON_INGOT, "shield", (p, c) -> {
                    LivingEntity t = findTarget(p, c.getDouble("range", 3.5));
                    if (t == null) {
                        plugin.hud().flash(p, Util.color("&cNo enemy in front of you."));
                        return false;
                    }
                    am.damage(p, t, c.getDouble("damage", 4.0));
                    launch(t, away(p.getLocation(), t.getLocation(), c.getDouble("knockback", 1.4), 0.35));
                    t.getWorld().playSound(t.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 0.8f);
                    t.getWorld().spawnParticle(Particle.CRIT, t.getLocation().add(0, 1, 0), 12, 0.3, 0.4, 0.3, 0.1);
                    return true;
                });

        am.register("counterattack", "Counterattack", "Block an attack to make your next hit deal bonus damage.",
                Material.CLOCK, "shield", (p, c) -> {
                    am.activate(p, "counterattack", c.getDouble("window", 4));
                    plugin.hud().flash(p, Util.color("&eBlock an attack!"));
                    return true;
                });

        am.register("taunt", "Taunt", "Mark nearby enemies with a glow and weaken them. You take a bit less damage.",
                Material.GOAT_HORN, "shield", (p, c) -> {
                    for (LivingEntity le : enemiesAround(p, c.getDouble("radius", 8))) {
                        pot(le, PotionEffectType.GLOWING, c.getDouble("glow-seconds", 5), 0);
                        pot(le, PotionEffectType.WEAKNESS, c.getDouble("weakness-seconds", 4), 0);
                    }
                    pot(p, PotionEffectType.RESISTANCE, 4, 0);
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 30, 1.0, 0.6, 1.0, 0.1);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1f, 1.2f);
                    return true;
                });

        am.register("aegis", "Aegis", "Gain extra absorption hearts for a few seconds.",
                Material.GOLDEN_APPLE, "shield", (p, c) -> {
                    pot(p, PotionEffectType.ABSORPTION, c.getDouble("duration", 10), c.getInt("amplifier", 1));
                    p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.02);
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.0f);
                    return true;
                });

        am.register("shield_charge", "Shield Charge", "Charge forward, hitting and pushing enemies in front of you.",
                Material.SHIELD, "shield", (p, c) -> {
                    Vector dir = p.getLocation().getDirection().setY(0);
                    if (dir.lengthSquared() < 0.0001) return false;
                    dir.normalize();
                    for (LivingEntity le : enemiesAround(p, c.getDouble("range", 3.5))) {
                        Vector to = le.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
                        if (to.lengthSquared() > 0.0001 && to.clone().normalize().dot(dir) < 0.5) continue;
                        am.damage(p, le, c.getDouble("damage", 3.0));
                        launch(le, dir.clone().multiply(c.getDouble("knockback", 1.2)).setY(0.35));
                    }
                    p.setVelocity(dir.clone().multiply(c.getDouble("power", 1.5)).setY(0.2));
                    am.activate(p, "nofall", 3);
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 15, 0.3, 0.1, 0.3, 0.02);
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 0.7f);
                    return true;
                });

        am.register("second_wind", "Second Wind", "Instantly heal some of your health.",
                Material.GLISTERING_MELON_SLICE, "shield", (p, c) -> {
                    if (!heal(p, c.getDouble("heal", 6.0))) {
                        plugin.hud().flash(p, Util.color("&cYou are already at full health."));
                        return false;
                    }
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.4f);
                    return true;
                });

        am.register("last_stand", "Last Stand", "Heal a little and take much less damage for a few seconds.",
                Material.TOTEM_OF_UNDYING, "shield", (p, c) -> {
                    heal(p, c.getDouble("heal", 4.0));
                    pot(p, PotionEffectType.RESISTANCE, c.getDouble("duration", 4), c.getInt("amplifier", 2));
                    p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.03);
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 0.6f);
                    return true;
                });

        am.register("repel", "Repel", "Blast nearby enemies away from you and slow them.",
                Material.IRON_BLOCK, "shield", (p, c) -> {
                    for (LivingEntity le : enemiesAround(p, c.getDouble("radius", 5))) {
                        launch(le, away(p.getLocation(), le.getLocation(), c.getDouble("knockback", 2.0), 0.5));
                        pot(le, PotionEffectType.SLOWNESS, c.getDouble("slow-seconds", 2), 1);
                    }
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().add(0, 1, 0), 40, 1.5, 0.4, 1.5, 0.1);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.7f, 1.4f);
                    return true;
                });
    }

    // ---------------------------------------------------------------- TRIDENT

    private void registerTrident() {
        armAbility("thunder_throw", "Thunder Throw", "Your next trident throw is lightning-powered.", Material.TRIDENT, "trident");

        am.register("tidal_rush", "Tidal Rush", "Launch yourself forward toward your target.",
                Material.HEART_OF_THE_SEA, "trident", (p, c) -> {
                    LivingEntity t = findTarget(p, c.getDouble("range", 15));
                    Vector dir = p.getLocation().getDirection();
                    if (t != null) {
                        dir = t.getEyeLocation().toVector().subtract(p.getEyeLocation().toVector());
                        if (dir.lengthSquared() < 0.0001) return false;
                    }
                    double power = c.getDouble("power", 1.9);
                    if (t != null) {
                        double dist = p.getLocation().distance(t.getLocation());
                        power = Math.min(power, Math.max(0.6, dist * 0.35));
                    }
                    Vector v = dir.clone().normalize().multiply(power);
                    v.setY(Math.max(v.getY(), 0.25));
                    p.setVelocity(v);
                    am.activate(p, "nofall", 4);
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_1, 1f, 1f);
                    p.getWorld().spawnParticle(Particle.BUBBLE_POP, p.getLocation().add(0, 1, 0), 25, 0.4, 0.5, 0.4, 0.05);
                    return true;
                });

        armAbility("whirlpool", "Whirlpool", "Your next trident throw pulls nearby enemies toward the impact point.",
                Material.PRISMARINE_SHARD, "trident");

        am.register("storm_call", "Storm Call", "Call a small lightning storm around the target area.",
                Material.LIGHTNING_ROD, "trident", (p, c) -> {
                    double range = c.getDouble("range", 25);
                    Location center;
                    Entity te = p.getTargetEntity((int) range);
                    if (te != null) {
                        center = te.getLocation();
                    } else {
                        RayTraceResult r = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(), range);
                        if (r == null) {
                            plugin.hud().flash(p, Util.color("&cNo target area."));
                            return false;
                        }
                        center = r.getHitPosition().toLocation(p.getWorld());
                    }
                    final Location base = center.clone();
                    final int strikes = c.getInt("strikes", 4);
                    final double spread = c.getDouble("spread", 3.0);
                    final double dmg = c.getDouble("damage", 4.0);
                    final double hitRadius = c.getDouble("hit-radius", 2.5);
                    for (int i = 0; i < strikes; i++) {
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            if (!p.isOnline()) return;
                            Location s = base.clone().add((random.nextDouble() - 0.5) * 2 * spread, 0,
                                    (random.nextDouble() - 0.5) * 2 * spread);
                            s.getWorld().strikeLightningEffect(s);
                            for (Entity en : s.getWorld().getNearbyEntities(s, hitRadius, hitRadius + 1, hitRadius)) {
                                if (en instanceof LivingEntity le && am.canHarm(p, le)) am.damage(p, le, dmg);
                            }
                        }, i * 6L);
                    }
                    return true;
                });

        am.register("water_jet", "Water Jet", "Shoot a jet of water forward that damages enemies in its path.",
                Material.PRISMARINE_CRYSTALS, "trident", (p, c) -> {
                    if (!lineWave(p, c.getDouble("length", 12), c.getDouble("damage", 5.0),
                            c.getDouble("knockback", 0.8), Particle.BUBBLE_POP)) return false;
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1f, 1.2f);
                    return true;
                });

        am.register("ocean_blessing", "Ocean Blessing", "Swim faster, breathe underwater and regenerate for a while.",
                Material.NAUTILUS_SHELL, "trident", (p, c) -> {
                    double dur = c.getDouble("duration", 8);
                    pot(p, PotionEffectType.DOLPHINS_GRACE, dur, 0);
                    pot(p, PotionEffectType.WATER_BREATHING, dur, 0);
                    pot(p, PotionEffectType.REGENERATION, dur, 0);
                    p.getWorld().spawnParticle(Particle.BUBBLE_POP, p.getLocation().add(0, 1, 0), 30, 0.5, 0.7, 0.5, 0.05);
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.2f);
                    return true;
                });

        am.register("tsunami", "Tsunami", "A wave of water damages and throws back everyone around you.",
                Material.KELP, "trident", (p, c) -> {
                    double r = c.getDouble("radius", 7);
                    for (LivingEntity le : enemiesAround(p, r)) {
                        am.damage(p, le, c.getDouble("damage", 4.0));
                        launch(le, away(p.getLocation(), le.getLocation(), c.getDouble("knockback", 1.8), 0.5));
                    }
                    p.getWorld().spawnParticle(Particle.BUBBLE_POP, p.getLocation().add(0, 1, 0), 80, r / 2, 0.6, r / 2, 0.1);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1f, 0.6f);
                    return true;
                });

        armAbility("poseidon_wrath", "Poseidon's Wrath", "Your next trident throw deals 60% bonus damage.",
                Material.CONDUIT, "trident");

        armAbility("kraken_grasp", "Kraken Grasp", "Your next trident throw holds the target in place for a moment.",
                Material.INK_SAC, "trident");

        am.register("tempest", "Tempest", "Lightning strikes randomly all around you, hitting enemies but never you.",
                Material.LIGHTNING_ROD, "trident", (p, c) -> {
                    final int strikes = c.getInt("strikes", 5);
                    final double radius = c.getDouble("radius", 6);
                    final double dmg = c.getDouble("damage", 4.0);
                    final double hitRadius = c.getDouble("hit-radius", 2.5);
                    for (int i = 0; i < strikes; i++) {
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            if (!p.isOnline()) return;
                            Location s = p.getLocation().clone().add((random.nextDouble() - 0.5) * 2 * radius, 0,
                                    (random.nextDouble() - 0.5) * 2 * radius);
                            s.getWorld().strikeLightningEffect(s);
                            for (Entity en : s.getWorld().getNearbyEntities(s, hitRadius, hitRadius + 1, hitRadius)) {
                                if (en instanceof LivingEntity le && am.canHarm(p, le)) am.damage(p, le, dmg);
                            }
                        }, i * 5L);
                    }
                    return true;
                });
    }

    // ---------------------------------------------------------------- BOW

    private void registerBow() {
        armAbility("piercing_shot", "Piercing Shot", "Your next arrow deals bonus damage and pierces through enemies.", Material.ARROW, "bow");
        armAbility("frost_arrow", "Frost Arrow", "Your next arrow slows the target for 3 seconds.", Material.SNOWBALL, "bow");
        armAbility("explosive_arrow", "Explosive Arrow", "Your next arrow explodes on impact. No block damage.", Material.TNT, "bow");
        armAbility("marked_target", "Marked Target", "Your next arrow marks the enemy for 6 seconds. Your next hit on them deals bonus damage.",
                Material.SPECTRAL_ARROW, "bow");

        armAbility("poison_arrow", "Poison Arrow", "Your next arrow poisons the target.", Material.SPIDER_EYE, "bow");
        armAbility("flame_arrow", "Flame Arrow", "Your next arrow sets the target on fire.", Material.BLAZE_ROD, "bow");
        armAbility("gale_arrow", "Gale Arrow", "Your next arrow blasts the target away from you.", Material.FEATHER, "bow");
        armAbility("lightning_arrow", "Lightning Arrow", "Your next arrow calls down lightning where it lands.", Material.LIGHTNING_ROD, "bow");

        am.register("hunters_leap", "Hunter's Leap", "Jump backwards away from danger without taking fall damage.",
                Material.RABBIT_FOOT, "bow", (p, c) -> {
                    Vector dir = p.getLocation().getDirection().setY(0);
                    if (dir.lengthSquared() < 0.0001) return false;
                    dir.normalize().multiply(-c.getDouble("power", 1.5)).setY(0.5);
                    p.setVelocity(dir);
                    am.activate(p, "nofall", 4);
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 15, 0.3, 0.1, 0.3, 0.02);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 1.2f);
                    return true;
                });

        am.register("arrow_rain", "Arrow Rain", "Call a rain of arrows down on the area you are aiming at.",
                Material.FIREWORK_ROCKET, "bow", (p, c) -> {
                    double range = c.getDouble("range", 30);
                    Location center;
                    Entity te = p.getTargetEntity((int) range);
                    if (te != null) {
                        center = te.getLocation();
                    } else {
                        RayTraceResult r = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(), range);
                        if (r == null) {
                            plugin.hud().flash(p, Util.color("&cNo target area."));
                            return false;
                        }
                        center = r.getHitPosition().toLocation(p.getWorld());
                    }
                    final Location base = center.clone();
                    final int arrows = c.getInt("arrows", 10);
                    final double spread = c.getDouble("spread", 3.5);
                    final double height = c.getDouble("height", 12);
                    final double arrowDamage = c.getDouble("arrow-damage", 1.5);
                    for (int i = 0; i < arrows; i++) {
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            if (!p.isOnline()) return;
                            Location s = base.clone().add((random.nextDouble() - 0.5) * 2 * spread, height,
                                    (random.nextDouble() - 0.5) * 2 * spread);
                            base.getWorld().spawn(s, Arrow.class, a -> {
                                a.setShooter(p);
                                a.setVelocity(new Vector((random.nextDouble() - 0.5) * 0.2, -2.5, (random.nextDouble() - 0.5) * 0.2));
                                a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                                a.setCritical(true);
                                a.setDamage(arrowDamage);
                                tag(a, "ability_extra");
                            });
                        }, i * 2L);
                    }
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1f, 0.6f);
                    return true;
                });
    }

    // ---------------------------------------------------------------- CROSSBOW

    private void registerCrossbow() {
        armAbility("multishot_burst", "Multishot Burst", "Your next bolt fires a burst of extra projectiles.", Material.CROSSBOW, "crossbow");
        armAbility("snare_bolt", "Snare Bolt", "Your next bolt slows the target and stops them sprinting briefly.", Material.COBWEB, "crossbow");
        armAbility("blast_bolt", "Blast Bolt", "Your next bolt knocks enemies away on impact. No block damage.", Material.FIRE_CHARGE, "crossbow");
        armAbility("execution_bolt", "Execution Bolt", "Your next bolt deals bonus damage to targets below 30% health.", Material.IRON_SWORD, "crossbow");

        armAbility("harpoon_bolt", "Harpoon Bolt", "Your next bolt yanks the target toward you.", Material.TRIPWIRE_HOOK, "crossbow");
        armAbility("shock_bolt", "Shock Bolt", "Your next bolt briefly stuns the target.", Material.GLOWSTONE_DUST, "crossbow");
        armAbility("venom_bolt", "Venom Bolt", "Your next bolt poisons the target.", Material.FERMENTED_SPIDER_EYE, "crossbow");
        armAbility("thunder_bolt", "Thunder Bolt", "Your next bolt calls down lightning where it lands.", Material.COPPER_INGOT, "crossbow");
        armAbility("sniper_bolt", "Sniper Bolt", "Your next bolt deals big bonus damage to far away targets.", Material.SPYGLASS, "crossbow");

        am.register("bolt_barrage", "Bolt Barrage", "Instantly fire a fan of bolts in front of you.",
                Material.TARGET, "crossbow", (p, c) -> {
                    int count = Math.max(1, c.getInt("projectiles", 5));
                    double spread = c.getDouble("spread-degrees", 10);
                    double speed = c.getDouble("speed", 3.0);
                    Vector base = p.getEyeLocation().getDirection().normalize().multiply(speed);
                    Location start = p.getEyeLocation().add(p.getEyeLocation().getDirection().multiply(0.8));
                    for (int i = 0; i < count; i++) {
                        double angle = Math.toRadians(spread * (i - (count - 1) / 2.0));
                        Vector v = base.clone().rotateAroundY(angle);
                        p.getWorld().spawn(start, Arrow.class, a -> {
                            a.setShooter(p);
                            a.setVelocity(v);
                            a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                            a.setCritical(true);
                            tag(a, "ability_extra");
                        });
                    }
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_CROSSBOW_SHOOT, 1f, 0.8f);
                    return true;
                });
    }

    private void armAbility(String id, String name, String desc, Material icon, String category) {
        am.register(id, name, desc, icon, category, (p, c) -> {
            double secs = c.getDouble("arm-seconds", 10);
            armed.put(p.getUniqueId(), id);
            am.activate(p, id, secs);
            p.getWorld().playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1.6f);
            plugin.hud().flash(p, Util.color("&6" + name + " &earmed - your next shot is empowered!"));
            return true;
        });
    }

    // =====================================================================
    //  state queries used by the listeners
    // =====================================================================

    public boolean hasArmed(Player p) {
        String id = armed.get(p.getUniqueId());
        if (id == null) return false;
        if (!am.isActive(p, id)) {
            armed.remove(p.getUniqueId());
            return false;
        }
        return true;
    }

    public void clearState(UUID id) {
        armed.remove(id);
        marks.remove(id);
        meteor.remove(id);
        armorBroken.remove(id);
    }

    public boolean isArmorBroken(LivingEntity le) {
        Long t = armorBroken.get(le.getUniqueId());
        if (t == null) return false;
        if (System.currentTimeMillis() > t) {
            armorBroken.remove(le.getUniqueId());
            return false;
        }
        return true;
    }

    /** Extra damage reduction (0..1) from Iron Will and Fortress. */
    public double incomingReduction(Player p) {
        double r = 0;
        if (am.isActive(p, "iron_will")) r += am.cfg("iron_will").getDouble("reduction", 0.35);
        if (am.isActive(p, "fortress")) r += am.cfg("fortress").getDouble("reduction", 0.5);
        if (am.isActive(p, "parry")) r += am.cfg("parry").getDouble("reduction", 0.8);
        return r;
    }

    /** Called when a player blocks a hit with a shield. */
    public void onBlocked(Player p) {
        if (!am.isActive(p, "counterattack")) return;
        am.endBuff(p, "counterattack");
        am.activate(p, "counter_ready", am.cfg("counterattack").getDouble("hit-window", 4));
        plugin.hud().flash(p, Util.color("&6Counter ready! &eHit them now."));
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1.6f);
    }

    private boolean consume(Player p, String key) {
        if (!am.isActive(p, key)) return false;
        am.endBuff(p, key);
        return true;
    }

    private static boolean isAxe(ItemStack i) {
        return i != null && i.getType().name().endsWith("_AXE");
    }

    private static boolean isMace(ItemStack i) {
        return i != null && i.getType() == Material.MACE;
    }

    // =====================================================================
    //  outgoing damage: next-hit buffs, marks, tagged projectiles
    // =====================================================================

    public double outgoing(Player attacker, LivingEntity victim, Entity damager, double dmg) {
        boolean melee = damager instanceof Player;
        long now = System.currentTimeMillis();
        Location vl = victim.getLocation().add(0, 1, 0);

        if (melee) {
            ItemStack hand = attacker.getInventory().getItemInMainHand();
            if (consume(attacker, "shadow_strike")) {
                dmg *= 1 + am.cfg("shadow_strike").getDouble("bonus", 0.4);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
            }
            if (isAxe(hand) && consume(attacker, "heavy_strike")) {
                dmg *= 1 + am.cfg("heavy_strike").getDouble("bonus", 0.5);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
                victim.getWorld().playSound(vl, Sound.ENTITY_PLAYER_ATTACK_STRONG, 1f, 0.6f);
            }
            if (isMace(hand) && consume(attacker, "overcharge")) {
                dmg *= 1 + am.cfg("overcharge").getDouble("bonus", 0.4);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
                victim.getWorld().playSound(vl, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.8f);
            }
            if (consume(attacker, "counter_ready")) {
                dmg *= 1 + am.cfg("counterattack").getDouble("bonus", 0.5);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
            }
            if (consume(attacker, "armor_break")) {
                double secs = am.cfg("armor_break").getDouble("duration", 4);
                armorBroken.put(victim.getUniqueId(), now + (long) (secs * 1000));
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 15, 0.3, 0.4, 0.3, 0.1);
                victim.getWorld().playSound(vl, Sound.ITEM_SHIELD_BREAK, 1f, 1f);
            }
            if (consume(attacker, "rending_strike")) {
                ConfigurationSection rc = am.cfg("rending_strike");
                bleed(attacker, victim, rc.getInt("bleed-seconds", 4), rc.getDouble("bleed-damage", 1.5));
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
            }
            if (isAxe(hand) && am.isActive(attacker, "executioner")) {
                ConfigurationSection ec = am.cfg("executioner");
                AttributeInstance exMh = victim.getAttribute(Util.maxHealth());
                double exMax = exMh != null ? exMh.getValue() : 20.0;
                if (victim.getHealth() / exMax < ec.getDouble("threshold", 0.4)) {
                    am.endBuff(attacker, "executioner");
                    dmg *= 1 + ec.getDouble("bonus", 0.8);
                    victim.getWorld().spawnParticle(Particle.CRIT, vl, 30, 0.3, 0.5, 0.3, 0.2);
                    victim.getWorld().playSound(vl, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.6f);
                }
            }
            if (isAxe(hand) && consume(attacker, "stagger")) {
                ConfigurationSection sc = am.cfg("stagger");
                pot(victim, PotionEffectType.SLOWNESS, sc.getDouble("duration", 2), sc.getInt("slow-amplifier", 4));
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 15, 0.3, 0.4, 0.3, 0.1);
                victim.getWorld().playSound(vl, Sound.BLOCK_ANVIL_LAND, 0.6f, 1.4f);
            }
            if (isMace(hand) && consume(attacker, "bone_crusher")) {
                ConfigurationSection bc = am.cfg("bone_crusher");
                dmg *= 1 + bc.getDouble("bonus", 0.3);
                pot(victim, PotionEffectType.SLOWNESS, bc.getDouble("duration", 3), bc.getInt("slow-amplifier", 2));
                pot(victim, PotionEffectType.WEAKNESS, bc.getDouble("duration", 3), 0);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 25, 0.3, 0.4, 0.3, 0.15);
                victim.getWorld().playSound(vl, Sound.ENTITY_SKELETON_HURT, 1f, 0.5f);
            }
        }

        String tag = tagOf(damager);

        // Marked Target: next hit (any weapon) on the marked enemy
        Mark m = marks.get(attacker.getUniqueId());
        if (m != null) {
            if (now > m.until()) {
                marks.remove(attacker.getUniqueId());
                am.endBuff(attacker, "marked_target");
            } else if (m.victim().equals(victim.getUniqueId()) && !"marked_target".equals(tag)) {
                dmg *= 1 + am.cfg("marked_target").getDouble("bonus", 0.4);
                marks.remove(attacker.getUniqueId());
                am.endBuff(attacker, "marked_target");
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
            }
        }

        if (tag == null) return dmg;
        ConfigurationSection c = am.cfg(tag);
        switch (tag) {
            case "piercing_shot" -> dmg *= 1 + c.getDouble("bonus", 0.5);
            case "multishot_extra" -> dmg *= am.cfg("multishot_burst").getDouble("extra-damage", 0.5);
            case "frost_arrow" -> {
                int ticks = (int) (c.getDouble("slow-seconds", 3) * 20);
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, c.getInt("slow-amplifier", 1)));
                victim.setFreezeTicks(Math.min(victim.getMaxFreezeTicks(), ticks));
                victim.getWorld().spawnParticle(Particle.SNOWFLAKE, vl, 25, 0.3, 0.5, 0.3, 0.03);
                victim.getWorld().playSound(vl, Sound.BLOCK_GLASS_BREAK, 1f, 1.4f);
            }
            case "snare_bolt" -> {
                int ticks = (int) (c.getDouble("duration", 2) * 20);
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, c.getInt("slow-amplifier", 1)));
                if (victim instanceof Player vp) blockSprint(vp, ticks);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 15, 0.3, 0.5, 0.3, 0.05);
            }
            case "execution_bolt" -> {
                AttributeInstance mh = victim.getAttribute(Util.maxHealth());
                double max = mh != null ? mh.getValue() : 20.0;
                if (victim.getHealth() / max < c.getDouble("threshold", 0.3)) {
                    dmg *= 1 + c.getDouble("bonus", 0.75);
                    victim.getWorld().spawnParticle(Particle.CRIT, vl, 30, 0.3, 0.5, 0.3, 0.2);
                    victim.getWorld().playSound(vl, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.8f);
                }
            }
            case "marked_target" -> {
                double secs = c.getDouble("mark-seconds", 6);
                marks.put(attacker.getUniqueId(), new Mark(victim.getUniqueId(), now + (long) (secs * 1000)));
                am.activate(attacker, "marked_target", secs);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.5, 0.3, 0.05);
                plugin.hud().flash(attacker, Util.color("&6Target marked!"));
            }
            case "poison_arrow", "venom_bolt" -> {
                pot(victim, PotionEffectType.POISON, c.getDouble("poison-seconds", 4), c.getInt("poison-amplifier", 1));
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 15, 0.3, 0.5, 0.3, 0.05);
            }
            case "flame_arrow" -> {
                victim.setFireTicks((int) (c.getDouble("fire-seconds", 5) * 20));
                victim.getWorld().spawnParticle(Particle.FLAME, vl, 20, 0.3, 0.5, 0.3, 0.02);
            }
            case "gale_arrow" -> {
                final Vector gale = victim.getLocation().toVector().subtract(attacker.getLocation().toVector()).setY(0);
                if (gale.lengthSquared() > 0.0001) {
                    gale.normalize().multiply(c.getDouble("knockback", 1.8)).setY(0.5);
                    Bukkit.getScheduler().runTask(plugin, () -> launch(victim, gale));
                }
                victim.getWorld().spawnParticle(Particle.CLOUD, vl, 20, 0.3, 0.5, 0.3, 0.1);
            }
            case "harpoon_bolt" -> {
                final Vector yank = attacker.getLocation().toVector().subtract(victim.getLocation().toVector());
                if (yank.lengthSquared() > 1.0) {
                    yank.normalize().multiply(c.getDouble("pull-power", 1.4)).setY(0.3);
                    Bukkit.getScheduler().runTask(plugin, () -> launch(victim, yank));
                }
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 15, 0.3, 0.5, 0.3, 0.05);
            }
            case "shock_bolt" -> {
                int shockTicks = (int) (c.getDouble("duration", 1.5) * 20);
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, shockTicks, 5));
                if (victim instanceof Player shocked) blockSprint(shocked, shockTicks);
                victim.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, vl, 25, 0.3, 0.5, 0.3, 0.2);
            }
            case "sniper_bolt" -> {
                double far = attacker.getLocation().distance(victim.getLocation());
                if (far >= c.getDouble("min-range", 15)) {
                    dmg *= 1 + c.getDouble("bonus", 1.0);
                    victim.getWorld().spawnParticle(Particle.CRIT, vl, 30, 0.3, 0.5, 0.3, 0.2);
                    victim.getWorld().playSound(vl, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.8f);
                } else {
                    dmg *= 1 + c.getDouble("close-bonus", 0.2);
                }
            }
            case "poseidon_wrath" -> {
                dmg *= 1 + c.getDouble("bonus", 0.6);
                victim.getWorld().spawnParticle(Particle.BUBBLE_POP, vl, 25, 0.3, 0.5, 0.3, 0.05);
            }
            case "kraken_grasp" -> {
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (c.getDouble("root-seconds", 2.5) * 20), 6));
                victim.getWorld().spawnParticle(Particle.BUBBLE_POP, vl, 30, 0.3, 0.5, 0.3, 0.05);
            }
            default -> {
            }
        }
        return dmg;
    }

    private void blockSprint(Player target, int ticks) {
        new BukkitRunnable() {
            int left = ticks;

            @Override
            public void run() {
                if (!target.isOnline() || target.isDead() || left <= 0) {
                    cancel();
                    return;
                }
                target.setSprinting(false);
                left--;
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // =====================================================================
    //  projectiles: arming, launch, impact
    // =====================================================================

    private String tagOf(Entity e) {
        if (!(e instanceof Projectile pr)) return null;
        return pr.getPersistentDataContainer().get(tagKey, PersistentDataType.STRING);
    }

    private void tag(Entity e, String id) {
        e.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, id);
    }

    public void onLaunch(Projectile proj, Player shooter) {
        if (!(proj instanceof AbstractArrow arrow)) return;
        if (tagOf(proj) != null) return; // our own extra projectile
        String id = armed.get(shooter.getUniqueId());
        if (id == null) return;
        if (!am.isActive(shooter, id)) {
            armed.remove(shooter.getUniqueId());
            return;
        }
        // trident abilities only apply to tridents, bow/crossbow abilities only to arrows
        if ((proj instanceof Trident) != TRIDENT_IDS.contains(id)) return;

        armed.remove(shooter.getUniqueId());
        am.endBuff(shooter, id);
        tag(proj, id);
        ConfigurationSection c = am.cfg(id);

        if (id.equals("piercing_shot")) {
            arrow.setPierceLevel(c.getInt("pierce", 2));
        } else if (id.equals("multishot_burst")) {
            spawnExtras(shooter, arrow, c);
        }
        shooter.getWorld().playSound(shooter.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.7f, 1.4f);
    }

    private void spawnExtras(Player shooter, AbstractArrow original, ConfigurationSection c) {
        int count = Math.max(0, c.getInt("extra-projectiles", 4));
        double spread = c.getDouble("spread-degrees", 12);
        Vector base = original.getVelocity();
        for (int i = 0; i < count; i++) {
            // -2,-1,+1,+2 steps around the main bolt
            int step = (i / 2) + 1;
            double angle = Math.toRadians(spread * step * (i % 2 == 0 ? -1 : 1));
            Vector v = base.clone().rotateAroundY(angle);
            original.getWorld().spawn(original.getLocation(), Arrow.class, a -> {
                a.setShooter(shooter);
                a.setVelocity(v);
                a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                a.setCritical(true);
                tag(a, "multishot_extra");
            });
        }
    }

    public void onHit(ProjectileHitEvent e) {
        Projectile proj = e.getEntity();
        String id = tagOf(proj);
        if (id == null || !ON_HIT_IDS.contains(id)) return;
        if (!(proj.getShooter() instanceof Player shooter)) return;
        // handle each tagged projectile once
        proj.getPersistentDataContainer().remove(tagKey);

        Location loc;
        if (e.getHitEntity() != null) loc = e.getHitEntity().getLocation().add(0, 1, 0);
        else if (e.getHitBlock() != null) loc = e.getHitBlock().getLocation().add(0.5, 1.0, 0.5);
        else loc = proj.getLocation();
        World w = loc.getWorld();
        ConfigurationSection c = am.cfg(id);

        switch (id) {
            case "explosive_arrow" -> {
                double r = c.getDouble("radius", 3);
                double dmg = c.getDouble("damage", 5.0);
                double kb = c.getDouble("knockback", 0.8);
                for (Entity en : w.getNearbyEntities(loc, r, r, r)) {
                    if (en instanceof LivingEntity le && am.canHarm(shooter, le)) {
                        am.damage(shooter, le, dmg);
                        launch(le, away(loc, le.getLocation(), kb, 0.3));
                    }
                }
                w.spawnParticle(Particle.EXPLOSION, loc, 1, 0, 0, 0, 0);
                w.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.2f);
            }
            case "blast_bolt" -> {
                double r = c.getDouble("radius", 4);
                double kb = c.getDouble("knockback", 1.8);
                for (Entity en : w.getNearbyEntities(loc, r, r, r)) {
                    if (en instanceof LivingEntity le && am.canHarm(shooter, le)) {
                        launch(le, away(loc, le.getLocation(), kb, 0.45));
                    }
                }
                w.spawnParticle(Particle.EXPLOSION, loc, 1, 0, 0, 0, 0);
                w.spawnParticle(Particle.CLOUD, loc, 25, 0.5, 0.3, 0.5, 0.1);
                w.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.5f);
            }
            case "whirlpool" -> {
                final double r = c.getDouble("radius", 6);
                final double power = c.getDouble("power", 0.9);
                final int pulses = c.getInt("pulses", 4);
                final Location center = loc.clone();
                for (int i = 0; i < pulses; i++) {
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (!shooter.isOnline()) return;
                        pullToward(shooter, center, r, power);
                        center.getWorld().spawnParticle(Particle.BUBBLE_POP, center, 40, r / 3, 0.5, r / 3, 0.1);
                    }, i * 8L);
                }
                w.playSound(loc, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1f, 0.7f);
            }
            case "thunder_throw" -> {
                double dmg = c.getDouble("damage", 6.0);
                w.strikeLightningEffect(loc);
                double r = e.getHitEntity() != null ? 1.5 : 2.0;
                for (Entity en : w.getNearbyEntities(loc, r, r, r)) {
                    if (en instanceof LivingEntity le && am.canHarm(shooter, le)) am.damage(shooter, le, dmg);
                }
            }
            case "lightning_arrow", "thunder_bolt" -> {
                double bolt = c.getDouble("damage", 5.0);
                w.strikeLightningEffect(loc);
                double br = e.getHitEntity() != null ? 1.5 : 2.0;
                for (Entity en : w.getNearbyEntities(loc, br, br, br)) {
                    if (en instanceof LivingEntity le && am.canHarm(shooter, le)) am.damage(shooter, le, bolt);
                }
            }
            default -> {
            }
        }
    }

    // =====================================================================
    //  helpers
    // =====================================================================

    /** Entity you are looking at, or (for easier aiming on Bedrock) the closest enemy in a forward cone. */
    private LivingEntity findTarget(Player p, double range) {
        Entity t = p.getTargetEntity((int) Math.ceil(range));
        if (t instanceof LivingEntity le && am.canHarm(p, le)) return le;
        Vector eye = p.getEyeLocation().toVector();
        Vector dir = p.getEyeLocation().getDirection();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity en : p.getNearbyEntities(range, range, range)) {
            if (!(en instanceof LivingEntity le) || !am.canHarm(p, le)) continue;
            Vector to = le.getEyeLocation().toVector().subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01) continue;
            if (to.clone().normalize().dot(dir) < 0.8) continue;
            if (dist < bestDist) {
                bestDist = dist;
                best = le;
            }
        }
        return best;
    }

    private void pullToward(Player src, Location center, double radius, double power) {
        for (Entity en : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(en instanceof LivingEntity le) || !am.canHarm(src, le)) continue;
            Vector v = center.toVector().subtract(le.getLocation().toVector());
            if (v.lengthSquared() < 1.0) continue;
            v.normalize().multiply(power).setY(0.25);
            launch(le, v);
        }
    }

    private static Vector away(Location from, Location to, double power, double lift) {
        Vector v = to.toVector().subtract(from.toVector()).setY(0);
        if (v.lengthSquared() < 0.0001) return new Vector(0, lift, 0);
        return v.normalize().multiply(power).setY(lift);
    }

    /** Sets velocity unless the target is Unstoppable. Caps the speed so nobody is flung out of the world. */
    private void launch(LivingEntity le, Vector v) {
        if (le instanceof Player lp && am.isActive(lp, "unstoppable")) return;
        if (v.length() > 3.0) v.normalize().multiply(3.0);
        le.setVelocity(v);
    }

    /** Living enemies (that this player may harm) within a radius. */
    private List<LivingEntity> enemiesAround(Player p, double r) {
        List<LivingEntity> out = new ArrayList<>();
        for (Entity en : p.getNearbyEntities(r, r / 2 + 1, r)) {
            if (en instanceof LivingEntity le && am.canHarm(p, le)) out.add(le);
        }
        return out;
    }

    private void pot(LivingEntity le, PotionEffectType type, double seconds, int amplifier) {
        le.addPotionEffect(new PotionEffect(type, (int) (seconds * 20), amplifier, false, true));
    }

    /** Heals the player; false if already at full health. */
    private boolean heal(Player p, double amount) {
        AttributeInstance mh = p.getAttribute(Util.maxHealth());
        double max = mh != null ? mh.getValue() : 20.0;
        if (p.getHealth() >= max - 0.1) return false;
        p.setHealth(Math.min(max, p.getHealth() + amount));
        p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.8, 0), 8, 0.3, 0.2, 0.3, 0);
        return true;
    }

    /** Damage over time, one tick per second, through the ability damage path. */
    private void bleed(Player src, LivingEntity victim, int seconds, double perSecond) {
        new BukkitRunnable() {
            int left = seconds;

            @Override
            public void run() {
                if (left <= 0 || !src.isOnline() || !victim.isValid() || victim.isDead()) {
                    cancel();
                    return;
                }
                am.damage(src, victim, perSecond);
                victim.getWorld().spawnParticle(Particle.CRIT, victim.getLocation().add(0, 1, 0), 8, 0.3, 0.4, 0.3, 0.05);
                left--;
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    /** A wave that travels forward in a straight line, damaging every enemy it passes. False if there is no direction. */
    private boolean lineWave(Player p, double length, double dmg, double kb, Particle particle) {
        Vector dir = p.getLocation().getDirection().setY(0);
        if (dir.lengthSquared() < 0.0001) return false;
        dir.normalize();
        Set<UUID> hit = new HashSet<>();
        World w = p.getWorld();
        Location origin = p.getLocation();
        for (int i = 1; i <= (int) length; i++) {
            Location pt = origin.clone().add(dir.clone().multiply(i));
            if (!pt.getBlock().isPassable() && !pt.clone().add(0, 1, 0).getBlock().isPassable()) break;
            w.spawnParticle(particle, pt.clone().add(0, 1, 0), 4, 0.3, 0.4, 0.3, 0.02);
            for (Entity en : w.getNearbyEntities(pt, 1.3, 1.6, 1.3)) {
                if (en instanceof LivingEntity le && am.canHarm(p, le) && hit.add(le.getUniqueId())) {
                    am.damage(p, le, dmg);
                    if (kb > 0) launch(le, dir.clone().multiply(kb).setY(0.35));
                }
            }
        }
        return true;
    }

    private boolean safeSpot(Location l) {
        Block feet = l.getBlock();
        Block head = feet.getRelative(BlockFace.UP);
        if (!feet.isPassable() || feet.isLiquid() || !head.isPassable() || head.isLiquid()) return false;
        if (feet.getType().name().contains("FIRE")) return false;
        for (int i = 1; i <= 3; i++) {
            Block b = feet.getRelative(0, -i, 0);
            Material t = b.getType();
            if (t == Material.LAVA || t == Material.MAGMA_BLOCK || t == Material.CACTUS || t == Material.CAMPFIRE
                    || t == Material.SOUL_CAMPFIRE || b.isLiquid()) return false;
            if (t.isSolid()) return true;
        }
        return false;
    }
}
