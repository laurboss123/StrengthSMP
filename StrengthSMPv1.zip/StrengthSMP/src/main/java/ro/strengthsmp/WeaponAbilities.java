package ro.strengthsmp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.Trident;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * All weapon-category abilities (sword, axe, mace, shield, trident, bow, crossbow).
 * No ability here ever breaks blocks. Everything is server-side, so Java and Bedrock (Geyser) behave the same.
 *
 * Ranged abilities (trident / bow / crossbow) "arm" the next shot: the cooldown starts when you use the
 * ability, and the next projectile you fire gets the effect.
 */
public class WeaponAbilities {

    private record Mark(UUID victim, long until) {
    }

    private static final Set<String> TRIDENT_IDS = Set.of("thunder_throw", "whirlpool");
    private static final Set<String> ON_HIT_IDS = Set.of("thunder_throw", "whirlpool", "explosive_arrow", "blast_bolt");

    private final StrengthSMP plugin;
    private final AbilityManager am;
    private final NamespacedKey tagKey;
    private final Random random = new Random();

    private final Map<UUID, String> armed = new HashMap<>();
    private final Map<UUID, Long> armorBroken = new HashMap<>();
    private final Map<UUID, Mark> marks = new HashMap<>();
    private final Set<UUID> meteor = new HashSet<>();

    public WeaponAbilities(StrengthSMP plugin, AbilityManager am) {
        this.plugin = plugin;
        this.am = am;
        this.tagKey = new NamespacedKey(plugin, "ability");
    }

    // =====================================================================
    //  registration
    // =====================================================================

    public void register() {
        registerSword();
        registerAxe();
        registerMace();
        registerShield();
        registerTrident();
        registerBow();
        registerCrossbow();

        // Item-only ability (Thunder Sword). Not part of any weapon category, so it never shows in the menu.
        am.register("lightning", "Lightning Strike", "Call lightning on the target you are looking at.",
                Material.LIGHTNING_ROD, (p, c) -> {
                    Entity t = p.getTargetEntity(c.getInt("range", 20));
                    if (!(t instanceof LivingEntity le) || !am.canHarm(p, le)) {
                        plugin.hud().flash(p, Util.color("&cNo valid target."));
                        return false;
                    }
                    if (c.getBoolean("real-lightning", false)) le.getWorld().strikeLightning(le.getLocation());
                    else le.getWorld().strikeLightningEffect(le.getLocation());
                    am.damage(p, le, c.getDouble("damage", 6.0));
                    return true;
                });
    }

    // ---------------------------------------------------------------- SWORD

    private void registerSword() {
        am.register("dash", "Dash", "Dash forward quickly.", Material.FEATHER, "sword", (p, c) -> {
            Vector dir = p.getLocation().getDirection().setY(0);
            if (dir.lengthSquared() < 0.0001) dir = new Vector(0, 0, 1);
            dir.normalize().multiply(c.getDouble("power", 1.8)).setY(c.getDouble("lift", 0.25));
            p.setVelocity(dir);
            am.activate(p, "nofall", 3);
            p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_ATTACK_SWEEP, 1f, 1f);
            p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 15, 0.3, 0.1, 0.3, 0.02);
            return true;
        });

        am.register("lifesteal", "Lifesteal", "Heal for 20% of the damage you deal.",
                Material.GHAST_TEAR, "sword", (p, c) -> {
                    am.activate(p, "lifesteal", c.getDouble("duration", 6));
                    p.getWorld().spawnParticle(Particle.HEART, p.getLocation().add(0, 1.8, 0), 6, 0.3, 0.2, 0.3, 0);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITCH_DRINK, 1f, 1f);
                    return true;
                });

        am.register("berserker", "Berserker", "Deal 30% more damage for a few seconds.",
                Material.NETHERITE_SWORD, "sword", (p, c) -> {
                    am.activate(p, "berserker", c.getDouble("duration", 6));
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_RAVAGER_ROAR, 1f, 1f);
                    return true;
                });

        am.register("shadow_strike", "Shadow Strike", "Teleport behind a target within 5 blocks. Your next hit deals bonus damage.",
                Material.ENDER_EYE, "sword", (p, c) -> {
                    LivingEntity t = findTarget(p, c.getDouble("range", 5));
                    if (t == null) {
                        plugin.hud().flash(p, Util.color("&cNo target within range."));
                        return false;
                    }
                    Vector back = t.getLocation().getDirection().setY(0);
                    if (back.lengthSquared() < 0.0001) back = p.getLocation().getDirection().setY(0);
                    if (back.lengthSquared() < 0.0001) return false;
                    back.normalize();
                    Location dest = null;
                    for (double d : new double[]{1.5, 1.0}) {
                        Location cand = t.getLocation().clone().subtract(back.clone().multiply(d));
                        if (safeSpot(cand)) {
                            dest = cand;
                            break;
                        }
                    }
                    if (dest == null) {
                        plugin.hud().flash(p, Util.color("&cNo room behind the target."));
                        return false;
                    }
                    dest.setDirection(t.getEyeLocation().toVector().subtract(dest.clone().add(0, 1.62, 0).toVector()));
                    p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.2);
                    p.teleport(dest);
                    p.getWorld().spawnParticle(Particle.PORTAL, dest.clone().add(0, 1, 0), 25, 0.3, 0.5, 0.3, 0.2);
                    p.getWorld().playSound(dest, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
                    am.activate(p, "shadow_strike", c.getDouble("window", 5));
                    return true;
                });

        am.register("blood_rage", "Blood Rage", "Attack faster for 5 seconds, but take 15% more damage.",
                Material.REDSTONE, "sword", (p, c) -> {
                    double dur = c.getDouble("duration", 5);
                    am.activate(p, "blood_rage", dur);
                    p.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, (int) (dur * 20),
                            c.getInt("haste-amplifier", 2), false, false));
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.1);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WOLF_GROWL, 1f, 0.8f);
                    return true;
                });
    }

    // ---------------------------------------------------------------- AXE

    private void registerAxe() {
        am.register("ground_slam", "Ground Slam", "Slam the ground, damaging and knocking back nearby enemies.",
                Material.IRON_AXE, "axe", (p, c) -> {
                    double r = c.getDouble("radius", 5);
                    double dmg = c.getDouble("damage", 6.0);
                    double kb = c.getDouble("knockback", 1.0);
                    for (Entity en : p.getNearbyEntities(r, r / 2, r)) {
                        if (en instanceof LivingEntity le && am.canHarm(p, le)) {
                            am.damage(p, le, dmg);
                            launch(le, away(p.getLocation(), le.getLocation(), kb, 0.45));
                        }
                    }
                    p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 40, r / 2, 0.2, r / 2, 0.1);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
                    return true;
                });

        am.register("armor_break", "Armor Break", "Your next hit lowers the target's damage resistance for 4 seconds.",
                Material.NETHERITE_AXE, "axe", (p, c) -> {
                    am.activate(p, "armor_break", c.getDouble("window", 8));
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BREAK, 1f, 1f);
                    return true;
                });

        am.register("heavy_strike", "Heavy Strike", "Your next axe hit deals 50% bonus damage.",
                Material.DIAMOND_AXE, "axe", (p, c) -> {
                    am.activate(p, "heavy_strike", c.getDouble("window", 10));
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_AXE_STRIP, 1f, 0.6f);
                    return true;
                });

        am.register("earthquake", "Earthquake", "A shockwave around you pushes nearby enemies away.",
                Material.COBBLESTONE, "axe", (p, c) -> {
                    double r = c.getDouble("radius", 6);
                    double kb = c.getDouble("knockback", 1.6);
                    for (Entity en : p.getNearbyEntities(r, r / 2, r)) {
                        if (en instanceof LivingEntity le && am.canHarm(p, le)) {
                            launch(le, away(p.getLocation(), le.getLocation(), kb, 0.4));
                        }
                    }
                    Location base = p.getLocation();
                    for (int i = 0; i < 24; i++) {
                        double a = Math.PI * 2 * i / 24.0;
                        base.getWorld().spawnParticle(Particle.CLOUD,
                                base.clone().add(Math.cos(a) * r * 0.8, 0.1, Math.sin(a) * r * 0.8), 2, 0.1, 0.05, 0.1, 0.01);
                    }
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 0.6f);
                    return true;
                });

        am.register("iron_will", "Iron Will", "Take 35% less damage for 4 seconds.",
                Material.IRON_CHESTPLATE, "axe", (p, c) -> {
                    am.activate(p, "iron_will", c.getDouble("duration", 4));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_PLACE, 0.7f, 1.2f);
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.05);
                    return true;
                });
    }

    // ---------------------------------------------------------------- MACE

    private void registerMace() {
        am.register("meteor_smash", "Meteor Smash", "Jump into the air and slam down, damaging enemies where you land.",
                Material.MACE, "mace", (p, c) -> {
                    if (!meteor.add(p.getUniqueId())) return false;
                    Vector v = p.getVelocity();
                    v.setY(c.getDouble("lift", 1.1));
                    p.setVelocity(v);
                    am.activate(p, "nofall", 10);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1f, 1f);
                    startMeteor(p, c);
                    return true;
                });

        am.register("gravity_crush", "Gravity Crush", "Pull nearby enemies toward you.",
                Material.ENDER_PEARL, "mace", (p, c) -> {
                    double r = c.getDouble("radius", 7);
                    double power = c.getDouble("power", 1.1);
                    pullToward(p, p.getLocation(), r, power);
                    p.getWorld().spawnParticle(Particle.PORTAL, p.getLocation().add(0, 1, 0), 60, r / 3, 0.8, r / 3, 0.5);
                    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 0.5f);
                    return true;
                });

        am.register("seismic_wave", "Seismic Wave", "Send a wave forward that damages and knocks back enemies.",
                Material.DEEPSLATE, "mace", (p, c) -> {
                    Vector dir = p.getLocation().getDirection().setY(0);
                    if (dir.lengthSquared() < 0.0001) return false;
                    dir.normalize();
                    double length = c.getDouble("length", 10);
                    double dmg = c.getDouble("damage", 6.0);
                    double kb = c.getDouble("knockback", 1.2);
                    Set<UUID> hit = new HashSet<>();
                    World w = p.getWorld();
                    Location origin = p.getLocation();
                    for (int i = 1; i <= (int) length; i++) {
                        Location pt = origin.clone().add(dir.clone().multiply(i));
                        if (!pt.getBlock().isPassable() && !pt.clone().add(0, 1, 0).getBlock().isPassable()) break;
                        w.spawnParticle(Particle.CLOUD, pt.clone().add(0, 0.2, 0), 4, 0.3, 0.1, 0.3, 0.02);
                        w.spawnParticle(Particle.CRIT, pt.clone().add(0, 0.5, 0), 3, 0.3, 0.2, 0.3, 0.1);
                        for (Entity en : w.getNearbyEntities(pt, 1.3, 1.6, 1.3)) {
                            if (en instanceof LivingEntity le && am.canHarm(p, le) && hit.add(le.getUniqueId())) {
                                am.damage(p, le, dmg);
                                launch(le, dir.clone().multiply(kb).setY(0.4));
                            }
                        }
                    }
                    w.playSound(origin, Sound.ENTITY_WARDEN_SONIC_CHARGE, 0.6f, 1.6f);
                    return true;
                });

        am.register("overcharge", "Overcharge", "Your next mace hit deals 40% bonus damage.",
                Material.BLAZE_POWDER, "mace", (p, c) -> {
                    am.activate(p, "overcharge", c.getDouble("window", 10));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.4f);
                    p.getWorld().spawnParticle(Particle.CRIT, p.getLocation().add(0, 1, 0), 25, 0.4, 0.6, 0.4, 0.1);
                    return true;
                });

        am.register("unstoppable", "Unstoppable", "Gain knockback resistance for 5 seconds.",
                Material.NETHERITE_INGOT, "mace", (p, c) -> {
                    double dur = c.getDouble("duration", 5);
                    am.activate(p, "unstoppable", dur);
                    AttributeInstance inst = p.getAttribute(Util.knockbackResistance());
                    if (inst != null) {
                        final AttributeModifier mod = new AttributeModifier(
                                new NamespacedKey(plugin, "unstoppable"), 1.0, AttributeModifier.Operation.ADD_NUMBER);
                        inst.addTransientModifier(mod);
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            AttributeInstance now = p.getAttribute(Util.knockbackResistance());
                            if (now != null) now.removeModifier(mod);
                        }, (long) (dur * 20));
                    }
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_NETHERITE, 1f, 1f);
                    return true;
                });
    }

    private void startMeteor(Player p, ConfigurationSection c) {
        final UUID id = p.getUniqueId();
        final double dive = c.getDouble("dive-speed", 2.0);
        final double radius = c.getDouble("radius", 4);
        final double dmg = c.getDouble("damage", 8.0);
        final double kb = c.getDouble("knockback", 0.9);
        new BukkitRunnable() {
            int ticks = 0;
            boolean diving = false;

            @Override
            public void run() {
                ticks++;
                if (!p.isOnline() || p.isDead() || ticks > 100) {
                    meteor.remove(id);
                    cancel();
                    return;
                }
                Vector v = p.getVelocity();
                if (!diving) {
                    if (ticks >= 3 && v.getY() <= 0.05) {
                        diving = true;
                        p.setVelocity(new Vector(0, -dive, 0));
                    }
                    return;
                }
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation(), 4, 0.25, 0.25, 0.25, 0.01);
                boolean landed = p.isOnGround()
                        || p.getLocation().clone().subtract(0, 0.4, 0).getBlock().getType().isSolid();
                if (!landed) {
                    if (v.getY() > -dive * 0.6) p.setVelocity(v.setY(-dive));
                    return;
                }
                Location l = p.getLocation();
                for (Entity en : p.getNearbyEntities(radius, radius / 2, radius)) {
                    if (en instanceof LivingEntity le && am.canHarm(p, le)) {
                        am.damage(p, le, dmg);
                        launch(le, away(l, le.getLocation(), kb, 0.5));
                    }
                }
                l.getWorld().spawnParticle(Particle.EXPLOSION, l, 3, radius / 3, 0.2, radius / 3, 0);
                l.getWorld().spawnParticle(Particle.CLOUD, l, 40, radius / 2, 0.2, radius / 2, 0.1);
                l.getWorld().playSound(l, Sound.ENTITY_GENERIC_EXPLODE, 1f, 0.8f);
                meteor.remove(id);
                cancel();
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }

    // ---------------------------------------------------------------- SHIELD

    private void registerShield() {
        am.register("reflect", "Reflect", "Reflect 30% of incoming damage back to the attacker for 5 seconds.",
                Material.GOLDEN_CHESTPLATE, "shield", (p, c) -> {
                    am.activate(p, "reflect", c.getDouble("duration", 5));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.5f);
                    p.getWorld().spawnParticle(Particle.END_ROD, p.getLocation().add(0, 1, 0), 15, 0.4, 0.6, 0.4, 0.02);
                    return true;
                });

        am.register("fortress", "Fortress", "Take 50% less damage for 5 seconds, but move slower.",
                Material.SHIELD, "shield", (p, c) -> {
                    double dur = c.getDouble("duration", 5);
                    am.activate(p, "fortress", dur);
                    p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, (int) (dur * 20),
                            c.getInt("slow-amplifier", 1), false, false));
                    p.getWorld().playSound(p.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.6f, 1.4f);
                    return true;
                });

        am.register("shield_bash", "Shield Bash", "Hit an enemy with your shield for damage and knockback.",
                Material.IRON_INGOT, "shield", (p, c) -> {
                    LivingEntity t = findTarget(p, c.getDouble("range", 3.5));
                    if (t == null) {
                        plugin.hud().flash(p, Util.color("&cNo enemy in front of you."));
                        return false;
                    }
                    am.damage(p, t, c.getDouble("damage", 4.0));
                    launch(t, away(p.getLocation(), t.getLocation(), c.getDouble("knockback", 1.4), 0.35));
                    t.getWorld().playSound(t.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 0.8f);
                    t.getWorld().spawnParticle(Particle.CRIT, t.getLocation().add(0, 1, 0), 12, 0.3, 0.4, 0.3, 0.1);
                    return true;
                });

        am.register("counterattack", "Counterattack", "Block an attack to make your next hit deal bonus damage.",
                Material.CLOCK, "shield", (p, c) -> {
                    am.activate(p, "counterattack", c.getDouble("window", 4));
                    plugin.hud().flash(p, Util.color("&eBlock an attack!"));
                    return true;
                });
    }

    // ---------------------------------------------------------------- TRIDENT

    private void registerTrident() {
        armAbility("thunder_throw", "Thunder Throw", "Your next trident throw is lightning-powered.", Material.TRIDENT, "trident");

        am.register("tidal_rush", "Tidal Rush", "Launch yourself forward toward your target.",
                Material.HEART_OF_THE_SEA, "trident", (p, c) -> {
                    LivingEntity t = findTarget(p, c.getDouble("range", 15));
                    Vector dir = p.getLocation().getDirection();
                    if (t != null) {
                        dir = t.getEyeLocation().toVector().subtract(p.getEyeLocation().toVector());
                        if (dir.lengthSquared() < 0.0001) return false;
                    }
                    double power = c.getDouble("power", 1.9);
                    if (t != null) {
                        double dist = p.getLocation().distance(t.getLocation());
                        power = Math.min(power, Math.max(0.6, dist * 0.35));
                    }
                    Vector v = dir.clone().normalize().multiply(power);
                    v.setY(Math.max(v.getY(), 0.25));
                    p.setVelocity(v);
                    am.activate(p, "nofall", 4);
                    p.getWorld().playSound(p.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_1, 1f, 1f);
                    p.getWorld().spawnParticle(Particle.BUBBLE_POP, p.getLocation().add(0, 1, 0), 25, 0.4, 0.5, 0.4, 0.05);
                    return true;
                });

        armAbility("whirlpool", "Whirlpool", "Your next trident throw pulls nearby enemies toward the impact point.",
                Material.PRISMARINE_SHARD, "trident");

        am.register("storm_call", "Storm Call", "Call a small lightning storm around the target area.",
                Material.LIGHTNING_ROD, "trident", (p, c) -> {
                    double range = c.getDouble("range", 25);
                    Location center;
                    Entity te = p.getTargetEntity((int) range);
                    if (te != null) {
                        center = te.getLocation();
                    } else {
                        RayTraceResult r = p.getWorld().rayTraceBlocks(p.getEyeLocation(), p.getEyeLocation().getDirection(), range);
                        if (r == null) {
                            plugin.hud().flash(p, Util.color("&cNo target area."));
                            return false;
                        }
                        center = r.getHitPosition().toLocation(p.getWorld());
                    }
                    final Location base = center.clone();
                    final int strikes = c.getInt("strikes", 4);
                    final double spread = c.getDouble("spread", 3.0);
                    final double dmg = c.getDouble("damage", 4.0);
                    final double hitRadius = c.getDouble("hit-radius", 2.5);
                    for (int i = 0; i < strikes; i++) {
                        Bukkit.getScheduler().runTaskLater(plugin, () -> {
                            if (!p.isOnline()) return;
                            Location s = base.clone().add((random.nextDouble() - 0.5) * 2 * spread, 0,
                                    (random.nextDouble() - 0.5) * 2 * spread);
                            s.getWorld().strikeLightningEffect(s);
                            for (Entity en : s.getWorld().getNearbyEntities(s, hitRadius, hitRadius + 1, hitRadius)) {
                                if (en instanceof LivingEntity le && am.canHarm(p, le)) am.damage(p, le, dmg);
                            }
                        }, i * 6L);
                    }
                    return true;
                });
    }

    // ---------------------------------------------------------------- BOW

    private void registerBow() {
        armAbility("piercing_shot", "Piercing Shot", "Your next arrow deals bonus damage and pierces through enemies.", Material.ARROW, "bow");
        armAbility("frost_arrow", "Frost Arrow", "Your next arrow slows the target for 3 seconds.", Material.SNOWBALL, "bow");
        armAbility("explosive_arrow", "Explosive Arrow", "Your next arrow explodes on impact. No block damage.", Material.TNT, "bow");
        armAbility("marked_target", "Marked Target", "Your next arrow marks the enemy for 6 seconds. Your next hit on them deals bonus damage.",
                Material.SPECTRAL_ARROW, "bow");
    }

    // ---------------------------------------------------------------- CROSSBOW

    private void registerCrossbow() {
        armAbility("multishot_burst", "Multishot Burst", "Your next bolt fires a burst of extra projectiles.", Material.CROSSBOW, "crossbow");
        armAbility("snare_bolt", "Snare Bolt", "Your next bolt slows the target and stops them sprinting briefly.", Material.COBWEB, "crossbow");
        armAbility("blast_bolt", "Blast Bolt", "Your next bolt knocks enemies away on impact. No block damage.", Material.FIRE_CHARGE, "crossbow");
        armAbility("execution_bolt", "Execution Bolt", "Your next bolt deals bonus damage to targets below 30% health.", Material.IRON_SWORD, "crossbow");
    }

    private void armAbility(String id, String name, String desc, Material icon, String category) {
        am.register(id, name, desc, icon, category, (p, c) -> {
            double secs = c.getDouble("arm-seconds", 10);
            armed.put(p.getUniqueId(), id);
            am.activate(p, id, secs);
            p.getWorld().playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 0.8f, 1.6f);
            plugin.hud().flash(p, Util.color("&6" + name + " &earmed - your next shot is empowered!"));
            return true;
        });
    }

    // =====================================================================
    //  state queries used by the listeners
    // =====================================================================

    public boolean hasArmed(Player p) {
        String id = armed.get(p.getUniqueId());
        if (id == null) return false;
        if (!am.isActive(p, id)) {
            armed.remove(p.getUniqueId());
            return false;
        }
        return true;
    }

    public void clearState(UUID id) {
        armed.remove(id);
        marks.remove(id);
        meteor.remove(id);
        armorBroken.remove(id);
    }

    public boolean isArmorBroken(LivingEntity le) {
        Long t = armorBroken.get(le.getUniqueId());
        if (t == null) return false;
        if (System.currentTimeMillis() > t) {
            armorBroken.remove(le.getUniqueId());
            return false;
        }
        return true;
    }

    /** Extra damage reduction (0..1) from Iron Will and Fortress. */
    public double incomingReduction(Player p) {
        double r = 0;
        if (am.isActive(p, "iron_will")) r += am.cfg("iron_will").getDouble("reduction", 0.35);
        if (am.isActive(p, "fortress")) r += am.cfg("fortress").getDouble("reduction", 0.5);
        return r;
    }

    /** Called when a player blocks a hit with a shield. */
    public void onBlocked(Player p) {
        if (!am.isActive(p, "counterattack")) return;
        am.endBuff(p, "counterattack");
        am.activate(p, "counter_ready", am.cfg("counterattack").getDouble("hit-window", 4));
        plugin.hud().flash(p, Util.color("&6Counter ready! &eHit them now."));
        p.getWorld().playSound(p.getLocation(), Sound.ITEM_SHIELD_BLOCK, 1f, 1.6f);
    }

    private boolean consume(Player p, String key) {
        if (!am.isActive(p, key)) return false;
        am.endBuff(p, key);
        return true;
    }

    private static boolean isAxe(ItemStack i) {
        return i != null && i.getType().name().endsWith("_AXE");
    }

    private static boolean isMace(ItemStack i) {
        return i != null && i.getType() == Material.MACE;
    }

    // =====================================================================
    //  outgoing damage: next-hit buffs, marks, tagged projectiles
    // =====================================================================

    public double outgoing(Player attacker, LivingEntity victim, Entity damager, double dmg) {
        boolean melee = damager instanceof Player;
        long now = System.currentTimeMillis();
        Location vl = victim.getLocation().add(0, 1, 0);

        if (melee) {
            ItemStack hand = attacker.getInventory().getItemInMainHand();
            if (consume(attacker, "shadow_strike")) {
                dmg *= 1 + am.cfg("shadow_strike").getDouble("bonus", 0.4);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
            }
            if (isAxe(hand) && consume(attacker, "heavy_strike")) {
                dmg *= 1 + am.cfg("heavy_strike").getDouble("bonus", 0.5);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
                victim.getWorld().playSound(vl, Sound.ENTITY_PLAYER_ATTACK_STRONG, 1f, 0.6f);
            }
            if (isMace(hand) && consume(attacker, "overcharge")) {
                dmg *= 1 + am.cfg("overcharge").getDouble("bonus", 0.4);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
                victim.getWorld().playSound(vl, Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.8f);
            }
            if (consume(attacker, "counter_ready")) {
                dmg *= 1 + am.cfg("counterattack").getDouble("bonus", 0.5);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
            }
            if (consume(attacker, "armor_break")) {
                double secs = am.cfg("armor_break").getDouble("duration", 4);
                armorBroken.put(victim.getUniqueId(), now + (long) (secs * 1000));
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 15, 0.3, 0.4, 0.3, 0.1);
                victim.getWorld().playSound(vl, Sound.ITEM_SHIELD_BREAK, 1f, 1f);
            }
        }

        String tag = tagOf(damager);

        // Marked Target: next hit (any weapon) on the marked enemy
        Mark m = marks.get(attacker.getUniqueId());
        if (m != null) {
            if (now > m.until()) {
                marks.remove(attacker.getUniqueId());
                am.endBuff(attacker, "marked_target");
            } else if (m.victim().equals(victim.getUniqueId()) && !"marked_target".equals(tag)) {
                dmg *= 1 + am.cfg("marked_target").getDouble("bonus", 0.4);
                marks.remove(attacker.getUniqueId());
                am.endBuff(attacker, "marked_target");
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.4, 0.3, 0.15);
            }
        }

        if (tag == null) return dmg;
        ConfigurationSection c = am.cfg(tag);
        switch (tag) {
            case "piercing_shot" -> dmg *= 1 + c.getDouble("bonus", 0.5);
            case "multishot_extra" -> dmg *= am.cfg("multishot_burst").getDouble("extra-damage", 0.5);
            case "frost_arrow" -> {
                int ticks = (int) (c.getDouble("slow-seconds", 3) * 20);
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, c.getInt("slow-amplifier", 1)));
                victim.setFreezeTicks(Math.min(victim.getMaxFreezeTicks(), ticks));
                victim.getWorld().spawnParticle(Particle.SNOWFLAKE, vl, 25, 0.3, 0.5, 0.3, 0.03);
                victim.getWorld().playSound(vl, Sound.BLOCK_GLASS_BREAK, 1f, 1.4f);
            }
            case "snare_bolt" -> {
                int ticks = (int) (c.getDouble("duration", 2) * 20);
                victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, c.getInt("slow-amplifier", 1)));
                if (victim instanceof Player vp) blockSprint(vp, ticks);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 15, 0.3, 0.5, 0.3, 0.05);
            }
            case "execution_bolt" -> {
                AttributeInstance mh = victim.getAttribute(Util.maxHealth());
                double max = mh != null ? mh.getValue() : 20.0;
                if (victim.getHealth() / max < c.getDouble("threshold", 0.3)) {
                    dmg *= 1 + c.getDouble("bonus", 0.75);
                    victim.getWorld().spawnParticle(Particle.CRIT, vl, 30, 0.3, 0.5, 0.3, 0.2);
                    victim.getWorld().playSound(vl, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.8f);
                }
            }
            case "marked_target" -> {
                double secs = c.getDouble("mark-seconds", 6);
                marks.put(attacker.getUniqueId(), new Mark(victim.getUniqueId(), now + (long) (secs * 1000)));
                am.activate(attacker, "marked_target", secs);
                victim.getWorld().spawnParticle(Particle.CRIT, vl, 20, 0.3, 0.5, 0.3, 0.05);
                plugin.hud().flash(attacker, Util.color("&6Target marked!"));
            }
            default -> {
            }
        }
        return dmg;
    }

    private void blockSprint(Player target, int ticks) {
        new BukkitRunnable() {
            int left = ticks;

            @Override
            public void run() {
                if (!target.isOnline() || target.isDead() || left <= 0) {
                    cancel();
                    return;
                }
                target.setSprinting(false);
                left--;
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    // =====================================================================
    //  projectiles: arming, launch, impact
    // =====================================================================

    private String tagOf(Entity e) {
        if (!(e instanceof Projectile pr)) return null;
        return pr.getPersistentDataContainer().get(tagKey, PersistentDataType.STRING);
    }

    private void tag(Entity e, String id) {
        e.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, id);
    }

    public void onLaunch(Projectile proj, Player shooter) {
        if (!(proj instanceof AbstractArrow arrow)) return;
        if (tagOf(proj) != null) return; // our own extra projectile
        String id = armed.get(shooter.getUniqueId());
        if (id == null) return;
        if (!am.isActive(shooter, id)) {
            armed.remove(shooter.getUniqueId());
            return;
        }
        // trident abilities only apply to tridents, bow/crossbow abilities only to arrows
        if ((proj instanceof Trident) != TRIDENT_IDS.contains(id)) return;

        armed.remove(shooter.getUniqueId());
        am.endBuff(shooter, id);
        tag(proj, id);
        ConfigurationSection c = am.cfg(id);

        if (id.equals("piercing_shot")) {
            arrow.setPierceLevel(c.getInt("pierce", 2));
        } else if (id.equals("multishot_burst")) {
            spawnExtras(shooter, arrow, c);
        }
        shooter.getWorld().playSound(shooter.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 0.7f, 1.4f);
    }

    private void spawnExtras(Player shooter, AbstractArrow original, ConfigurationSection c) {
        int count = Math.max(0, c.getInt("extra-projectiles", 4));
        double spread = c.getDouble("spread-degrees", 12);
        Vector base = original.getVelocity();
        for (int i = 0; i < count; i++) {
            // -2,-1,+1,+2 steps around the main bolt
            int step = (i / 2) + 1;
            double angle = Math.toRadians(spread * step * (i % 2 == 0 ? -1 : 1));
            Vector v = base.clone().rotateAroundY(angle);
            original.getWorld().spawn(original.getLocation(), Arrow.class, a -> {
                a.setShooter(shooter);
                a.setVelocity(v);
                a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
                a.setCritical(true);
                tag(a, "multishot_extra");
            });
        }
    }

    public void onHit(ProjectileHitEvent e) {
        Projectile proj = e.getEntity();
        String id = tagOf(proj);
        if (id == null || !ON_HIT_IDS.contains(id)) return;
        if (!(proj.getShooter() instanceof Player shooter)) return;
        // handle each tagged projectile once
        proj.getPersistentDataContainer().remove(tagKey);

        Location loc;
        if (e.getHitEntity() != null) loc = e.getHitEntity().getLocation().add(0, 1, 0);
        else if (e.getHitBlock() != null) loc = e.getHitBlock().getLocation().add(0.5, 1.0, 0.5);
        else loc = proj.getLocation();
        World w = loc.getWorld();
        ConfigurationSection c = am.cfg(id);

        switch (id) {
            case "explosive_arrow" -> {
                double r = c.getDouble("radius", 3);
                double dmg = c.getDouble("damage", 5.0);
                double kb = c.getDouble("knockback", 0.8);
                for (Entity en : w.getNearbyEntities(loc, r, r, r)) {
                    if (en instanceof LivingEntity le && am.canHarm(shooter, le)) {
                        am.damage(shooter, le, dmg);
                        launch(le, away(loc, le.getLocation(), kb, 0.3));
                    }
                }
                w.spawnParticle(Particle.EXPLOSION, loc, 1, 0, 0, 0, 0);
                w.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.2f);
            }
            case "blast_bolt" -> {
                double r = c.getDouble("radius", 4);
                double kb = c.getDouble("knockback", 1.8);
                for (Entity en : w.getNearbyEntities(loc, r, r, r)) {
                    if (en instanceof LivingEntity le && am.canHarm(shooter, le)) {
                        launch(le, away(loc, le.getLocation(), kb, 0.45));
                    }
                }
                w.spawnParticle(Particle.EXPLOSION, loc, 1, 0, 0, 0, 0);
                w.spawnParticle(Particle.CLOUD, loc, 25, 0.5, 0.3, 0.5, 0.1);
                w.playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 0.8f, 1.5f);
            }
            case "whirlpool" -> {
                final double r = c.getDouble("radius", 6);
                final double power = c.getDouble("power", 0.9);
                final int pulses = c.getInt("pulses", 4);
                final Location center = loc.clone();
                for (int i = 0; i < pulses; i++) {
                    Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        if (!shooter.isOnline()) return;
                        pullToward(shooter, center, r, power);
                        center.getWorld().spawnParticle(Particle.BUBBLE_POP, center, 40, r / 3, 0.5, r / 3, 0.1);
                    }, i * 8L);
                }
                w.playSound(loc, Sound.ENTITY_PLAYER_SPLASH_HIGH_SPEED, 1f, 0.7f);
            }
            case "thunder_throw" -> {
                double dmg = c.getDouble("damage", 6.0);
                w.strikeLightningEffect(loc);
                double r = e.getHitEntity() != null ? 1.5 : 2.0;
                for (Entity en : w.getNearbyEntities(loc, r, r, r)) {
                    if (en instanceof LivingEntity le && am.canHarm(shooter, le)) am.damage(shooter, le, dmg);
                }
            }
            default -> {
            }
        }
    }

    // =====================================================================
    //  helpers
    // =====================================================================

    /** Entity you are looking at, or (for easier aiming on Bedrock) the closest enemy in a forward cone. */
    private LivingEntity findTarget(Player p, double range) {
        Entity t = p.getTargetEntity((int) Math.ceil(range));
        if (t instanceof LivingEntity le && am.canHarm(p, le)) return le;
        Vector eye = p.getEyeLocation().toVector();
        Vector dir = p.getEyeLocation().getDirection();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity en : p.getNearbyEntities(range, range, range)) {
            if (!(en instanceof LivingEntity le) || !am.canHarm(p, le)) continue;
            Vector to = le.getEyeLocation().toVector().subtract(eye);
            double dist = to.length();
            if (dist > range || dist < 0.01) continue;
            if (to.clone().normalize().dot(dir) < 0.8) continue;
            if (dist < bestDist) {
                bestDist = dist;
                best = le;
            }
        }
        return best;
    }

    private void pullToward(Player src, Location center, double radius, double power) {
        for (Entity en : center.getWorld().getNearbyEntities(center, radius, radius, radius)) {
            if (!(en instanceof LivingEntity le) || !am.canHarm(src, le)) continue;
            Vector v = center.toVector().subtract(le.getLocation().toVector());
            if (v.lengthSquared() < 1.0) continue;
            v.normalize().multiply(power).setY(0.25);
            launch(le, v);
        }
    }

    private static Vector away(Location from, Location to, double power, double lift) {
        Vector v = to.toVector().subtract(from.toVector()).setY(0);
        if (v.lengthSquared() < 0.0001) return new Vector(0, lift, 0);
        return v.normalize().multiply(power).setY(lift);
    }

    /** Sets velocity unless the target is Unstoppable. Caps the speed so nobody is flung out of the world. */
    private void launch(LivingEntity le, Vector v) {
        if (le instanceof Player lp && am.isActive(lp, "unstoppable")) return;
        if (v.length() > 3.0) v.normalize().multiply(3.0);
        le.setVelocity(v);
    }

    private boolean safeSpot(Location l) {
        Block feet = l.getBlock();
        Block head = feet.getRelative(BlockFace.UP);
        if (!feet.isPassable() || feet.isLiquid() || !head.isPassable() || head.isLiquid()) return false;
        if (feet.getType().name().contains("FIRE")) return false;
        for (int i = 1; i <= 3; i++) {
            Block b = feet.getRelative(0, -i, 0);
            Material t = b.getType();
            if (t == Material.LAVA || t == Material.MAGMA_BLOCK || t == Material.CACTUS || t == Material.CAMPFIRE
                    || t == Material.SOUL_CAMPFIRE || b.isLiquid()) return false;
            if (t.isSolid()) return true;
        }
        return false;
    }
}
