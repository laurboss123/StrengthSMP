package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class StrengthSMP extends JavaPlugin {

    private DataManager data;
    private StrengthManager strength;
    private AbilityManager abilities;
    private ItemManager items;
    private AntiFarm antiFarm;
    private ScoreboardManager scoreboards;
    private PlayerListener playerListener;
    private TeamManager teams;
    private ProtectionManager protection;
    private BountyManager bounty;
    private HudManager hud;
    private final Set<UUID> combatLoggers = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        data = new DataManager(this);
        strength = new StrengthManager(this);
        strength.loadRanks();
        antiFarm = new AntiFarm(this);
        abilities = new AbilityManager(this);
        abilities.registerDefaults();
        items = new ItemManager(this);
        items.load();
        scoreboards = new ScoreboardManager(this);
        teams = new TeamManager(this);
        teams.load();
        protection = new ProtectionManager(this);
        bounty = new BountyManager(this);
        hud = new HudManager(this);

        playerListener = new PlayerListener(this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(playerListener, this);
        getServer().getPluginManager().registerEvents(new ExtraListener(this), this);

        Commands cmds = new Commands(this);
        for (String name : List.of("strength", "ability", "withdraw", "prestige", "upgrade", "reroll",
                "leaderboard", "ssmp", "pvp", "team", "bounty")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(cmds);
                pc.setTabCompleter(cmds);
            }
        }

        // keep health / tab list in sync (armor bonuses etc.)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) strength.refresh(p);
        }, 100L, 100L);
        // autosave every 5 minutes
        Bukkit.getScheduler().runTaskTimer(this, () -> data.saveAll(), 6000L, 6000L);

        hud.start();
        protection.start();

        // /reload safety
        for (Player p : Bukkit.getOnlinePlayers()) playerListener.setup(p);

        // optional PlaceholderAPI support
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new StrengthPlaceholders(this).register();
                getLogger().info("PlaceholderAPI expansion registered (%strengthsmp_...%).");
            } catch (Throwable t) {
                getLogger().warning("Could not register PlaceholderAPI expansion: " + t.getMessage());
            }
        }

        getLogger().info("StrengthSMP enabled (Java + Bedrock via Geyser/Floodgate).");
    }

    @Override
    public void onDisable() {
        if (data != null) data.saveAll();
        if (teams != null) teams.save();
    }

    public void reload() {
        reloadConfig();
        strength.loadRanks();
        items.load();
    }

    private String text(String key, Object... kv) {
        String raw = getConfig().getString("messages." + key);
        if (raw == null) raw = "&cMissing message: " + key;
        return Util.fmt(raw, kv);
    }

    /** Message with the [Strength] prefix. */
    public Component msg(String key, Object... kv) {
        return Util.color(getConfig().getString("messages.prefix", "") + text(key, kv));
    }

    /** Message without prefix (for the action bar). */
    public Component raw(String key, Object... kv) {
        return Util.color(text(key, kv));
    }

    public void send(CommandSender to, String key, Object... kv) {
        to.sendMessage(msg(key, kv));
    }

    public Set<UUID> combatLoggers() {
        return combatLoggers;
    }

    public DataManager data() {
        return data;
    }

    public StrengthManager strength() {
        return strength;
    }

    public AbilityManager abilities() {
        return abilities;
    }

    public ItemManager items() {
        return items;
    }

    public AntiFarm antiFarm() {
        return antiFarm;
    }

    public ScoreboardManager scoreboards() {
        return scoreboards;
    }

    public TeamManager teams() {
        return teams;
    }

    public ProtectionManager protection() {
        return protection;
    }

    public BountyManager bounty() {
        return bounty;
    }

    public HudManager hud() {
        return hud;
    }
}
