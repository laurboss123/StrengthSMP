package ro.strengthsmp;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

public class StrengthSMP extends JavaPlugin {

    private DataManager data;
    private StrengthManager strength;
    private AbilityManager abilities;
    private ItemManager items;
    private AntiFarm antiFarm;
    private ScoreboardManager scoreboards;
    private PlayerListener playerListener;
    private TeamManager teams;
    private ProtectionManager protection;
    private BountyManager bounty;
    private HudManager hud;
    private CategoryManager categories;
    private SpawnProtection spawnProtection;
    private PassiveManager passives;
    private CosmeticsManager cosmetics;
    private Rewards rewards;
    private QuestManager quests;
    private DuelManager duels;
    private EventManager events;
    private WeeklyManager weekly;
    private ReviveManager revive;
    private FormsManager forms;
    private final Set<UUID> combatLoggers = new HashSet<>();

    // language files (language: ro in config.yml). "en" uses the texts built into the code and config.yml
    private YamlConfiguration langUser;
    private YamlConfiguration langDefault;
    private String langCode = "en";

    // runtime locations (arena spawns, KOTH zone) are kept out of config.yml so its comments are never rewritten
    private File locationsFile;
    private YamlConfiguration locations;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadLang();
        loadLocations();
        data = new DataManager(this);
        strength = new StrengthManager(this);
        strength.loadRanks();
        antiFarm = new AntiFarm(this);
        abilities = new AbilityManager(this);
        abilities.registerDefaults();
        items = new ItemManager(this);
        items.load();
        scoreboards = new ScoreboardManager(this);
        teams = new TeamManager(this);
        teams.load();
        protection = new ProtectionManager(this);
        bounty = new BountyManager(this);
        hud = new HudManager(this);
        categories = new CategoryManager(this);
        spawnProtection = new SpawnProtection(this);
        passives = new PassiveManager(this);
        cosmetics = new CosmeticsManager(this);
        rewards = new Rewards(this);
        quests = new QuestManager(this);
        duels = new DuelManager(this);
        events = new EventManager(this);
        weekly = new WeeklyManager(this);
        revive = new ReviveManager(this);
        forms = new FormsManager(this);

        playerListener = new PlayerListener(this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(playerListener, this);
        getServer().getPluginManager().registerEvents(new ExtraListener(this), this);
        getServer().getPluginManager().registerEvents(spawnProtection, this);
        getServer().getPluginManager().registerEvents(quests, this);
        getServer().getPluginManager().registerEvents(duels, this);

        Commands cmds = new Commands(this);
        for (String name : List.of("strength", "ability", "withdraw", "prestige", "upgrade", "reroll",
                "leaderboard", "ssmp", "pvp", "team", "bounty", "category", "duel", "quests", "revive")) {
            PluginCommand pc = getCommand(name);
            if (pc != null) {
                pc.setExecutor(cmds);
                pc.setTabCompleter(cmds);
            }
        }

        // keep health / tab list in sync (armor bonuses etc.)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) strength.refresh(p);
        }, 100L, 100L);
        // autosave every 5 minutes
        Bukkit.getScheduler().runTaskTimer(this, () -> data.saveAll(), 6000L, 6000L);

        hud.start();
        protection.start();
        duels.start();
        events.start();
        weekly.start();

        // /reload safety
        for (Player p : Bukkit.getOnlinePlayers()) playerListener.setup(p);

        // optional PlaceholderAPI support
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new StrengthPlaceholders(this).register();
                getLogger().info("PlaceholderAPI expansion registered (%strengthsmp_...%).");
            } catch (Throwable t) {
                getLogger().warning("Could not register PlaceholderAPI expansion: " + t.getMessage());
            }
        }

        getLogger().info("StrengthSMP enabled (Java + Bedrock via Geyser/Floodgate). Language: " + langCode);
    }

    @Override
    public void onDisable() {
        if (events != null) events.shutdown();
        if (data != null) data.saveAll();
        if (teams != null) teams.save();
    }

    public void reload() {
        reloadConfig();
        loadLang();
        strength.loadRanks();
        items.load();
        quests.invalidate();
    }

    // ---------- language ----------

    /** Loads plugins/StrengthSMP/lang/<code>.yml for the configured language (config.yml: language). */
    public void loadLang() {
        langCode = getConfig().getString("language", "en").toLowerCase(Locale.ROOT);
        langUser = null;
        langDefault = null;
        if (langCode.equals("en")) return;
        String res = "lang/" + langCode + ".yml";
        try {
            File f = new File(getDataFolder(), res);
            if (!f.exists() && getResource(res) != null) saveResource(res, false);
            if (f.exists()) langUser = YamlConfiguration.loadConfiguration(f);
            InputStream in = getResource(res);
            if (in != null) {
                langDefault = YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8));
            }
            if (langUser == null && langDefault == null) {
                getLogger().warning("Language '" + langCode + "' not found, using English.");
            }
        } catch (Exception ex) {
            getLogger().warning("Could not load language '" + langCode + "': " + ex.getMessage());
            langUser = null;
            langDefault = null;
        }
    }

    public String language() {
        return langCode;
    }

    private String langGet(String path) {
        String v = langUser != null ? langUser.getString(path) : null;
        if (v == null && langDefault != null) v = langDefault.getString(path);
        return v;
    }

    /** A UI text: the translated version when a language file is active, otherwise the built-in English default. */
    public String ui(String key, String def, Object... kv) {
        String raw = langGet("ui." + key);
        if (raw == null) raw = def;
        return Util.fmt(raw, kv);
    }

    private String text(String key, Object... kv) {
        String raw = langGet("messages." + key);
        if (raw == null) raw = getConfig().getString("messages." + key);
        if (raw == null) raw = "&cMissing message: " + key;
        return Util.fmt(raw, kv);
    }

    /** Message with the [Strength] prefix. */
    public Component msg(String key, Object... kv) {
        String prefix = langGet("messages.prefix");
        if (prefix == null) prefix = getConfig().getString("messages.prefix", "");
        return Util.color(prefix + text(key, kv));
    }

    /** Message without prefix (for the action bar). */
    public Component raw(String key, Object... kv) {
        return Util.color(text(key, kv));
    }

    public void send(CommandSender to, String key, Object... kv) {
        to.sendMessage(msg(key, kv));
    }

    // ---------- runtime locations (locations.yml) ----------

    private void loadLocations() {
        locationsFile = new File(getDataFolder(), "locations.yml");
        locations = YamlConfiguration.loadConfiguration(locationsFile);
    }

    public YamlConfiguration locations() {
        return locations;
    }

    public void saveLocations() {
        try {
            locations.save(locationsFile);
        } catch (IOException ex) {
            getLogger().warning("Could not save locations.yml: " + ex.getMessage());
        }
    }

    // ---------- accessors ----------

    public Set<UUID> combatLoggers() {
        return combatLoggers;
    }

    public DataManager data() {
        return data;
    }

    public StrengthManager strength() {
        return strength;
    }

    public AbilityManager abilities() {
        return abilities;
    }

    public ItemManager items() {
        return items;
    }

    public AntiFarm antiFarm() {
        return antiFarm;
    }

    public ScoreboardManager scoreboards() {
        return scoreboards;
    }

    public TeamManager teams() {
        return teams;
    }

    public ProtectionManager protection() {
        return protection;
    }

    public BountyManager bounty() {
        return bounty;
    }

    public HudManager hud() {
        return hud;
    }

    public SpawnProtection spawnProt() {
        return spawnProtection;
    }

    public CategoryManager categories() {
        return categories;
    }

    public PassiveManager passives() {
        return passives;
    }

    public CosmeticsManager cosmetics() {
        return cosmetics;
    }

    public Rewards rewards() {
        return rewards;
    }

    public QuestManager quests() {
        return quests;
    }

    public DuelManager duels() {
        return duels;
    }

    public EventManager events() {
        return events;
    }

    public WeeklyManager weekly() {
        return weekly;
    }

    public ReviveManager revive() {
        return revive;
    }

    public FormsManager forms() {
        return forms;
    }
}
