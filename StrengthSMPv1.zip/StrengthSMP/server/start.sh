#!/bin/bash
# Put paper.jar next to this file (https://papermc.io/downloads/paper)
java -Xms2G -Xmx4G -jar paper.jar --nogui
